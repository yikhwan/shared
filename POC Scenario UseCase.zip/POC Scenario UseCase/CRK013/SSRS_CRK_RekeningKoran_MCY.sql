
-------------------------------------------------------------------------------------------------------------------------------

set hivevar:z_dPeriod = date_format(date_add(trunc(CURRENT_TIMESTAMP(), 'MM'),(-1)),'yyyyMMdd');
set hivevar:z_dPeriodEOM = date_add(trunc(CURRENT_TIMESTAMP(), 'MM'),(-1));

set hivevar:z_dPeriodBOMName = date_format(trunc(${hivevar:z_dPeriodEOM},'MM'),'dd MMMM yyyy');
set hivevar:z_dPeriodEOMName = date_format(${hivevar:z_dPeriodEOM},'dd MMMM yyyy');

drop table if exists TMP_SIBS_DI236MBLSG;
create temporary table TMP_SIBS_DI236MBLSG
(
     DDACCT STRING, 
     DDBRA DECIMAL(5,0), 
     DDNA1 STRING, 
     DDNA2 STRING, 
     DDNA3 STRING, 
     DDNA4 STRING, 
     DDNA5 STRING, 
     DDPRDT TIMESTAMP, 
     DDBR string, 
     DDBRNAM STRING, 
     DDPDES STRING, 
     DDCTYP STRING, 
     RPTPAG DECIMAL(5,0), 
     DDDAT6 TIMESTAMP, 
     DDEFF6 TIMESTAMP, 
     DDREMA STRING, 
     DDMDR DECIMAL(17,2), 
     DDMCR DECIMAL(17,2), 
     DDBAL DECIMAL(19,2), 
     DDAWAL DECIMAL(19,2), 
     DDDBM DECIMAL(19,2), 
     DDCRM DECIMAL(19,2), 
     DDSGL1 STRING, 
     DDSGL2 STRING, 
     DDSGL3 STRING, 
     DDSGL4 STRING, 
     DDSGL5 STRING, 
     DDSGL6 STRING, 
     DDSGL7 STRING, 
     DDSGL8 STRING, 
     MCNOTE1 STRING, 
     MCCTYP STRING, 
     MCEXRT DECIMAL(13,7), 
     MCAMT DECIMAL(17,2), 
     MCAMTI DECIMAL(17,2), 
     MCTAMT DECIMAL(17,2), 
     MCNOTE2 STRING, 
     ODMAT6 TIMESTAMP, 
     ODCPNO STRING, 
     WOTRATE DECIMAL(11,7), 
     ODAGD6 TIMESTAMP, 
     ODREV6 TIMESTAMP, 
     ODEXP6 TIMESTAMP, 
     ODALMT DECIMAL(17,2), 
     AVLBAL DECIMAL(17,2), 
     POINT DECIMAL(11,2), 
     OWBAMT DECIMAL(17,2), 
     OWDAMT DECIMAL(17,2), 
     OWCAMT DECIMAL(17,2), 
     OWAMT DECIMAL(17,2), 
     CFEADD STRING, 
     CFEADC STRING, 
     MINMTDX DECIMAL(17,2), 
     MAXMTDX DECIMAL(17,2), 
     AVGAMTX DECIMAL(17,2), 
     ORGFILE STRING, 
     TIMESTP TIMESTAMP,
     ROWID INT,
	rowid_header int
);

insert into TMP_SIBS_DI236MBLSG
(
      ddacct
     ,ddbra
     ,ddna1
     ,ddna2
     ,ddna3
     ,ddna4
     ,ddna5
     ,ddprdt
     ,ddbr
     ,ddbrnam
     ,ddpdes
     ,ddctyp
     ,rptpag
     ,dddat6
     ,ddeff6
     ,ddrema
     ,ddmdr
     ,ddmcr
     ,ddbal
     ,ddawal
     ,dddbm
     ,ddcrm
     ,ddsgl1
     ,ddsgl2
     ,ddsgl3
     ,ddsgl4
     ,ddsgl5
     ,ddsgl6
     ,ddsgl7
     ,ddsgl8
     ,mcnote1
     ,mcctyp
     ,mcexrt
     ,mcamt
     ,mcamti
     ,mctamt
     ,mcnote2
     ,odmat6
     ,odcpno
     ,wotrate
     ,odagd6
     ,odrev6
     ,odexp6
     ,odalmt
     ,avlbal
     ,point
     ,owbamt
     ,owdamt
     ,owcamt
     ,owamt
     ,cfeadd
     ,cfeadc
     ,minmtdx
     ,maxmtdx
     ,avgamtx
     ,orgfile
     ,timestp
     ,rowid
     ,rowid_header
)
select
       ddacct as ddacct
     , ddbra as ddbra
     , ddna1 as ddna1
     , ddna2 as ddna2
     , ddna3 as ddna3
     , ddna4 as ddna4
     , ddna5 as ddna5
     , ddprdt as ddprdt
     , ddbr as ddbr
     , ddbrnam as ddbrnam
     , ddpdes as ddpdes
     , trim(ddctyp) as ddctyp
     , rptpag as rptpag
     , dddat6 as dddat6
     , ddeff6 as ddeff6
     , ddrema as ddrema
     , ddmdr as ddmdr
     , ddmcr as ddmcr
     , ddbal as ddbal
     , ddawal as ddawal
     , dddbm as dddbm
     , ddcrm as ddcrm
     , ddsgl1 as ddsgl1
     , ddsgl2 as ddsgl2
     , ddsgl3 as ddsgl3
     , ddsgl4 as ddsgl4
     , ddsgl5 as ddsgl5
     , ddsgl6 as ddsgl6
     , ddsgl7 as ddsgl7
     , ddsgl8 as ddsgl8
     , mcnote1 as mcnote1
     , mcctyp as mcctyp
     , mcexrt as mcexrt
     , mcamt as mcamt
     , mcamti as mcamti
     , mctamt as mctamt
     , mcnote2 as mcnote2
     , odmat6 as odmat6
     , trim(odcpno) as odcpno
     , wotrate as wotrate
     , odagd6 as odagd6
     , odrev6 as odrev6
     , odexp6 as odexp6
     , odalmt as odalmt
     , avlbal as avlbal
     , point as point
     , owbamt as owbamt
     , owdamt as owdamt
     , owcamt as owcamt
     , owamt as owamt
     , cfeadd as cfeadd
     , cfeadc as cfeadc
     , minmtdx as minmtdx
     , maxmtdx as maxmtdx
     , avgamtx as avgamtx
     , orgfile as orgfile
     , timestp as timestp
     , rowid as rowid
	, ROW_NUMBER() OVER (PARTITION BY ddacct,ddctyp ORDER BY DDDAT6 desc, ROWID desc ) as rowid_header
from t1_AS400.SIBS_DI236MBLSG  as xa
where xa.partition_date = ${hivevar:z_dPeriod}
;

drop table if exists TMP_Result;
create temporary table TMP_Result
(
      ddacct             string
     ,ddctyp             string
     ,TglTransaksi       string
     ,TglValuta          string
     ,Uraian             string
     ,debet              decimal(17,2)
     ,Kredit             decimal(17,2)
     ,saldo              decimal(17,2) 
     ,rowid_trx          int
     ,rowid_uraian       int
     ,rowid_ddctyp       int
     ,period             string
)
;

drop table if exists TMP_DDAWL_ACCTNO;
create temporary table TMP_DDAWL_ACCTNO
(
      ddacct         string
     ,ddctyp         string
     ,DDAWAL         decimal(17,2)
     ,rowid_ddawal   int
);

insert into TMP_DDAWL_ACCTNO
select 
      ddacct
     ,ddctyp
     ,ddawal
     ,ROW_NUMBER() OVER (PARTITION BY ddacct,ddctyp ORDER BY DDDAT6 asc, ROWID asc ) as rowid_ddawal
from TMP_SIBS_DI236MBLSG
;
-------------------------------POINT-----------------------------------------------------------

drop table if exists TMP_POINT_ACCTNO;
create temporary table TMP_POINT_ACCTNO
(
      ddacct         string
	,ddctyp         string
	,ODCPNO         string    
	,OWAMT          decimal(17,2)
	,point          string
	,lastsaldo      decimal(19,2)
);

insert into TMP_POINT_ACCTNO
select
     xa.ddacct
     ,xa.ddctyp
     ,xa.ODCPNO
     ,xa.OWAMT
     ,'Total POIN Anda = ' || cast(xa.POINT as string) as point
     ,xa.DDBAL as lastsaldo
from TMP_SIBS_DI236MBLSG as xa
where rowid_header = 1
;
----------------------------------------------------------------------------------------------

drop table if exists TMP_TRX_URAIAN;
create temporary table TMP_TRX_URAIAN
(
      ddacct         string
	,ddctyp         string
	,tgltransaksi   string  
	,tglvaluta      string
	,uraian1        string
	,uraian2        string
	,debet          decimal(17,2)
	,Kredit         decimal(17,2)
	,saldo          decimal(17,2) 
	,rowid_trx      int
	,rowid          int
);

INSERT INTO TMP_TRX_URAIAN
select 
     ddacct as ddacct
     ,ddctyp as ddctyp
     ,cast(from_unixtime(unix_timestamp(dddat6,'yyyy-MM-dd'),'dd/MM/yy') as string) as tgltransaksi
     ,cast(from_unixtime(unix_timestamp(COALESCE(DDEFF6, DDDAT6),'yyyy-MM-dd'),'dd/MM/yy') as string) as tglvaluta 
     ,regexp_replace(TRIM(split(ddrema,'  -  ')[0]),' +',' ') as uraian1
     ,regexp_replace(TRIM(split(ddrema,'  -  ')[1]),' +',' ') as uraian2
     ,DDMDR as debet
     ,DDMCR as kredit
     ,DDBAL as saldo
     ,ROW_NUMBER () OVER (PARTITION BY ddacct,ddctyp ORDER BY dddat6 asc, rowid asc) as rowid_trx
     ,rowid as rowid
from  TMP_SIBS_DI236MBLSG
;

insert into TMP_Result
( 
     ddacct
     ,ddctyp
     ,TglTransaksi 
     ,TglValuta    
     ,Uraian
     ,Debet        
     ,Kredit       
     ,Saldo 
     ,rowid_trx
     ,rowid_uraian
     ,rowid_ddctyp
     ,period
)
select 
      ddacct as ddacct
     ,ddctyp as ddctyp
     ,'' as TglTransaksi 
     ,'' as TglValuta 
     ,'Currency Code : '|| ddctyp as Uraian 
     ,null as Debet 
     ,null as Kredit
     ,null as Saldo
     ,0 as rowid_trx 
     ,0 as rowid_uraian
     ,null as rowid_ddctyp
     ,${hivevar:z_dPeriod} as period
from TMP_DDAWL_ACCTNO where rowid_ddawal = 1
union all
select 
      ddacct as ddacct
     ,ddctyp as ddctyp
     ,'' as TglTransaksi 
     ,'' as TglValuta 
     ,'Beginning Balance' as Uraian 
     ,null as Debet 
     ,null as Kredit
     ,DDAWAL as Saldo
     ,0 as rowid_trx 
     ,1 as rowid_uraian
     ,null as rowid_ddctyp
     ,${hivevar:z_dPeriod} as period
from TMP_DDAWL_ACCTNO where rowid_ddawal = 1
union all
select 
      ddacct as ddacct
     ,ddctyp as ddctyp
     ,TglTransaksi as TglTransaksi 
     ,TglValuta as TglValuta 
     ,Uraian1 as Uraian 
     ,Debet as Debet 
     ,Kredit as Kredit
     ,saldo as Saldo
     ,rowid_trx as rowid_trx
     ,2 as rowid_uraian
     ,null as rowid_ddctyp
     ,${hivevar:z_dPeriod} as period
from TMP_TRX_URAIAN 
union all
select 
     ddacct as ddacct
     ,ddctyp as ddctyp
     ,'' as TglTransaksi 
     ,'' as TglValuta 
     ,Uraian2 as Uraian 
     ,null as Debet 
     ,null as Kredit
     ,null as Saldo
     ,rowid_trx as rowid_trx
     ,3 as rowid_uraian
     ,null as rowid_ddctyp
     ,${hivevar:z_dPeriod} as period
from TMP_TRX_URAIAN
;

insert overwrite table t1_preprocess.detailtrx_DI236MBLSG partition(period)
select ddacct 
     ,ddctyp
     ,TglTransaksi 
     ,TglValuta    
     ,Uraian
     ,Debet        
     ,Kredit       
     ,Saldo 
     ,rowid_trx
     ,rowid_uraian 
     ,case when ddctyp ='IDR' then 0 
          when ddctyp ='USD' then 1
          when ddctyp ='SGD' then 2
          when ddctyp ='JPY' then 3
          when ddctyp ='EUR' then 4 
          when ddctyp ='AUD' then 5
          when ddctyp ='HKD' then 6 
          when ddctyp ='GBP' then 7
          when ddctyp ='CAD' then 8
          when ddctyp ='CHF' then 9
          when ddctyp ='NZD' then 10
          when ddctyp ='CNH' then 11
     end as rowid_ddctyp
     ,period
from TMP_Result
;

----------------------------------------HEADER-------------------------------------------------------------------
drop table if exists TMP_SUM_DI236MBLSG;
create temporary table TMP_SUM_DI236MBLSG
(
      ddacct             decimal(19,0)
     ,ddctyp             string
     ,TotalMutasiDebit   decimal(17,2)
     ,TotalMutasiCredit  decimal(17,2)
)
;
insert into TMP_SUM_DI236MBLSG
(ddacct,ddctyp,TotalMutasiDebit,TotalMutasiCredit)
select 
      ddacct
     ,ddctyp
     ,SUM(xa.DDMDR) as TotalMutasiDebit
     ,SUM(xa.DDMCR) as TotalMutasiCredit
from TMP_SIBS_DI236MBLSG as xa
group by ddacct,ddctyp
;

insert overwrite table t1_preprocess.header_rekeningkoran_DI236MBLSG partition(period)
select 
      xa.ddacct
     ,xa.DDNA1
     ,TRIM(xa.DDNA3) as DDNA3
     ,TRIM(xa.DDNA4) as DDNA4
     ,TRIM(xa.DDNA5) as DDNA5
     ,xa.DDPDES 
     ,xa.DDBRNAM
     ,xa.DDCTYP
     ,SUBSTRING('00000'||xa.ddbr, length('00000'||xa.ddbr) - 4 , 5 ) as Branch
     ,${hivevar:z_dPeriodBOMName} ||' - '|| ${hivevar:z_dPeriodEOMName} as Periode
     ,cast(date_format(${hivevar:z_dPeriodEOM},'dd/MM/yy') as string) as TanggalCetak
     ,'' as BarCode
     ,'A2-N089210001' as TextSamping
     ,date_format(${hivevar:z_dPeriodEOM},'MM/yy')|| '-001/001-' || SUBSTRING('00000'||(cast(xa.ddacct as decimal(19,0)) % 1000), length('00000'||(cast(xa.ddacct as decimal(19,0))% 1000)) - 3 , 4 ) as TextAtas
     ,xa.ODCPNO as FacilityNumber
     ,xa.ODALMT as Plafond 
     ,cast(xa.WOTRATE as string) as Bunga
     ,COALESCE(cast(xa.ODREV6 as string), '') as MasaKredit1
     ,COALESCE(cast(xa.ODEXP6 as string), '') as MasaKredit2
     ,xa.DDBAL as SaldoAkhir
     ,xb.TotalMutasiDebit as TotalMutasiDebit
     ,xb.TotalMutasiCredit as TotalMutasiCredit
     ,OWBAMT as TunggakanBunga
     ,OWDAMT as TunggakanDenda
     ,OWCAMT as TunggakanBiayaLain
     ,OWAMT as TunggakanTotal
     ,case when xa.ODCPNO = '' then 0 else 1 end as PrintFacility
     ,case when xa.OWAMT = 0 then 0 else 1 end as PrintTunggakan
     ,regexp_replace(MCNOTE1,' +',' ')  as MCNOTE1
     ,MCCTYP as MCCTYP
     ,MCEXRT as MCEXRT
     ,MCAMT as MCAMT
     ,MCAMTI as MCAMTI
     ,MCTAMT as MCTAMT
     ,regexp_replace(MCNOTE2,' +',' ') as MCNOTE2
     ,MINMTDX as MINMTDX
     ,MAXMTDX as MAXMTDX
     ,AVGAMTX as AVGAMTX
     ,case when xa.ddctyp ='IDR' then 0 
          when xa.ddctyp ='USD' then 1
          when xa.ddctyp ='SGD' then 2
          when xa.ddctyp ='JPY' then 3
          when xa.ddctyp ='EUR' then 4 
          when xa.ddctyp ='AUD' then 5
          when xa.ddctyp ='HKD' then 6 
          when xa.ddctyp ='GBP' then 7
          when xa.ddctyp ='CAD' then 8
          when xa.ddctyp ='CHF' then 9
          when xa.ddctyp ='NZD' then 10
          when xa.ddctyp ='CNH' then 11
     end as rowid_ddctyp
     ,${hivevar:z_dPeriod}  as period
from TMP_SIBS_DI236MBLSG xa
join TMP_SUM_DI236MBLSG xb
on xa.ddacct = xb.ddacct
and xa.DDCTYP = xb.ddctyp
where xa.rowid_header = 1
;