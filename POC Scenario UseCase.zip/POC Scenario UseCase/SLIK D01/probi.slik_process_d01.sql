create or replace function probi.slik_process_d01
(
     z_pdperiod date
)
returns integer
as
$BODY$
----------------------------------------------------------------------------------------------------------
-- Variable Declaration --
----------------------------------------------------------------------------------------------------------
declare
---- system variable ----
z_cFuncName   character varying;
z_cErrMsg     character varying;
z_cSQLState   character varying;
z_cSQLMsg     character varying;
z_cUser       character varying;
z_cQuery      character varying;
z_cColumnList character varying;

---- procedure variable ----
z_dCurrEOD          date;
z_dCurrEOM          date;
z_dPeriodLastEOM    date;
z_dPeriod           date;
z_dPrevPeriod       date;

z_cSandiLJK         character varying;
z_cFlagDetail       character varying;
z_cBulan            character varying;
z_cTahun            character varying;
z_nProcessId        integer;
z_nJobId            integer;
z_cStatusProcess    character varying;
z_nSubmitterNIK     integer;

--========================================================================================================
BEGIN--FUNCTION--
--========================================================================================================
----------------------------------------------------------------------------------------------------------
-- Variable Assignment --
----------------------------------------------------------------------------------------------------------
z_cFuncName = 'SLIK_Process_D01';

select
 xa.ops_date
from ads.DOPS_Parameters as xa
into
 z_dCurrEOD
;

z_dCurrEOM = DATE_TRUNC('month', z_dCurrEOD)::date - 1;
z_dPeriod = COALESCE(z_pdPeriod, z_dCurrEOM::date);
z_dPrevPeriod = DATE_TRUNC('MONTH', z_dPeriod + '0 MONTH'::interval) - '1 DAY'::interval;
z_dPeriodLastEOM = DATE_TRUNC('month', z_dPeriod)::date - 1;

z_cSandiLJK = '028';
z_cFlagDetail = 'D';
z_cBulan = public.util_right('00' || date_part('month', z_dPeriod)::character varying, 2);
z_cTahun = public.util_right('0000' || date_part('year', z_dPeriod)::character varying, 4);
z_nProcessId = 11;
z_nJobId = 24;
z_cStatusProcess = 'success';
z_nSubmitterNIK = 99999;

----------------------------------------------------------------------------------------------------------
-- Variable Debug --
----------------------------------------------------------------------------------------------------------
raise notice 'z_dCurrEOD        : %', z_dCurrEOD;
raise notice 'z_dCurrEOM        : %', z_dCurrEOM;
raise notice 'z_dPeriod         : %', z_dPeriod;
raise notice 'z_dPeriodLastEOM  : %', z_dPeriodLastEOM;
raise notice 'z_cSandiLJK       : %', z_cSandiLJK;
raise notice 'z_cFlagDetail     : %', z_cFlagDetail;
raise notice 'z_cBulan          : %', z_cBulan;
raise notice 'z_cTahun          : %', z_cTahun;
raise notice 'z_nProcessId      : %', z_nProcessId;
raise notice 'z_nJobId          : %', z_nJobId;
raise notice 'z_cStatusProcess  : %', z_cStatusProcess;
raise notice 'z_nSubmitterNIK   : %', z_nSubmitterNIK;

----------------------------------------------------------------------------------------------------------
-- Preliminary Validation --
----------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------
-- Temporary Procedure Table Declaration --
----------------------------------------------------------------------------------------------------------
z_cErrMsg = public.serene(1, 'A010');

-- TMP_SLIK_F_D01 --
perform public.fnDropTemporaryTable('TMP_SLIK_F_D01');
create temporary table TMP_SLIK_F_D01
(
     Period                     date
    ,FlagDetail                 character varying
    ,CIF                        character varying
    ,JenisIdentitas             character varying
    ,NIKPassport                character varying
    ,NamaSesuaiIdentitas        character varying
    ,NamaLengkap                character varying
    ,KodeStatusGelarDebitur     character varying
    ,JenisKelamin               character varying
    ,TempatLahirKTP             character varying
    ,TanggalLahir               character varying -- date
    ,NPWP                       character varying
    ,Alamat                     character varying
    ,Kelurahan                  character varying
    ,Kecamatan                  character varying
    ,KodeDATIII                 character varying
    ,KodePos                    character varying
    ,Telepon                    character varying
    ,NomorTeleponGenggam        character varying
    ,AlamatEmail                character varying
    ,KodeNegara                 character varying
    ,KodePekerjaan              character varying
    ,TempatBekerja              character varying
    ,KodeBidangUsaha            character varying
    ,AlamatTempatBekerja        character varying
    ,PenghasilanKotorPerTahun   character varying -- numeric
    ,KodeSumberPenghasilan      character varying
    ,JumlahTanggungan           character varying -- numeric
    ,KodeHubungandenganLJK      character varying
    ,KodeGolonganDebitur        character varying
    ,StatusPerkawinanDebitur    character varying
    ,NIKPassportPasangan        character varying
    ,NamaPasangan               character varying
    ,TanggalLahirPasangan       character varying -- date
    ,PerjanjianPisahHarta       character varying
    ,MelanggarBM                character varying
    ,MelampauiBM                character varying
    ,NamaGadisIbuKandung        character varying
    ,KodeKantorCabang           character varying
    ,OperationData              character varying
    ,TahunData                  character varying
    ,BulanData                  character varying
    ,SandiLJK                   character varying
    ,KodeJenisLJK               character varying
    ,CreateDate                 character varying
    ,CIFOri                     character varying
    ,insertquery                character varying
    ,updatequery                character varying default ''
    ,deletequery                character varying
)
distributed randomly;

z_cErrMsg = public.serene(1, 'A020');

perform public.fnDropTemporaryTable('tmp_cif_hilang');
create temporary table tmp_cif_hilang
(
    cif                      character varying
    ,kodekantorcabang   character varying
)
distributed randomly;

z_cErrMsg = public.serene(1, 'A030');

perform public.fnDropTemporaryTable('tmp_slik_f_d01_reinsert');
create temporary table tmp_slik_f_d01_reinsert
(
     period                   date
    ,flagdetail               character varying
    ,cif                      character varying(40)
    ,jenisidentitas           character varying
    ,nikpassport              character varying
    ,namasesuaiidentitas      character varying
    ,namalengkap              character varying
    ,kodestatusgelardebitur   character varying
    ,jeniskelamin             character varying
    ,tempatlahirktp           character varying
    ,tanggallahir             character varying
    ,npwp                     character varying
    ,alamat                   character varying
    ,kelurahan                character varying
    ,kecamatan                character varying
    ,kodedatiii               character varying
    ,kodepos                  character varying
    ,telepon                  character varying
    ,nomortelepongenggam      character varying
    ,alamatemail              character varying
    ,kodenegara               character varying
    ,kodepekerjaan            character varying
    ,tempatbekerja            character varying
    ,kodebidangusaha          character varying
    ,alamattempatbekerja      character varying
    ,penghasilankotorpertahun character varying
    ,kodesumberpenghasilan    character varying
    ,jumlahtanggungan         character varying
    ,kodehubungandenganljk    character varying
    ,kodegolongandebitur      character varying
    ,statusperkawinandebitur  character varying
    ,nikpassportpasangan      character varying
    ,namapasangan             character varying
    ,tanggallahirpasangan     character varying
    ,perjanjianpisahharta     character varying
    ,melanggarbm              character varying
    ,melampauibm              character varying
    ,namagadisibukandung      character varying
    ,kodekantorcabang         character varying
    ,operationdata            character varying
    ,tahundata                character varying
    ,bulandata                character varying
    ,sandiljk                 character varying
    ,kodejenisljk             character varying
    ,createdate               character varying
    ,insertquery                character varying
    ,updatequery                character varying default ''
    ,deletequery                character varying
)
distributed randomly;

----------------------------------------------------------------------------------------------------------
-- Temporary Source Table Declaration --
----------------------------------------------------------------------------------------------------------
z_cErrMsg = public.serene(1, 'B010');

-- TMP_SLIK_CustomerMaster --
perform public.fnDropTemporaryTable('TMP_SLIK_CustomerMaster');
create temporary table TMP_SLIK_CustomerMaster
(
     CIF                character varying
    ,CustomerType       character varying -- CompanyFlag
    ,PeriodPelaporan    date
    ,CIFOri             character varying
    ,KodeKantorCabang   character varying
    ,statussyariah      character varying
)
distributed randomly;

z_cErrMsg = public.serene(1, 'B020');

insert into TMP_SLIK_CustomerMaster
(
     CIF
    ,CustomerType -- CompanyFlag
    ,PeriodPelaporan
    ,CIFOri
    ,KodeKantorCabang
    ,statussyariah
)
select distinct
     xa.CIF
    ,xa.CustomerType -- CompanyFlag
    ,xa.PeriodPelaporan
    ,xa.CIFOri as CIFOri
    ,xa.KodeKantorCabang as KodeKantorCabang
    ,xa.statussyariah as statussyariah
from probi.slik_customermaster as xa
where xa.PeriodPelaporan = z_dPeriod
and xa.statussyariah is not null
;

z_cErrMsg = public.serene(1, 'B030');

-- TMP_SLIK_CustomerDetail --
perform public.fnDropTemporaryTable('TMP_SLIK_CustomerDetail');
create temporary table TMP_SLIK_CustomerDetail
(
     Period                     date
    ,CustomerType               character varying
    ,CIF                        character varying
    ,OfficeCIF                  character varying
    ,CIFName                    character varying
    ,NamaLengkap                character varying
    ,Telepon                    character varying
    ,NomorTeleponGenggam        character varying
    ,AlamatEmail                character varying
    ,Alamat                     character varying
    ,Kelurahan                  character varying
    ,Kecamatan                  character varying
    ,KodeDATIII                 character varying
    ,KodePos                    character varying
    ,KodeNegara                 character varying
    ,KodePekerjaan              character varying -- KodeBidangUsaha
    ,MelanggarBM                character varying
    ,MelampauiBM                character varying
    ,KodeBidangUsaha            character varying -- SektorEkonomi
    ,IdNumber                   character varying
    ,IDType                     character varying
    ,FlagWNIWNA                 character varying
    ,KodeStatusGelarDebitur     character varying
    ,JenisKelamin               character varying
    ,TempatLahirKTP             character varying
    ,TanggalLahir               date
    ,NPWP                       character varying
    ,TempatBekerja              character varying
    ,AlamatTempatBekerja        character varying
    ,PenghasilanKotorPerTahun   numeric
    ,KodeSumberPenghasilan      character varying
    ,KodeHubungandenganLJK      character varying
    ,KodeGolonganDebitur        character varying
    ,StatusPerkawinanDebitur    character varying
    ,NamaGadisIbuKandung        character varying
    ,KodeJenisBadanUsaha        character varying
    ,CIFOri                     character varying
    ,kodekantorcabang               character varying
    ,gopublic                       character varying
    ,idgroupdebitur                 numeric(10,0)
    ,namagroupdebitur               character varying
    ,noaktependirian                character varying
    ,noakteperubahanterakhir        character varying
    ,peringkatdebitur               character varying
    ,lembagapemeringkat             character varying
    ,tanggalpemeringkatan           date
    ,nikpassportpasangan            character varying
    ,namapasangan                   character varying
    ,tanggallahirpasangan           date
    ,perjanjianpisahharta           character varying
    ,jumlahtanggungan               integer
    ,tanggalaktependirian           date
    ,tanggalakteperubahanterakhir   date
)
distributed randomly;

z_cErrMsg = public.serene(1, 'B040');

insert into TMP_SLIK_CustomerDetail
(
     Period
    ,CIF
    ,OfficeCIF
    ,CIFName
    ,NamaLengkap
    ,Telepon
    ,NomorTeleponGenggam
    ,AlamatEmail
    ,Alamat
    ,Kelurahan
    ,Kecamatan
    ,KodeDATIII
    ,KodePos
    ,KodeNegara
    ,KodePekerjaan -- KodeBidangUsaha
    ,MelanggarBM
    ,MelampauiBM
    ,KodeBidangUsaha -- SektorEkonomi
    ,IdNumber
    ,IDType
    ,FlagWNIWNA
    ,KodeStatusGelarDebitur
    ,JenisKelamin
    ,TempatLahirKTP
    ,TanggalLahir
    ,NPWP
    ,TempatBekerja
    ,AlamatTempatBekerja
    ,PenghasilanKotorPerTahun
    ,KodeSumberPenghasilan
    ,KodeHubungandenganLJK
    ,KodeGolonganDebitur
    ,StatusPerkawinanDebitur
    ,NamaGadisIbuKandung
    ,KodeJenisBadanUsaha
    ,CIFOri
    ,kodekantorcabang
    ,gopublic
    ,idgroupdebitur
    ,namagroupdebitur
    ,noaktependirian
    ,noakteperubahanterakhir
    ,peringkatdebitur
    ,lembagapemeringkat
    ,tanggalpemeringkatan
    ,nikpassportpasangan
    ,namapasangan
    ,tanggallahirpasangan
    ,perjanjianpisahharta
    ,jumlahtanggungan
    ,tanggalaktependirian
    ,tanggalakteperubahanterakhir
)
select distinct
     xa.Period
    ,xa.CIF
    ,xa.OfficeCIF
    ,xa.CIFName
    ,xa.NamaLengkap
    ,xa.Telepon
    ,xa.NomorTeleponGenggam
    ,xa.AlamatEmail
    ,xa.Alamat
    ,xa.Kelurahan
    ,xa.Kecamatan
    ,xa.KodeDATIII
    ,xa.KodePos
    ,xa.KodeNegara
    ,xa.KodePekerjaan -- KodeBidangUsaha
    ,xa.MelanggarBM
    ,xa.MelampauiBM
    ,xa.KodeBidangUsaha -- SektorEkonomi
    ,xa.IdNumber
    ,xa.IDType
    ,xa.FlagWNIWNA
    ,xa.KodeStatusGelarDebitur
    ,xa.JenisKelamin
    ,xa.TempatLahirKTP
    ,xa.TanggalLahir
    ,xa.NPWP
    ,xa.TempatBekerja
    ,xa.AlamatTempatBekerja
    ,xa.PenghasilanKotorPerTahun
    ,xa.KodeSumberPenghasilan
    ,xa.KodeHubungandenganLJK
    ,xa.KodeGolonganDebitur
    ,xa.StatusPerkawinanDebitur
    ,xa.NamaGadisIbuKandung
    ,xa.KodeJenisBadanUsaha
    ,xa.CIFOri
    ,xa.kodekantorcabang as kodekantorcabang
    ,xa.gopublic as gopublic
    ,xa.idgroupdebitur as idgroupdebitur
    ,xa.namagroupdebitur as namagroupdebitur
    ,xa.noaktependirian as noaktependirian
    ,xa.noakteperubahanterakhir as noakteperubahanterakhir
    ,xa.peringkatdebitur as peringkatdebitur
    ,xa.lembagapemeringkat as lembagapemeringkat
    ,xa.tanggalpemeringkatan as tanggalpemeringkatan
    ,xa.nikpassportpasangan as nikpassportpasangan
    ,xa.namapasangan as namapasangan
    ,xa.tanggallahirpasangan as tanggallahirpasangan
    ,xa.perjanjianpisahharta as perjanjianpisahharta
    ,xa.jumlahtanggungan as jumlahtanggungan
    ,xa.tanggalaktependirian as tanggalaktependirian
    ,xa.tanggalakteperubahanterakhir as tanggalakteperubahanterakhir
from probi.slik_customerdetail as xa
where xa.Period = z_dPeriod
;

z_cErrMsg = public.serene(1, 'B050');

-- TMP_SLIK_F_D01_Prev --
perform public.fnDropTemporaryTable('TMP_SLIK_F_D01_Prev');
create temporary table TMP_SLIK_F_D01_Prev
(
     Period                     date
    ,FlagDetail                 character varying
    ,CIF                        character varying
    ,JenisIdentitas             character varying
    ,NIKPassport                character varying
    ,NamaSesuaiIdentitas        character varying
    ,NamaLengkap                character varying
    ,KodeStatusGelarDebitur     character varying
    ,JenisKelamin               character varying
    ,TempatLahirKTP             character varying
    ,TanggalLahir               character varying -- date
    ,NPWP                       character varying
    ,Alamat                     character varying
    ,Kelurahan                  character varying
    ,Kecamatan                  character varying
    ,KodeDATIII                 character varying
    ,KodePos                    character varying
    ,Telepon                    character varying
    ,NomorTeleponGenggam        character varying
    ,AlamatEmail                character varying
    ,KodeNegara                 character varying
    ,KodePekerjaan              character varying
    ,TempatBekerja              character varying
    ,KodeBidangUsaha            character varying
    ,AlamatTempatBekerja        character varying
    ,PenghasilanKotorPerTahun   character varying -- numeric
    ,KodeSumberPenghasilan      character varying
    ,JumlahTanggungan           character varying -- numeric
    ,KodeHubungandenganLJK      character varying
    ,KodeGolonganDebitur        character varying
    ,StatusPerkawinanDebitur    character varying
    ,NIKPassportPasangan        character varying
    ,NamaPasangan               character varying
    ,TanggalLahirPasangan       character varying -- date
    ,PerjanjianPisahHarta       character varying
    ,MelanggarBM                character varying
    ,MelampauiBM                character varying
    ,NamaGadisIbuKandung        character varying
    ,KodeKantorCabang           character varying
    ,OperationData              character varying
    ,TahunData                  character varying
    ,BulanData                  character varying
    ,SandiLJK                   character varying
    ,KodeJenisLJK               character varying
    ,CreateDate                 character varying
)
distributed randomly;

z_cErrMsg = public.serene(1, 'B060');

insert into TMP_SLIK_F_D01_Prev
(
     Period
    ,FlagDetail
    ,CIF
    ,JenisIdentitas
    ,NIKPassport
    ,NamaSesuaiIdentitas
    ,NamaLengkap
    ,KodeStatusGelarDebitur
    ,JenisKelamin
    ,TempatLahirKTP
    ,TanggalLahir
    ,NPWP
    ,Alamat
    ,Kelurahan
    ,Kecamatan
    ,KodeDATIII
    ,KodePos
    ,Telepon
    ,NomorTeleponGenggam
    ,AlamatEmail
    ,KodeNegara
    ,KodePekerjaan
    ,TempatBekerja
    ,KodeBidangUsaha
    ,AlamatTempatBekerja
    ,PenghasilanKotorPerTahun
    ,KodeSumberPenghasilan
    ,JumlahTanggungan
    ,KodeHubungandenganLJK
    ,KodeGolonganDebitur
    ,StatusPerkawinanDebitur
    ,NIKPassportPasangan
    ,NamaPasangan
    ,TanggalLahirPasangan
    ,PerjanjianPisahHarta
    ,MelanggarBM
    ,MelampauiBM
    ,NamaGadisIbuKandung
    ,KodeKantorCabang
    ,OperationData
    ,TahunData
    ,BulanData
    ,SandiLJK
    ,KodeJenisLJK
    ,CreateDate
)
select distinct
     xa.Period
    ,xa.FlagDetail
    ,xa.CIF
    ,xa.JenisIdentitas
    ,xa.NIKPassport
    ,xa.NamaSesuaiIdentitas
    ,xa.NamaLengkap
    ,xa.KodeStatusGelarDebitur
    ,xa.JenisKelamin
    ,xa.TempatLahirKTP
    ,xa.TanggalLahir
    ,xa.NPWP
    ,xa.Alamat
    ,xa.Kelurahan
    ,xa.Kecamatan
    ,xa.KodeDATIII
    ,xa.KodePos
    ,xa.Telepon
    ,xa.NomorTeleponGenggam
    ,xa.AlamatEmail
    ,xa.KodeNegara
    ,xa.KodePekerjaan
    ,xa.TempatBekerja
    ,xa.KodeBidangUsaha
    ,xa.AlamatTempatBekerja
    ,xa.PenghasilanKotorPerTahun
    ,xa.KodeSumberPenghasilan
    ,xa.JumlahTanggungan
    ,xa.KodeHubungandenganLJK
    ,xa.KodeGolonganDebitur
    ,xa.StatusPerkawinanDebitur
    ,xa.NIKPassportPasangan
    ,xa.NamaPasangan
    ,xa.TanggalLahirPasangan
    ,xa.PerjanjianPisahHarta
    ,xa.MelanggarBM
    ,xa.MelampauiBM
    ,xa.NamaGadisIbuKandung
    ,xa.KodeKantorCabang
    ,xa.OperationData
    ,xa.TahunData
    ,xa.BulanData
    ,xa.SandiLJK
    ,xa.KodeJenisLJK
    ,xa.CreateDate
from probi.slik_f_d01 as xa
where xa.Period = z_dPeriodLastEOM
;

----------------------------------------------------------------------------------------------------------
-- Main Process --
----------------------------------------------------------------------------------------------------------
z_cErrMsg = public.serene(1, 'C010');

-- insert data ke form d01

insert into TMP_SLIK_F_D01
(
     Period
    ,FlagDetail
    ,CIF
    ,JenisIdentitas
    ,NIKPassport
    ,NamaSesuaiIdentitas
    ,NamaLengkap
    ,KodeStatusGelarDebitur
    ,JenisKelamin
    ,TempatLahirKTP
    ,TanggalLahir
    ,NPWP
    ,Alamat
    ,Kelurahan
    ,Kecamatan
    ,KodeDATIII
    ,KodePos
    ,Telepon
    ,NomorTeleponGenggam
    ,AlamatEmail
    ,KodeNegara
    ,KodePekerjaan
    ,TempatBekerja
    ,KodeBidangUsaha
    ,AlamatTempatBekerja
    ,PenghasilanKotorPerTahun
    ,KodeSumberPenghasilan
    ,JumlahTanggungan
    ,KodeHubungandenganLJK
    ,KodeGolonganDebitur
    ,StatusPerkawinanDebitur
    ,NIKPassportPasangan
    ,NamaPasangan
    ,TanggalLahirPasangan
    ,PerjanjianPisahHarta
    ,MelanggarBM
    ,MelampauiBM
    ,NamaGadisIbuKandung
    ,KodeKantorCabang
    ,OperationData
    ,TahunData
    ,BulanData
    ,SandiLJK
    ,KodeJenisLJK
    ,CreateDate
    ,CIFOri
    ,insertquery
)
select distinct
     z_dPeriod as Period
    ,z_cFlagDetail as FlagDetail -- Header = H, Detail = D
    ,COALESCE(xa.CIF, '') as CIF
    ,COALESCE(xa.IDType, '') as JenisIdentitas
    ,case
         when xa.IDType in ('KTP', 'KTPS', '1') then COALESCE(TRIM(regexp_replace(xa.IdNumber, '[^0-9]', '', 'g')), '')
         when xa.IDType in ('PP', '2') then COALESCE(TRIM(regexp_replace(xa.IdNumber, '[^0-9A-Za-z]', '', 'g')), '')
         else COALESCE(TRIM(regexp_replace(xa.IdNumber, '[^0-9A-Za-z]', '', 'g')), '')
     end as NIKPassport
    ,COALESCE(xa.CIFName, '') as NamaSesuaiIdentitas
    ,COALESCE(xa.NamaLengkap, '') as NamaLengkap
    ,COALESCE(xa.KodeStatusGelarDebitur, '') as KodeStatusGelarDebitur -- A = SD, B = SMP, C = SMA, D = Diploma, E = S1, F = S2, G = S3, X = Taman Bermain/PAUD, Y = Taman Kanak-Kanak, Z   = Lainnya
    ,COALESCE(xa.JenisKelamin, '') as JenisKelamin -- Male = M, Female = F
    ,COALESCE(xa.TempatLahirKTP, '') as TempatLahirKTP
    ,probi.fnslik_chardate(xa.TanggalLahir) as TanggalLahir
    ,COALESCE(TRIM(regexp_replace(xa.NPWP, '[^0-9]', '', 'g')), '') as NPWP
    ,COALESCE(xa.Alamat, '') as Alamat
    ,COALESCE(xa.Kelurahan, '') as Kelurahan
    ,COALESCE(xa.Kecamatan, '') as Kecamatan
    ,COALESCE(xa.KodeDATIII, '') as KodeDATIII
    ,COALESCE(xa.KodePos, '') as KodePos
    ,COALESCE(xa.Telepon, '0') as Telepon
    ,COALESCE(xa.NomorTeleponGenggam, '') as NomorTeleponGenggam
    ,COALESCE(xa.AlamatEmail, '') as AlamatEmail
    ,COALESCE(xa.KodeNegara, '') as KodeNegara
    ,COALESCE(xa.KodePekerjaan, '') as KodePekerjaan
    ,COALESCE(xa.TempatBekerja, 'NA') as TempatBekerja
    ,COALESCE(xa.KodeBidangUsaha, '') as KodeBidangUsaha
    ,COALESCE(xa.AlamatTempatBekerja, '') as AlamatTempatBekerja
    ,probi.fnslik_charnumeric(xa.PenghasilanKotorPerTahun) as PenghasilanKotorPerTahun
    ,COALESCE(xa.KodeSumberPenghasilan::character varying, '') as KodeSumberPenghasilan
    -- ,'' as JumlahTanggungan
    ,case
         when COALESCE(xa.jumlahtanggungan, 0) = 0 then '0'
         else COALESCE(xa.jumlahtanggungan, 0)
     end as JumlahTanggungan
    ,COALESCE(xa.KodeHubungandenganLJK, '9900') as KodeHubungandenganLJK
    ,COALESCE(xa.KodeGolonganDebitur, '') as KodeGolonganDebitur
    ,COALESCE(xa.StatusPerkawinanDebitur, '') as StatusPerkawinanDebitur -- Kawin (A) = 1, Belum Kawin (B) = 2, Cerai (C) = 3
    ,COALESCE(xa.nikpassportpasangan, '') as NIKPassportPasangan
    ,COALESCE(xa.namapasangan, '') as NamaPasangan
    ,probi.fnslik_chardate(xa.tanggallahirpasangan) as TanggalLahirPasangan
    ,COALESCE(xa.perjanjianpisahharta, '') as PerjanjianPisahHarta
    ,COALESCE(xa.MelanggarBM, 'T') as MelanggarBM
    ,COALESCE(xa.MelampauiBM, 'T') as MelampauiBM
    ,COALESCE(xa.NamaGadisIbuKandung, '') as NamaGadisIbuKandung
    -- ,'' as KodeKantorCabang
    ,xa.kodekantorcabang as KodeKantorCabang
    ,'' as OperationData
    ,z_cTahun as TahunData
    ,z_cBulan as BulanData
    ,z_cSandiLJK as SandiLJK
    -- ,'' as KodeJenisLJK
    ,case
         when xb.statussyariah = 'T' then '0101'
         else '0102'
     end as KodeJenisLJK
    ,to_char(current_timestamp, 'yyyymmdd hh:mi:ss')::character varying as CreateDate
    ,COALESCE(xa.CIFOri, '') as CIFOri
    ,'IQ-01' as insertquery
from TMP_SLIK_CustomerDetail as xa
inner join TMP_SLIK_CustomerMaster as xb
    on xb.CIF = xa.CIF
    and xb.CustomerType = 'A' -- CompanyFlag
;

z_cErrMsg = public.serene(1, 'C020');

-- update JenisIdentitas dari probi. regulatory_parameterlist

update TMP_SLIK_F_D01 as xz
set
     JenisIdentitas = xa.slikvalue
    ,updatequery = xz.updatequery || 'UQ-01#'
from probi.regulatory_parameterlist as xa
where xa.mappingcode = 'jenisidentitas'
and xz.JenisIdentitas = xa.hostvalue
;

z_cErrMsg = public.serene(1, 'C030');

-- update KodeGolonganDebitur dari probi. regulatory_parameterlist

update TMP_SLIK_F_D01 as xz
set
     KodeGolonganDebitur = xa.slikvalue
    ,updatequery = xz.updatequery || 'UQ-02#'
from probi.regulatory_parameterlist as xa
where xa.mappingcode = 'kodegolongandebitur'
and xz.KodeGolonganDebitur = xa.hostvalue
;

z_cErrMsg = public.serene(1, 'C040');

-- update StatusPerkawinanDebitur dari probi. regulatory_parameterlist

update TMP_SLIK_F_D01 as xz
set
     StatusPerkawinanDebitur = xa.slikvalue
    ,updatequery = xz.updatequery || 'UQ-03#'
from probi.regulatory_parameterlist as xa
where xa.mappingcode = 'statusperkawinandebitur'
and xz.StatusPerkawinanDebitur = xa.hostvalue
;

z_cErrMsg = public.serene(1, 'C050');

-- update KodeStatusGelarDebitur dari probi. regulatory_parameterlist

update TMP_SLIK_F_D01 as xz
set
     KodeStatusGelarDebitur = xa.slikvalue
    ,updatequery = xz.updatequery || 'UQ-04#'
from probi.regulatory_parameterlist as xa
where xa.mappingcode = 'kodestatusgelardebitur'
and xz.KodeStatusGelarDebitur = xa.hostvalue
;

z_cErrMsg = public.serene(1, 'C060');

-- update kodestatusgelardebitur menjadi 00 untuk yang kosong

update TMP_SLIK_F_D01 as xz
set
     KodeStatusGelarDebitur = '00'
    ,updatequery = xz.updatequery || 'UQ-05#'
where trim(coalesce(KodeStatusGelarDebitur, '')) = ''
;

z_cErrMsg = public.serene(1, 'C070');

-- update JenisKelamin dari probi. regulatory_parameterlist

update TMP_SLIK_F_D01 as xz
set
     JenisKelamin = xa.slikvalue
    ,updatequery = xz.updatequery || 'UQ-06#'
from probi.regulatory_parameterlist as xa
where xa.mappingcode = 'jeniskelamin'
and xz.JenisKelamin = xa.hostvalue
;

z_cErrMsg = public.serene(1, 'C080');

-- update KodePekerjaan dari probi. regulatory_parameterlist

update TMP_SLIK_F_D01 as xz
set
     KodePekerjaan = xa.slikvalue
    ,updatequery = xz.updatequery || 'UQ-07#'
from probi.regulatory_parameterlist as xa
where xa.mappingcode = 'pekerjaan'
and xz.KodePekerjaan = xa.hostvalue
;

z_cErrMsg = public.serene(1, 'C090');

-- update KodeHubungandenganLJK dari probi. regulatory_parameterlist

update TMP_SLIK_F_D01 as xz
set
     KodeHubungandenganLJK = xa.slikvalue
    ,updatequery = xz.updatequery || 'UQ-08#'
from probi.regulatory_parameterlist as xa
where xa.mappingcode = 'hubungandenganbank'
and xz.KodeHubungandenganLJK = xa.hostvalue
;

z_cErrMsg = public.serene(1, 'C100');

-- update KodeDATIII dari probi. regulatory_parameterlist

update TMP_SLIK_F_D01 as xz
set
     KodeDATIII = xa.slikvalue
    ,updatequery = xz.updatequery || 'UQ-09#'
from probi.regulatory_parameterlist as xa
where xa.mappingcode = 'dati2'
and xz.KodeDATIII = xa.hostvalue
;

z_cErrMsg = public.serene(1, 'C110');

-- update KodeBidangUsaha dari probi. regulatory_parameterlist

update TMP_SLIK_F_D01 as xz
set
     KodeBidangUsaha = xa.slikvalue
    ,updatequery = xz.updatequery || 'UQ-10#'
from probi.regulatory_parameterlist as xa
where xa.mappingcode = 'sektorekonomi'
and xz.KodeBidangUsaha = xa.hostvalue
and xa.isactive = 'A'
;

z_cErrMsg = public.serene(1, 'C120');

-- update KodeNegara dari probi. regulatory_parameterlist

update TMP_SLIK_F_D01 as xz
set
     KodeNegara = xa.slikvalue
    ,updatequery = xz.updatequery || 'UQ-11#'
from probi.regulatory_parameterlist as xa
where xa.mappingcode = 'negaradomisili'
and xz.KodeNegara = xa.hostvalue
;

z_cErrMsg = public.serene(1, 'C160');

-- update PerjanjianPisahHarta

update TMP_SLIK_F_D01 as xz
set
     PerjanjianPisahHarta = 'T'
    ,updatequery = xz.updatequery || 'UQ-12#'
where COALESCE(xz.PerjanjianPisahHarta, '') = ''
;

z_cErrMsg = public.serene(1, 'C180');

-- update OperationData = C di TMP_SLIK_F_D01 yang datanya baru dan tidak ada di TMP_SLIK_F_D01_Prev

update TMP_SLIK_F_D01 as xz
set
     OperationData = 'C'
    ,updatequery = xz.updatequery || 'UQ-13#'
from TMP_SLIK_F_D01 as xa
left join TMP_SLIK_F_D01_Prev as xb
    on TRIM(xb.CIF) = TRIM(xa.CIF)
    -- and xb.kodekantorcabang = xa.kodekantorcabang
where TRIM(xa.CIF) = TRIM(xz.CIF)
and xb.CIF is NULL
;

z_cErrMsg = public.serene(1, 'C190');

-- update OperationData = U di TMP_SLIK_F_D01 yang salah satu datanya mengalami perubahan data dari TMP_SLIK_F_D01_Prev

update TMP_SLIK_F_D01 as xz
set
     OperationData = 'U'
    ,updatequery = xz.updatequery || 'UQ-14#'
from TMP_SLIK_F_D01 as xa
inner join TMP_SLIK_F_D01_Prev as xb
    on TRIM(xb.CIF) = TRIM(xa.CIF)
    -- and xb.kodekantorcabang = xa.kodekantorcabang
    and
    (
        TRIM(xb.FlagDetail) <> TRIM(xa.FlagDetail) or
        TRIM(xb.JenisIdentitas) <> TRIM(xa.JenisIdentitas) or
        TRIM(xb.NIKPassport) <> TRIM(xa.NIKPassport) or
        TRIM(xb.NamaSesuaiIdentitas) <> TRIM(xa.NamaSesuaiIdentitas) or
        TRIM(xb.NamaLengkap) <> TRIM(xa.NamaLengkap) or
        TRIM(xb.KodeStatusGelarDebitur) <> TRIM(xa.KodeStatusGelarDebitur) or
        TRIM(xb.JenisKelamin) <> TRIM(xa.JenisKelamin) or
        TRIM(xb.TempatLahirKTP) <> TRIM(xa.TempatLahirKTP) or
        TRIM(xb.TanggalLahir) <> TRIM(xa.TanggalLahir) or
        TRIM(xb.NPWP) <> TRIM(xa.NPWP) or
        TRIM(xb.Alamat) <> TRIM(xa.Alamat) or
        TRIM(xb.Kelurahan) <> TRIM(xa.Kelurahan) or
        TRIM(xb.Kecamatan) <> TRIM(xa.Kecamatan) or
        TRIM(xb.KodeDATIII) <> TRIM(xa.KodeDATIII) or
        TRIM(xb.KodePos) <> TRIM(xa.KodePos) or
        TRIM(xb.Telepon) <> TRIM(xa.Telepon) or
        TRIM(xb.NomorTeleponGenggam) <> TRIM(xa.NomorTeleponGenggam) or
        TRIM(xb.AlamatEmail) <> TRIM(xa.AlamatEmail) or
        TRIM(xb.KodeNegara) <> TRIM(xa.KodeNegara) or
        TRIM(xb.KodePekerjaan) <> TRIM(xa.KodePekerjaan) or
        TRIM(xb.TempatBekerja) <> TRIM(xa.TempatBekerja) or
        TRIM(xb.KodeBidangUsaha) <> TRIM(xa.KodeBidangUsaha) or
        TRIM(xb.AlamatTempatBekerja) <> TRIM(xa.AlamatTempatBekerja) or
        TRIM(xb.PenghasilanKotorPerTahun) <> TRIM(xa.PenghasilanKotorPerTahun) or
        TRIM(xb.KodeSumberPenghasilan) <> TRIM(xa.KodeSumberPenghasilan) or
        TRIM(xb.JumlahTanggungan) <> TRIM(xa.JumlahTanggungan) or
        TRIM(xb.KodeHubungandenganLJK) <> TRIM(xa.KodeHubungandenganLJK) or
        TRIM(xb.KodeGolonganDebitur) <> TRIM(xa.KodeGolonganDebitur) or
        TRIM(xb.StatusPerkawinanDebitur) <> TRIM(xa.StatusPerkawinanDebitur) or
        TRIM(xb.NIKPassportPasangan) <> TRIM(xa.NIKPassportPasangan) or
        TRIM(xb.NamaPasangan) <> TRIM(xa.NamaPasangan) or
        TRIM(xb.TanggalLahirPasangan) <> TRIM(xa.TanggalLahirPasangan) or
        TRIM(xb.PerjanjianPisahHarta) <> TRIM(xa.PerjanjianPisahHarta) or
        TRIM(xb.MelanggarBM) <> TRIM(xa.MelanggarBM) or
        TRIM(xb.MelampauiBM) <> TRIM(xa.MelampauiBM) or
        -- TRIM(xb.NamaGadisIbuKandung) <> TRIM(xa.NamaGadisIbuKandung) or
        -- TRIM(xb.KodeKantorCabang) <> TRIM(xa.KodeKantorCabang)
        TRIM(xb.NamaGadisIbuKandung) <> TRIM(xa.NamaGadisIbuKandung)
    )
where TRIM(xa.CIF) = TRIM(xz.CIF)
;

z_cErrMsg = public.serene(1, 'C200');

-- update OperationData = N di TMP_SLIK_F_D01 yang datanya tidak mengalami perubahan data dari TMP_SLIK_F_D01_Prev

update TMP_SLIK_F_D01 as xz
set
     OperationData = 'N'
    ,updatequery = xz.updatequery || 'UQ-15#'
from TMP_SLIK_F_D01 as xa
inner join TMP_SLIK_F_D01_Prev as xb
    on TRIM(xb.CIF) = TRIM(xa.CIF)
    and
    (
        TRIM(xb.FlagDetail) = TRIM(xa.FlagDetail) and
        TRIM(xb.JenisIdentitas) = TRIM(xa.JenisIdentitas) and
        TRIM(xb.NIKPassport) = TRIM(xa.NIKPassport) and
        TRIM(xb.NamaSesuaiIdentitas) = TRIM(xa.NamaSesuaiIdentitas) and
        TRIM(xb.NamaLengkap) = TRIM(xa.NamaLengkap) and
        TRIM(xb.KodeStatusGelarDebitur) = TRIM(xa.KodeStatusGelarDebitur) and
        TRIM(xb.JenisKelamin) = TRIM(xa.JenisKelamin) and
        TRIM(xb.TempatLahirKTP) = TRIM(xa.TempatLahirKTP) and
        TRIM(xb.TanggalLahir) = TRIM(xa.TanggalLahir) and
        TRIM(xb.NPWP) = TRIM(xa.NPWP) and
        TRIM(xb.Alamat) = TRIM(xa.Alamat) and
        TRIM(xb.Kelurahan) = TRIM(xa.Kelurahan) and
        TRIM(xb.Kecamatan) = TRIM(xa.Kecamatan) and
        TRIM(xb.KodeDATIII) = TRIM(xa.KodeDATIII) and
        TRIM(xb.KodePos) = TRIM(xa.KodePos) and
        TRIM(xb.Telepon) = TRIM(xa.Telepon) and
        TRIM(xb.NomorTeleponGenggam) = TRIM(xa.NomorTeleponGenggam) and
        TRIM(xb.AlamatEmail) = TRIM(xa.AlamatEmail) and
        TRIM(xb.KodeNegara) = TRIM(xa.KodeNegara) and
        TRIM(xb.KodePekerjaan) = TRIM(xa.KodePekerjaan) and
        TRIM(xb.TempatBekerja) = TRIM(xa.TempatBekerja) and
        TRIM(xb.KodeBidangUsaha) = TRIM(xa.KodeBidangUsaha) and
        TRIM(xb.AlamatTempatBekerja) = TRIM(xa.AlamatTempatBekerja) and
        TRIM(xb.PenghasilanKotorPerTahun) = TRIM(xa.PenghasilanKotorPerTahun) and
        TRIM(xb.KodeSumberPenghasilan) = TRIM(xa.KodeSumberPenghasilan) and
        TRIM(xb.JumlahTanggungan) = TRIM(xa.JumlahTanggungan) and
        TRIM(xb.KodeHubungandenganLJK) = TRIM(xa.KodeHubungandenganLJK) and
        TRIM(xb.KodeGolonganDebitur) = TRIM(xa.KodeGolonganDebitur) and
        TRIM(xb.StatusPerkawinanDebitur) = TRIM(xa.StatusPerkawinanDebitur) and
        TRIM(xb.NIKPassportPasangan) = TRIM(xa.NIKPassportPasangan) and
        TRIM(xb.NamaPasangan) = TRIM(xa.NamaPasangan) and
        TRIM(xb.TanggalLahirPasangan) = TRIM(xa.TanggalLahirPasangan) and
        TRIM(xb.PerjanjianPisahHarta) = TRIM(xa.PerjanjianPisahHarta) and
        TRIM(xb.MelanggarBM) = TRIM(xa.MelanggarBM) and
        TRIM(xb.MelampauiBM) = TRIM(xa.MelampauiBM) and
        -- TRIM(xb.NamaGadisIbuKandung) = TRIM(xa.NamaGadisIbuKandung) and
        -- TRIM(xb.KodeKantorCabang) = TRIM(xa.KodeKantorCabang)
        TRIM(xb.NamaGadisIbuKandung) = TRIM(xa.NamaGadisIbuKandung)
    )
where TRIM(xa.CIF) = TRIM(xz.CIF)
;

z_cErrMsg = public.serene(1, 'C210');

insert into tmp_cif_hilang
(
     cif
    ,kodekantorcabang
)
select distinct
     xa.cif
    ,xa.kodekantorcabang as kodekantorcabang
from probi.slik_f_f01 as xa
left join TMP_SLIK_F_D01 as xb
    on trim(coalesce(xa.cif, '')) = trim(coalesce(xb.cif, ''))
where xa.period = z_dPeriod
and trim(coalesce(xa.cif, '')) <> ''
and xb.cif is null
union select distinct
     xa.cif
    ,xa.kodekantorcabang as kodekantorcabang
from probi.slik_f_f02 as xa
left join TMP_SLIK_F_D01 as xb
    on trim(coalesce(xa.cif, '')) = trim(coalesce(xb.cif, ''))
where xa.period = z_dPeriod
and trim(coalesce(xa.cif, '')) <> ''
and xb.cif is null
union select distinct
     xa.cif
    ,xa.kodekantorcabang as kodekantorcabang
from probi.slik_f_f03 as xa
left join TMP_SLIK_F_D01 as xb
    on trim(coalesce(xa.cif, '')) = trim(coalesce(xb.cif, ''))
where xa.period = z_dPeriod
and trim(coalesce(xa.cif, '')) <> ''
and xb.cif is null
union select distinct
     xa.cif
    ,xa.kodekantorcabang as kodekantorcabang
from probi.slik_f_f04 as xa
left join TMP_SLIK_F_D01 as xb
    on trim(coalesce(xa.cif, '')) = trim(coalesce(xb.cif, ''))
where xa.period = z_dPeriod
and trim(coalesce(xa.cif, '')) <> ''
and xb.cif is null
union select distinct
     xa.cif
    ,xa.kodekantorcabang as kodekantorcabang
from probi.slik_f_f05 as xa
left join TMP_SLIK_F_D01 as xb
    on trim(coalesce(xa.cif, '')) = trim(coalesce(xb.cif, ''))
where xa.period = z_dPeriod
and trim(coalesce(xa.cif, '')) <> ''
and xb.cif is null
union select distinct
     xa.cif
    ,xa.kodekantorcabang as kodekantorcabang
from probi.slik_f_f06 as xa
left join TMP_SLIK_F_D01 as xb
    on trim(coalesce(xa.cif, '')) = trim(coalesce(xb.cif, ''))
where xa.period = z_dPeriod
and trim(coalesce(xa.cif, '')) <> ''
and xb.cif is null
;

z_cErrMsg = public.serene(1, 'C220');

insert into tmp_slik_f_d01_reinsert
(
     period                   ,flagdetail               ,cif
    ,jenisidentitas           ,nikpassport              ,namasesuaiidentitas
    ,namalengkap              ,kodestatusgelardebitur   ,jeniskelamin
    ,tempatlahirktp           ,tanggallahir             ,npwp
    ,alamat                   ,kelurahan                ,kecamatan
    ,kodedatiii               ,kodepos                  ,telepon
    ,nomortelepongenggam      ,alamatemail              ,kodenegara
    ,kodepekerjaan            ,tempatbekerja            ,kodebidangusaha
    ,alamattempatbekerja      ,penghasilankotorpertahun ,kodesumberpenghasilan
    ,jumlahtanggungan         ,kodehubungandenganljk    ,kodegolongandebitur
    ,statusperkawinandebitur  ,nikpassportpasangan      ,namapasangan
    ,tanggallahirpasangan     ,perjanjianpisahharta     ,melanggarbm
    ,melampauibm              ,namagadisibukandung      ,kodekantorcabang
    ,operationdata            ,tahundata                ,bulandata
    ,sandiljk                 ,kodejenisljk             ,createdate
    ,insertquery
)
select
     z_dPeriod
    ,xa.flagdetail as flagdetail
    ,xa.cif as cif
    ,xa.jenisidentitas as jenisidentitas
    ,xa.nikpassport as nikpassport
    ,xa.namasesuaiidentitas as namasesuaiidentitas
    ,xa.namalengkap as namalengkap
    ,xa.kodestatusgelardebitur as kodestatusgelardebitur
    ,xa.jeniskelamin as jeniskelamin
    ,xa.tempatlahirktp as tempatlahirktp
    ,xa.tanggallahir as tanggallahir
    ,xa.npwp as npwp
    ,xa.alamat as alamat
    ,xa.kelurahan as kelurahan
    ,xa.kecamatan as kecamatan
    ,xa.kodedatiii as kodedatiii
    ,xa.kodepos as kodepos
    ,xa.telepon as telepon
    ,xa.nomortelepongenggam as nomortelepongenggam
    ,xa.alamatemail as alamatemail
    ,xa.kodenegara as kodenegara
    ,xa.kodepekerjaan as kodepekerjaan
    ,xa.tempatbekerja as tempatbekerja
    ,xa.kodebidangusaha as kodebidangusaha
    ,xa.alamattempatbekerja as alamattempatbekerja
    ,xa.penghasilankotorpertahun as penghasilankotorpertahun
    ,xa.kodesumberpenghasilan as kodesumberpenghasilan
    ,xa.jumlahtanggungan as jumlahtanggungan
    ,xa.kodehubungandenganljk as kodehubungandenganljk
    ,xa.kodegolongandebitur as kodegolongandebitur
    ,xa.statusperkawinandebitur as statusperkawinandebitur
    ,xa.nikpassportpasangan as nikpassportpasangan
    ,xa.namapasangan as namapasangan
    ,xa.tanggallahirpasangan as tanggallahirpasangan
    ,xa.perjanjianpisahharta as perjanjianpisahharta
    ,xa.melanggarbm as melanggarbm
    ,xa.melampauibm as melampauibm
    ,xa.namagadisibukandung as namagadisibukandung
    ,xa.kodekantorcabang as kodekantorcabang
    ,xa.operationdata as operationdata
    ,xa.tahundata as tahundata
    ,xa.bulandata as bulandata
    ,xa.sandiljk as sandiljk
    ,xa.kodejenisljk as kodejenisljk
    ,xa.createdate as createdate
    ,'IQ-01' as insertquery
from probi.slik_f_d01 as xa
inner join tmp_cif_hilang as xb
    on trim(coalesce(xa.cif, '')) = trim(coalesce(xb.cif, ''))
where xa.period = z_dPrevPeriod
;

----------------------------------------------------------------------------------------------------------
-- Main Process Result --
----------------------------------------------------------------------------------------------------------
z_cErrMsg = public.serene(1, 'D010');

delete from probi.slik_f_d01 as xz
where xz.Period = z_dPeriod
;

z_cErrMsg = public.serene(1, 'D020');

insert into probi.slik_f_d01
(
     Period
    ,FlagDetail
    ,CIF
    ,JenisIdentitas
    ,NIKPassport
    ,NamaSesuaiIdentitas
    ,NamaLengkap
    ,KodeStatusGelarDebitur
    ,JenisKelamin
    ,TempatLahirKTP
    ,TanggalLahir
    ,NPWP
    ,Alamat
    ,Kelurahan
    ,Kecamatan
    ,KodeDATIII
    ,KodePos
    ,Telepon
    ,NomorTeleponGenggam
    ,AlamatEmail
    ,KodeNegara
    ,KodePekerjaan
    ,TempatBekerja
    ,KodeBidangUsaha
    ,AlamatTempatBekerja
    ,PenghasilanKotorPerTahun
    ,KodeSumberPenghasilan
    ,JumlahTanggungan
    ,KodeHubungandenganLJK
    ,KodeGolonganDebitur
    ,StatusPerkawinanDebitur
    ,NIKPassportPasangan
    ,NamaPasangan
    ,TanggalLahirPasangan
    ,PerjanjianPisahHarta
    ,MelanggarBM
    ,MelampauiBM
    ,NamaGadisIbuKandung
    ,KodeKantorCabang
    ,OperationData
    ,TahunData
    ,BulanData
    ,SandiLJK
    ,KodeJenisLJK
    ,CreateDate
)
select
     xa.Period as Period
    ,trim(coalesce(xa.FlagDetail, '')) as FlagDetail
    ,trim(coalesce(xa.CIF, '')) as CIF
    ,trim(coalesce(xa.JenisIdentitas, '')) as JenisIdentitas
    ,trim(coalesce(xa.NIKPassport, '')) as NIKPassport
    ,trim(coalesce(xa.NamaSesuaiIdentitas, '')) as NamaSesuaiIdentitas
    ,trim(coalesce(xa.NamaLengkap, '')) as NamaLengkap
    ,case
        when coalesce(xa.KodeStatusGelarDebitur, '') = '' then '00'
        else trim(coalesce(xa.KodeStatusGelarDebitur, ''))
     end as KodeStatusGelarDebitur
    ,trim(coalesce(xa.JenisKelamin, '')) as JenisKelamin
    ,trim(coalesce(xa.TempatLahirKTP, '')) as TempatLahirKTP
    ,trim(coalesce(xa.TanggalLahir, '')) as TanggalLahir
    ,trim(coalesce(xa.NPWP, '')) as NPWP
    ,trim(coalesce(xa.Alamat, '')) as Alamat
    ,trim(coalesce(xa.Kelurahan, '')) as Kelurahan
    ,trim(coalesce(xa.Kecamatan, '')) as Kecamatan
    ,trim(coalesce(xa.KodeDATIII, '')) as KodeDATIII
    ,trim(coalesce(xa.KodePos, '')) as KodePos
    ,trim(coalesce(xa.Telepon, '')) as Telepon
    ,trim(coalesce(xa.NomorTeleponGenggam, '')) as NomorTeleponGenggam
    ,trim(coalesce(xa.AlamatEmail, '')) as AlamatEmail
    ,trim(coalesce(xa.KodeNegara, '')) as KodeNegara
    ,trim(coalesce(xa.KodePekerjaan, '')) as KodePekerjaan
    ,trim(coalesce(xa.TempatBekerja, '')) as TempatBekerja
    ,trim(coalesce(xa.KodeBidangUsaha, '')) as KodeBidangUsaha
    ,trim(coalesce(xa.AlamatTempatBekerja, '')) as AlamatTempatBekerja
    ,trim(coalesce(xa.PenghasilanKotorPerTahun, '')) as PenghasilanKotorPerTahun
    ,trim(coalesce(xa.KodeSumberPenghasilan, '')) as KodeSumberPenghasilan
    ,trim(coalesce(xa.JumlahTanggungan, '')) as JumlahTanggungan
    ,trim(coalesce(xa.KodeHubungandenganLJK, '')) as KodeHubungandenganLJK
    ,trim(coalesce(xa.KodeGolonganDebitur, '')) as KodeGolonganDebitur
    ,trim(coalesce(xa.StatusPerkawinanDebitur, '')) as StatusPerkawinanDebitur
    ,trim(coalesce(xa.NIKPassportPasangan, '')) as NIKPassportPasangan
    ,trim(coalesce(xa.NamaPasangan, '')) as NamaPasangan
    ,trim(coalesce(xa.TanggalLahirPasangan, '')) as TanggalLahirPasangan
    ,trim(coalesce(xa.PerjanjianPisahHarta, '')) as PerjanjianPisahHarta
    ,trim(coalesce(xa.MelanggarBM, '')) as MelanggarBM
    ,trim(coalesce(xa.MelampauiBM, '')) as MelampauiBM
    ,trim(coalesce(xa.NamaGadisIbuKandung, '')) as NamaGadisIbuKandung
    ,trim(coalesce(xa.KodeKantorCabang, '')) as KodeKantorCabang
    ,trim(coalesce(xa.OperationData, '')) as OperationData
    ,xa.TahunData as TahunData
    ,xa.BulanData as BulanData
    ,xa.SandiLJK as SandiLJK
    ,xa.KodeJenisLJK as KodeJenisLJK
    ,xa.CreateDate as CreateDate
from TMP_SLIK_F_D01 as xa
order by
     xa.CIF asc
    ,xa.NamaLengkap asc
;

z_cErrMsg = public.serene(1, 'D030');

insert into probi.slik_f_d01
(
     period                   ,flagdetail               ,cif
    ,jenisidentitas           ,nikpassport              ,namasesuaiidentitas
    ,namalengkap              ,kodestatusgelardebitur   ,jeniskelamin
    ,tempatlahirktp           ,tanggallahir             ,npwp
    ,alamat                   ,kelurahan                ,kecamatan
    ,kodedatiii               ,kodepos                  ,telepon
    ,nomortelepongenggam      ,alamatemail              ,kodenegara
    ,kodepekerjaan            ,tempatbekerja            ,kodebidangusaha
    ,alamattempatbekerja      ,penghasilankotorpertahun ,kodesumberpenghasilan
    ,jumlahtanggungan         ,kodehubungandenganljk    ,kodegolongandebitur
    ,statusperkawinandebitur  ,nikpassportpasangan      ,namapasangan
    ,tanggallahirpasangan     ,perjanjianpisahharta     ,melanggarbm
    ,melampauibm              ,namagadisibukandung      ,kodekantorcabang
    ,operationdata            ,tahundata                ,bulandata
    ,sandiljk                 ,kodejenisljk             ,createdate
)
select
     xa.period as period
    ,xa.flagdetail as flagdetail
    ,xa.cif as cif
    ,xa.jenisidentitas as jenisidentitas
    ,xa.nikpassport as nikpassport
    ,xa.namasesuaiidentitas as namasesuaiidentitas
    ,xa.namalengkap as namalengkap
    ,xa.kodestatusgelardebitur as kodestatusgelardebitur
    ,xa.jeniskelamin as jeniskelamin
    ,xa.tempatlahirktp as tempatlahirktp
    ,xa.tanggallahir as tanggallahir
    ,xa.npwp as npwp
    ,xa.alamat as alamat
    ,xa.kelurahan as kelurahan
    ,xa.kecamatan as kecamatan
    ,xa.kodedatiii as kodedatiii
    ,xa.kodepos as kodepos
    ,xa.telepon as telepon
    ,xa.nomortelepongenggam as nomortelepongenggam
    ,xa.alamatemail as alamatemail
    ,xa.kodenegara as kodenegara
    ,xa.kodepekerjaan as kodepekerjaan
    ,xa.tempatbekerja as tempatbekerja
    ,xa.kodebidangusaha as kodebidangusaha
    ,xa.alamattempatbekerja as alamattempatbekerja
    ,xa.penghasilankotorpertahun as penghasilankotorpertahun
    ,xa.kodesumberpenghasilan as kodesumberpenghasilan
    ,xa.jumlahtanggungan as jumlahtanggungan
    ,xa.kodehubungandenganljk as kodehubungandenganljk
    ,xa.kodegolongandebitur as kodegolongandebitur
    ,xa.statusperkawinandebitur as statusperkawinandebitur
    ,xa.nikpassportpasangan as nikpassportpasangan
    ,xa.namapasangan as namapasangan
    ,xa.tanggallahirpasangan as tanggallahirpasangan
    ,xa.perjanjianpisahharta as perjanjianpisahharta
    ,xa.melanggarbm as melanggarbm
    ,xa.melampauibm as melampauibm
    ,xa.namagadisibukandung as namagadisibukandung
    ,xa.kodekantorcabang as kodekantorcabang
    ,xa.operationdata as operationdata
    ,xa.tahundata as tahundata
    ,xa.bulandata as bulandata
    ,xa.sandiljk as sandiljk
    ,xa.kodejenisljk as kodejenisljk
    ,xa.createdate as createdate
from tmp_slik_f_d01_reinsert as xa
;


z_cErrMsg = public.serene(1, 'D040');

perform public.runcmd
(
                  'psql -d ' || current_database()::character varying || ' -Atc "'
    || CHR(10) || 'update probi.BI_ProcessTable_TM as xz'
    || CHR(10) || 'set'
    || CHR(10) || '     successbit = 1 -- success --'
    || CHR(10) || '    ,lastexecsuccessdate = ''' || current_timestamp::character varying || ''''
    || CHR(10) || 'where xz.storedprocedurename = ''' || LOWER(z_cFuncName) || ''''
    || CHR(10) || ';'
    || CHR(10) || '"'
);

z_cErrMsg = public.serene(1, 'D050');

perform public.runcmd
(
                  'psql -d ' || current_database()::character varying || ' -Atc "'
    || CHR(10) || 'insert into probi.bi_statusprocesslog_tm'
    || CHR(10) || '('
    || CHR(10) || '     processguid          ,perioddata           ,groupid              ,processid'
    || CHR(10) || '    ,lastchangestatusdate ,statusprocess        ,keterangan           ,submiternik'
    || CHR(10) || '    ,submitdate           ,approvalnik          ,approvaldate         ,textfile'
    || CHR(10) || ')'
    || CHR(10) || 'select'
    || CHR(10) || '     null::character varying as processguid'
    || CHR(10) || '    ,''' || z_dPeriod::character varying || ''' as perioddata'
    || CHR(10) || '    ,' || z_nJobId::character varying || ' as groupid'
    || CHR(10) || '    ,' || z_nProcessId::character varying || ' as processid'
    || CHR(10) || '    ,null::timestamp without time zone as lastchangestatusdate'
    || CHR(10) || '    ,''' || z_cStatusProcess || ''' as statusprocess'
    || CHR(10) || '    ,''' || '' || ''' as keterangan'
    || CHR(10) || '    ,' || z_nSubmitterNIK::character varying || ' as submiternik'
    || CHR(10) || '    ,''' || current_timestamp::character varying || ''' as submitdate'
    || CHR(10) || '    ,null::integer as approvalnik'
    || CHR(10) || '    ,null::timestamp without time zone as approvaldate'
    || CHR(10) || '    ,null::character varying as textfile'
    || CHR(10) || ';'
    || CHR(10) || '"'
);

return 0;

----------------------------------------------------------------------------------------------------------
-- Exception --
----------------------------------------------------------------------------------------------------------
EXCEPTION
when OTHERS then
z_cFuncName = COALESCE(z_cFuncName, '[UNSPECIFIED FUNCTION NAME]');
z_cErrMsg   = COALESCE(z_cErrMsg, 'Error#00 - Unspecified Error. Please review the function definition.');
z_cSQLState = SQLSTATE;
z_cSQLMsg   = SQLERRM;
z_cUser     = USER;

raise EXCEPTION '[ERROR - %]: % | % - %', z_cFuncName, z_cErrMsg, z_cSQLState, z_cSQLMsg;

return 1;

----------------------------------------------------------------------------------------------------------
-- Object Usage List --
----------------------------------------------------------------------------------------------------------
/*
-- Table --

-- Function --

-- Result --

*/
--========================================================================================================
END;--FUNCTION--
--========================================================================================================
$BODY$
language plpgsql volatile;