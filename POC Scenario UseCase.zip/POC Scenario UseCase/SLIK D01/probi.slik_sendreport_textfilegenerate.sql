"create or replace function probi.slik_sendreport_textfilegenerate
(
     z_pdperiod date
    ,z_pcuserslik character varying
    ,z_pcuserslikselect character varying
    ,z_pcstatusidkantor character varying
    ,z_pbcreatefolder boolean
    ,z_pcstatustexfile character varying
    ,z_pcguidcustom character varying
)
returns integer
as
$BODY$
----------------------------------------------------------------------------------------------------------
-- Variable Declaration --
----------------------------------------------------------------------------------------------------------
declare
---- system variable ----
z_cFuncName             character varying;
z_cErrMsg               character varying;
z_cSQLState             character varying;
z_cSQLMsg               character varying;
z_cUser                 character varying;
z_cQuery                character varying;
z_cColumnList           character varying;

---- procedure variable ----
z_dCurrEOD              date;
z_dPeriod               date;
z_cUserSlik             character varying;
z_cUserSlikSelect       character varying;
z_rUserSlikList         record;
z_cStatusIdKantor       character varying;
z_rLoopForm             record;
z_ntest                 integer;
z_nmaxorder             integer;
z_cPeriod               character varying;

z_cTahun                character varying;
z_cBulan                character varying;
z_cKodeLJK              character varying;
z_cSandiLJK             character varying;

z_cDestPathParent       character varying;
z_cDestPathFolder       character varying;
z_cDestPathText         character varying;
z_cDestNameText         character varying;
Z_cCommand              character varying;
z_cFTPIdText            integer;
Z_cResult               character varying;
z_cUrutan               character varying;
z_nJumlahData           numeric(8, 0);
z_bTextfile             boolean;
z_bFTP                  boolean;

Z_cSubject              character varying;
Z_cBody                 character varying;
Z_cRecipients           character varying;
Z_cCCRecipients         character varying;
z_bCreateFolder         boolean;

z_cCurrYear             character varying;
z_cCurrMonth            character varying;
z_cCurrDay              character varying;
z_cCurrHour             character varying;
z_cCurrMinute           character varying;

z_cCurrDate             character varying;
z_cCurrTime             character varying;

z_nCountPIC             integer;

z_cGuid                 character varying;
z_nTotalSegment         numeric;
z_nSumTotal             numeric;
z_rLoopForm2            record;
z_cKodeLJKHeader        character varying;

z_cUserName             character varying;
z_nDataCount_01         integer;
z_nDataCount_02         integer;
z_nDataCount_03         integer;
z_nDataCount_04         integer;
z_nDataCount_05         integer;
z_nDataCount_06         integer;
z_nDataCount_07         integer;
z_nDataCount_08         integer;
z_nDataCount_09         integer;
z_nDataCount_10         integer;
z_nDataCount_11         integer;
z_nDataCount_12         integer;
z_nDataCount_13         integer;
z_cstatustexfile       character varying;
z_cGuidCustom          character varying;

--========================================================================================================
BEGIN--FUNCTION--
--========================================================================================================
----------------------------------------------------------------------------------------------------------
-- Variable Assignment --
----------------------------------------------------------------------------------------------------------
z_cFuncName = 'SLIK_SendReport_TextfileGenerate';

select
    xa.ops_date
from ads.DOPS_Parameters as xa
into
    z_dCurrEOD
;

z_cUserSlik = coalesce(z_pcUserSlik, '');
z_cUserSlikSelect = coalesce(z_pcUserSlikSelect, '');
z_dPeriod = coalesce(z_pdPeriod, '19000101')::date;
z_cStatusIdKantor = coalesce(z_pcStatusIdKantor, '');
z_cTahun = to_char(z_dPeriod, 'yyyy');
z_cBulan = to_char(z_dPeriod, 'mm');
z_cPeriod = to_char(z_dPeriod, 'yyyymmdd');
z_cKodeLJK =
    case
        when z_cStatusIdKantor = 'K' then '0101'
        else '0102'
    end
;
z_cSandiLJK = '028';

z_bCreateFolder = coalesce(z_pbCreateFolder, true);


z_cCurrYear = extract(year from clock_timestamp())::text::character varying;
z_cCurrMonth = lpad(extract(month from clock_timestamp())::text, 2, '0')::character varying;
z_cCurrDay = lpad(extract(day from clock_timestamp())::text, 2, '0')::character varying;
z_cCurrHour = lpad(extract(hour from clock_timestamp())::text, 2, '0')::character varying;
z_cCurrMinute = lpad(extract(minute from clock_timestamp())::text, 2, '0')::character varying;


z_cCurrDate = z_cCurrYear || z_cCurrMonth || z_cCurrDay;
z_cCurrTime = z_cCurrHour || '.' || z_cCurrMinute;

select
    initcap(xa.employeename)
from workfile.tmp_employeepeoplesoft as xa
where xa.employeeid = z_cUserSlik
into
    z_cUserName
;

z_cstatustexfile = coalesce(trim(z_pcstatustexfile), '');
z_cGuidCustom = coalesce(trim(z_pcGuidCustom), '');

----------------------------------------------------------------------------------------------------------
-- Variable Debug --
----------------------------------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------------
-- Preliminary Validation --
----------------------------------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------------
-- Temporary Procedure Table Declaration --
----------------------------------------------------------------------------------------------------------
z_cErrMsg = public.serene(1, '010');

if public.fnCheckTemporaryTableExistence('tmp_ftp_parameter_14244184') = 0
then
    z_cErrMsg = public.serene(1, 'Gagal create temp table tmp_ftp_parameter_14244184!');
    create temporary table tmp_ftp_parameter_14244184
    (
         ReplacementKeyword     character varying
        ,KeywordToReplace       character varying
        ,Period                 character varying
    )
    distributed randomly;
else
    z_cErrMsg = public.serene(1, 'Gagal truncate temp table tmp_ftp_parameter_14244184!');
    truncate table tmp_ftp_parameter_14244184;
end if;

if public.fnCheckTemporaryTableExistence('tmp_SLIK_H_Textfile') = 0
then
    z_cErrMsg = public.serene(1, 'Gagal create temp table tmp_SLIK_H_Textfile!');
    create temporary table tmp_SLIK_H_Textfile
    (
         formid             character varying
        ,jumlahdata         numeric
        ,jumlahdatasegment  numeric
        ,guid               character varying
    )
    distributed randomly;
else
    z_cErrMsg = public.serene(1, 'Gagal truncate temp table tmp_SLIK_H_Textfile!');
    truncate table tmp_SLIK_H_Textfile;
end if;

if public.fnCheckTemporaryTableExistence('tmp_ftp_DestinationFileName_25355295') = 0 -- ini ganti
then
    z_cErrMsg = public.serene(1, 'Gagal create temp table tmp_ftp_DestinationFileName_25355295!');
    create temporary table tmp_ftp_DestinationFileName_25355295
    (
         Period                         character varying
        ,FileNameKeywordToReplace       character varying
        ,FileNameReplacementKeyword     character varying
        ,PathFolderKeywordToReplace     character varying
        ,PathFolderReplacementKeyword   character varying
    )
    distributed randomly;
else
    z_cErrMsg = public.serene(1, 'Gagal truncate temp table tmp_ftp_parameter_14244184!');
    truncate table tmp_ftp_DestinationFileName_25355295;

end if;

----------------------------------------------------------------------------------------------------------
-- Temporary Source Table Declaration --
----------------------------------------------------------------------------------------------------------
z_cErrMsg = public.serene(1, '020');

----------------------------------------------------------------------------------------------------------
-- Main Process --
----------------------------------------------------------------------------------------------------------
z_cErrMsg = public.serene(1, '030');

if upper(z_cUserSlikSelect) = 'ALL' then
    raise notice '----- ALL -----';

    z_cErrMsg = public.serene(1, 'Gagal create temp table tmp_all_user!');
    perform public.fnDropTemporaryTable('tmp_all_user');
    create temporary table tmp_all_user
    (
         pic        character varying
    )
    distributed randomly;

    z_cErrMsg = public.serene(1, 'Gagal create temp table tmp_all_user_with_rownumber!');
    perform public.fnDropTemporaryTable('tmp_all_user_with_rownumber');
    create temporary table tmp_all_user_with_rownumber
    (
         pic        character varying
        ,rownumber  integer
    )
    distributed randomly;

    z_cErrMsg = public.serene(1, 'Gagal insert temp table tmp_all_user!');
    insert into tmp_all_user
    ( pic )

    select
         z_cUserSlik
    ;

    z_cErrMsg = public.serene(1, 'Gagal insert temp table tmp_all_user_with_rownumber!');
    insert into tmp_all_user_with_rownumber
    ( pic, rownumber )
    select
         xa.pic
        ,row_number() over (order by xa.pic)
    from tmp_all_user as xa
    ;

    raise notice '----- ROWCOUNT : % -----', (select count(1) from tmp_all_user_with_rownumber);

    truncate table probi.SLIK_F_OrderList;

end if;

if z_cUserSlikSelect = 'ALL' then
    z_cErrMsg = public.serene(1, 'Gagal create temp table tmp_all_user_distinct!');
    perform public.fnDropTemporaryTable('tmp_all_user_distinct');
    create temporary table tmp_all_user_distinct
    (
         pic        character varying
    )
    distributed randomly;

    z_cErrMsg = public.serene(1, 'Gagal insert temp table tmp_all_user_distinct!');
    insert into tmp_all_user_distinct
    ( pic )
    select
         z_cUserSlik
    ;


    z_cUserSlikSelect = z_cUserSlik;
    if z_nCountPIC > 1 then
        z_bCreateFolder = false;
    end if;
end if;

-- ambil urutan
z_nmaxorder =
    coalesce(max(xa.orderid), 0)
    from probi.SLIK_F_OrderList as xa
    where xa.period = z_dPeriod
;

z_cErrMsg = public.serene(1, 'Gagal insert table probi.SLIK_F_OrderList!');
insert into probi.SLIK_F_OrderList
(
     period
    ,orderid
    ,userid
    ,processdate
)
select
     z_dPeriod -- period
    ,z_nmaxorder + 1 -- orderid
    ,z_cUserSlikSelect -- userid
    ,current_timestamp -- processdate
;

-- create path
-- path folder = NIK-YYYYMMDD-hh.mm-KODELJK
z_cUrutan = (z_nmaxorder + 1)::character varying;
z_cDestPathParent = '/data/FTP_FILES/APPLICATION/ProBI/SLIK/';
z_cDestPathFolder =
    z_pcUserSlik
    || '-' || z_cCurrDate
    || '-' || z_cCurrTime
    || '-' || z_cKodeLJK
;
z_cDestPathText = z_cDestPathParent || z_cDestPathFolder;

raise notice 'des %', z_cDestPathParent;
raise notice 'folder %', z_cDestPathFolder;
raise notice 'path %', z_cDestPathText;

-- create folder di loop paling awal
if z_bCreateFolder then
    -- folder

    z_cErrMsg = public.serene(1, 'Gagal pre - mkdir!');
    perform public.ftp_pre_post_process
    (
        'pre - mkdir'
        ,z_cDestPathText
        ,null
        ,null
        ,null
    );

    z_cErrMsg = public.serene(1, 'Gagal pre - chmod!');
    perform public.ftp_pre_post_process
    (
        'pre - chmod'
        ,z_cDestPathText
        ,null
        ,null
        ,null
    );


    raise notice '----- FOLDER CREATED -----';
end if;

z_cGuid = 'txt' || md5(z_cDestPathText);

for z_rLoopForm in
    select
        formid
    from probi.SLIK_ParamFormList
    where formid <> 'S01'
    order by rowid
loop
    z_cDestNameText =
        z_cKodeLJK
        || '.' || z_cSandiLJK
        || '.' || z_cTahun
        || '.' || z_cBulan
        || '.' || z_rLoopForm.FormId
        || '.' || z_cUrutan
        || '.txt'
    ;

    raise notice 'path %', z_cDestPathText;
    raise notice 'text %', z_cDestNameText;

    ---- delete current destination text file ----
    z_cErrMsg = public.serene(1, 'Gagal delete current destination text file!');
--     perform public.runcmd('rm ' || z_cDestPathText || z_cDestNameText);
    perform public.ftp_pre_post_process
    (
        'pre - rm files'
        ,z_cDestPathText || '/' ||z_cDestNameText
        ,null
        ,null
        ,null
    );

    if lower(z_cstatustexfile) = 'all'
    then
        z_cQuery = ' ';
        z_cQuery = z_cQuery || CHR(10) || 'select * ';
        z_cQuery = z_cQuery || CHR(10) || 'from probi.SLIK_SendReport_TextfileCreate ';
        z_cQuery = z_cQuery || CHR(10) || '( ';
        z_cQuery = z_cQuery || CHR(10) || '     ''' || z_dPeriod || ''' ';
        z_cQuery = z_cQuery || CHR(10) || '    ,''' || z_cUserSlikSelect || ''' ';
        z_cQuery = z_cQuery || CHR(10) || '    ,''' || z_rLoopForm.FormId || ''' ';
        z_cQuery = z_cQuery || CHR(10) || '    ,''' || z_cStatusIdKantor || ''' ';
        z_cQuery = z_cQuery || CHR(10) || '); ';
        z_cQuery = z_cQuery || CHR(10) || ' ';
    else -- untuk custom --
        z_cQuery = ' ';
        z_cQuery = z_cQuery || CHR(10) || 'select * ';
        z_cQuery = z_cQuery || CHR(10) || 'from probi.slik_sendreport_textfilecreate_custom ';
        z_cQuery = z_cQuery || CHR(10) || '( ';
        z_cQuery = z_cQuery || CHR(10) || '     ''' || z_dPeriod || ''' ';
        z_cQuery = z_cQuery || CHR(10) || '    ,''' || z_cUserSlikSelect || ''' ';
        z_cQuery = z_cQuery || CHR(10) || '    ,''' || z_rLoopForm.FormId || ''' ';
        z_cQuery = z_cQuery || CHR(10) || '    ,''' || z_cStatusIdKantor || ''' ';
        z_cQuery = z_cQuery || CHR(10) || '    ,''' || z_cGuidCustom || ''' ';
        z_cQuery = z_cQuery || CHR(10) || '); ';
        z_cQuery = z_cQuery || CHR(10) || ' ';
    end if;
    ---- insert data ----
    z_cQuery = z_cQuery || CHR(10) || ' ';
    z_cQuery = z_cQuery || CHR(10) || 'insert into probi.SLIK_H_Textfile ';
    z_cQuery = z_cQuery || CHR(10) || '( ';
    z_cQuery = z_cQuery || CHR(10) || ' period ';
    z_cQuery = z_cQuery || CHR(10) || ',userid ';
    z_cQuery = z_cQuery || CHR(10) || ',formid ';
    z_cQuery = z_cQuery || CHR(10) || ',urutan ';
    z_cQuery = z_cQuery || CHR(10) || ',jumlahdata ';
    z_cQuery = z_cQuery || CHR(10) || ',jumlahdatasegment ';
    z_cQuery = z_cQuery || CHR(10) || ',createdate ';
    z_cQuery = z_cQuery || CHR(10) || ',guid ';
    z_cQuery = z_cQuery || CHR(10) || ',kodeljk ';
    z_cQuery = z_cQuery || CHR(10) || ') ';
    z_cQuery = z_cQuery || CHR(10) || 'select ';
    z_cQuery = z_cQuery || CHR(10) || '     ''' || z_dPeriod || ''' ';
    z_cQuery = z_cQuery || CHR(10) || '    ,''' || z_cUserSlikSelect || ''' ';
    z_cQuery = z_cQuery || CHR(10) || '    ,''' || z_rLoopForm.FormId || ''' ';
    z_cQuery = z_cQuery || CHR(10) || '    ,''' || z_cUrutan || ''' ';
    z_cQuery = z_cQuery || CHR(10) || '    ,xa.rowcount ';
    z_cQuery = z_cQuery || CHR(10) || '    ,xa.totalsegment ';
    z_cQuery = z_cQuery || CHR(10) || '    ,current_timestamp ';
    z_cQuery = z_cQuery || CHR(10) || '    ,''' || z_cGuid || ''' ';
    z_cQuery = z_cQuery || CHR(10) || '    ,xa.kodeljk ';
    z_cQuery = z_cQuery || CHR(10) || 'from tmp_TextFile as xa ';
    z_cQuery = z_cQuery || CHR(10) || 'where rowid = 1; ';
    z_cQuery = z_cQuery || CHR(10) || ' ';

    raise notice '%', z_cQuery;

    ---- textfile ----
    z_cQuery = z_cQuery || CHR(10) || 'COPY ';
    z_cQuery = z_cQuery || CHR(10) || '( ';
    z_cQuery = z_cQuery || CHR(10) || '    select ';
    z_cQuery = z_cQuery || CHR(10) || '     xa.txt ';
    z_cQuery = z_cQuery || CHR(10) || '    from tmp_TextFile as xa ';
    z_cQuery = z_cQuery || CHR(10) || '    order by ';
    z_cQuery = z_cQuery || CHR(10) || '     xa.rowid asc ';
    z_cQuery = z_cQuery || CHR(10) || ') to ''' || z_cDestPathText || '/' ||z_cDestNameText || ''' ';
    z_cQuery = z_cQuery || CHR(10) || 'WITH ';
    z_cQuery = z_cQuery || CHR(10) || '    delimiter as '' '' ';
    z_cQuery = z_cQuery || CHR(10) || '    null as ''<NULL>'' ';
    z_cQuery = z_cQuery || CHR(10) || '    escape as ''off'' ';
    z_cQuery = z_cQuery || CHR(10) || '; ';

    z_cErrMsg = public.serene(1, 'Gagal exec query!');
    Z_cResult =  public.runcmd('psql -d ' || current_database()::character varying || ' -Atc "' || z_cQuery || '"');

    raise notice 'z_cQuery : %', z_cQuery;

    z_cErrMsg = public.serene(1, 'Gagal grant access to pre - chmod');
    perform public.ftp_pre_post_process
    (
        'pre - chmod'
        ,z_cDestPathText || '/' ||z_cDestNameText
        ,null
        ,null
        ,null
    );

    z_cErrMsg = public.serene(1, 'Gagal grant access to pre - unix2dos');
    perform public.ftp_pre_post_process
    (
        'pre - unix2dos'
        ,z_cDestPathText || '/' ||z_cDestNameText
        ,null
        ,null
        ,null
    );


    z_cKodeLJKHeader = (select kodeljk from probi.SLIK_H_Textfile where formid = z_rLoopForm.FormId and urutan = z_cUrutan and period = z_dPeriod and guid = z_cGuid limit 1);
    if z_cKodeLJK <> z_cKodeLJKHeader then
        z_cErrMsg = public.serene(1, 'Kode lembaga pada nama file harus sama dengan kode lembaga pada header!');
        raise exception 'Exception Raised';
    end if;

    -- pengecekan status textfile
    if (upper(Z_cResult) like '%ERROR%') then
        z_bTextfile = false;
    else
        z_bTextfile = true;
    end if;
end loop;

----------------------------------------------------------------------------------------------------------
-- Main Process Result --
----------------------------------------------------------------------------------------------------------
z_cErrMsg = public.serene(1, '040');

-- send folder di loop paling akhir
if z_cUserSlikSelect = z_cUserSlik then
    z_cErrMsg = public.serene(1, 'Gagal insert temp table tmp_ftp_parameter_14244184!');
    insert into tmp_ftp_parameter_14244184
    (
         ReplacementKeyword
        ,KeywordToReplace
        ,Period
    )
    select
--          z_cDestPathFolder || '.zip' -- ReplacementKeyword
--         ,'z_pcUserSlik-z_cCurrDate-z_cCurrTime-z_cKodeLJK.zip' -- KeywordToReplace
         z_cDestPathFolder -- ReplacementKeyword
        ,'z_pcUserSlik-z_cCurrDate-z_cCurrTime-z_cKodeLJK' -- KeywordToReplace
        ,z_cPeriod -- Period
    ;

    truncate table tmp_ftp_DestinationFileName_25355295;
    insert into tmp_ftp_DestinationFileName_25355295
    (
         PathFolderReplacementKeyword
        ,PathFolderKeywordToReplace
        ,FileNameReplacementKeyword
        ,FileNameKeywordToReplace
        ,Period
    )
    select
         z_cDestPathFolder -- ReplacementKeyword
        ,'z_pcUserSlik-z_cCurrDate-z_cCurrTime-z_cKodeLJK' -- KeywordToReplace
        ,'' -- ReplacementKeyword
        ,'' -- KeywordToReplace
        ,z_cPeriod -- Period
    ;

    -- pengecekan jumlah data yang digenerate

    z_cErrMsg = public.serene(1, 'Gagal insert temp table tmp_SLIK_H_Textfile!');
    insert into tmp_SLIK_H_Textfile
    (
         formid
        ,jumlahdata
        ,jumlahdatasegment
        ,guid
    )
    select
         xa.formid -- formid
        ,xa.jumlahdata -- jumlahdata
        ,xa.jumlahdatasegment -- jumlahdatasegment
        ,xa.guid -- guid
    from probi.SLIK_H_Textfile as xa
    where xa.guid = z_cGuid
    and xa.period = z_dPeriod
    ;

    for z_rLoopForm2 in
        select distinct
            xa.formid
        from tmp_SLIK_H_Textfile as xa
        order by xa.formid asc

        
    loop
        z_nTotalSegment = (select distinct jumlahdatasegment from tmp_SLIK_H_Textfile where formid = z_rLoopForm2.formid limit 1);
        z_nSumTotal = (select sum(jumlahdata) from tmp_SLIK_H_Textfile where formid = z_rLoopForm2.formid limit 1);
        if z_nTotalSegment <> z_nSumTotal then
            z_cErrMsg = public.serene(1, 'Apabila file di pecah, maka jumlah baris data harus sama dengan jumlah data. Form : ' || z_rLoopForm2.formid || ' Jumlah Data : ' || z_nTotalSegment || ' Jumlah Baris : ' || z_nSumTotal);
            raise exception 'Exception Raised';
        end if;
    end loop;

    z_cFTPIdText =
        FTPId::character varying
        from public.FTP_FILE_TM
        where destinationpathfolder like '%z_pcUserSlik-z_cCurrDate%'
        and flag = 'MDEL'
    ;
    perform public.ftp_process_maintenance
        (
            'MDEL'
            ,z_cFTPIdText::integer
            ,null
        );

    z_cFTPIdText =
        FTPId::character varying
        from public.FTP_FILE_TM
        where destinationpathfolder like '%z_pcUserSlik-z_cCurrDate%'
        and flag = 'RMDIR'
    ;
    perform public.ftp_process_maintenance
        (
            'RMDIR'
            ,z_cFTPIdText::integer
            ,null
        );

    z_cFTPIdText =
        FTPId::character varying
        from public.FTP_FILE_TM
        where destinationpathfolder like '%z_pcUserSlik-z_cCurrDate%'
        and flag = 'MKDIR'
    ;

    perform public.ftp_process_maintenance
        (
            'MKDIR'
            ,z_cFTPIdText::integer
            ,null
        );

    z_cFTPIdText =
        FTPId::character varying
        from public.FTP_FILE_TM
        where destinationpathfolder like '%z_pcUserSlik-z_cCurrDate%'
        and flag = 'U'
    ;

    z_cErrMsg = public.serene(1, 'ftp');

    z_cResult = ' ';

    Z_cResult = public.ftp_process
    (
         z_cFTPIdText::integer -- z_pnftpid - FTP_File_TM.ftpid --
        ,true -- z_pboverwritefile - overwrite destination file <not applicable> --
        ,z_dPeriod -- z_pdperiod - file untuk DWHTXT selalu null, ini mempengaruhi nama file yang diberikan tambahan YYYYMMDD --
        ,1 -- z_pndebug - 0 = tidak dicek lagi apakah datanya sudah ada / belum | 1 = dicek ulang apakah datanya sudah ada / belum --
        ,null -- z_pcfilepassword - password for zip --
    );

    raise notice '%', z_cResult;

    if (Z_cResult <> '0') then
        z_bFTP = false;
    else
        z_bFTP = true;
    end if;

    raise notice 'textfile %', z_bTextfile;
    raise notice 'textfile %', z_bFTP;

    ---- ini untuk status data yang di custom textfile ----
    ---- jika user pilihnya textfile nya ALL data , di table probi.slik_listdatamanultextfile ini datanya tidak muncul ketika di custom file ----
    if lower(z_cstatustexfile) = 'all'
    then
        ---update yang data customnya flag textfilenya  dianggap berhasil
        update probi.slik_listdatamanultextfile as xz
        set
             statustextfile = 'N'
            ,gettextfile = 'Y'
            ,isfinish = 'Y - ALL'
        where xz.period = z_dPeriod
        and xz.statuskantor = z_cStatusIdKantor
        and xz.statustextfile = 'Y'
        ;
    ---- update yang data customnya flag textfilenya  dianggap berhasil ----
    else
        update probi.slik_listdatamanultextfile as xz
        set
             statustextfile = 'N'
            ,gettextfile = 'Y'
            ,isfinish = 'Y - CUSTOM'
        where xz.period = z_dPeriod
        and xz.guidcustom = z_cGuidCustom
        and xz.statuskantor = z_cStatusIdKantor
        ;
    end if;

Z_cRecipients = '';
Z_cCCRecipients = '';

select
     Z_cRecipients || COALESCE(xa.recipient, '')
    ,Z_cCCRecipients || COALESCE(xa.ccrecipients, '')
from mis.misemailalertrecipient as xa
where LOWER(TRIM(xa.storedprocedurename)) = LOWER(TRIM(z_cFuncName))
and xa.tipe = 1
into
     Z_cRecipients
    ,Z_cCCRecipients
;

    if (z_bTextfile = false or z_bFTP = false) then
        -- Z_cSubject = 'Error Textfile atau FTP';
        -- Z_cBody = 'Dear All, <br><br>';
        -- Z_cBody = Z_cBody || 'Proses Create textfile atau FTP Error. Mohon dicek kembali. <br><br>';
        -- Z_cBody = Z_cBody || 'Terima kasih. <br>';
        -- Z_cRecipients = z_cUserSlik || '@ ocbcnisp.com;';

        z_cSubject =
            '[SLIK] Proses Textfile atau FTP Gagal Untuk User '
            || z_cUserSlik || ' ('
            || z_cUserSlik || '-'
            || z_cCurrDate || '-'
            || z_cCurrTime || '-'
            || z_cKodeLJK || ')'
        ;

        Z_cBody = '';
        Z_cBody = Z_cBody || 'DH Bapak / Ibu ' || z_cUserName || ', <br><br>';
        Z_cBody = Z_cBody || 'Proses Create textfile atau FTP Error. Mohon dicek kembali. <br><br>';
        Z_cBody = Z_cBody || 'Terima kasih. <br>';
    else
        -- Z_cSubject = 'Proses Textfile dan FTP Berhasil untuk user ';
        -- z_cSubject = Z_cSubject || z_cUserSlik;
        -- Z_cBody = 'Dear All, <br><br>';
        -- Z_cBody = Z_cBody || 'Textfile sudah tersedia di share. Silahkan dicek kembali. <br><br>';
        -- Z_cBody = Z_cBody || 'Terima kasih. <br>';
        -- Z_cRecipients = z_cUserSlik || '@ ocbcnisp.com;';

        select
            xa.jumlahdata::integer as jumlahdata
        from probi.SLIK_H_Textfile as xa
        where xa.guid = z_cGuid
        and xa.formid = 'D01'
        into
            z_nDataCount_01
        ;

        select
            xa.jumlahdata::integer as jumlahdata
        from probi.SLIK_H_Textfile as xa
        where xa.guid = z_cGuid
        and xa.formid = 'D02'
        into
            z_nDataCount_02
        ;

        select
            xa.jumlahdata::integer as jumlahdata
        from probi.SLIK_H_Textfile as xa
        where xa.guid = z_cGuid
        and xa.formid = 'F01'
        into
            z_nDataCount_03
        ;

        select
            xa.jumlahdata::integer as jumlahdata
        from probi.SLIK_H_Textfile as xa
        where xa.guid = z_cGuid
        and xa.formid = 'F02'
        into
            z_nDataCount_04
        ;

        select
            xa.jumlahdata::integer as jumlahdata
        from probi.SLIK_H_Textfile as xa
        where xa.guid = z_cGuid
        and xa.formid = 'F03'
        into
            z_nDataCount_05
        ;

        select
            xa.jumlahdata::integer as jumlahdata
        from probi.SLIK_H_Textfile as xa
        where xa.guid = z_cGuid
        and xa.formid = 'F04'
        into
            z_nDataCount_06
        ;

        select
            xa.jumlahdata::integer as jumlahdata
        from probi.SLIK_H_Textfile as xa
        where xa.guid = z_cGuid
        and xa.formid = 'F05'
        into
            z_nDataCount_07
        ;

        select
            xa.jumlahdata::integer as jumlahdata
        from probi.SLIK_H_Textfile as xa
        where xa.guid = z_cGuid
        and xa.formid = 'F06'
        into
            z_nDataCount_08
        ;

        select
            xa.jumlahdata::integer as jumlahdata
        from probi.SLIK_H_Textfile as xa
        where xa.guid = z_cGuid
        and xa.formid = 'A01'
        into
            z_nDataCount_09
        ;

        select
            xa.jumlahdata::integer as jumlahdata
        from probi.SLIK_H_Textfile as xa
        where xa.guid = z_cGuid
        and xa.formid = 'P01'
        into
            z_nDataCount_10
        ;

        select
            xa.jumlahdata::integer as jumlahdata
        from probi.SLIK_H_Textfile as xa
        where xa.guid = z_cGuid
        and xa.formid = 'M01'
        into
            z_nDataCount_11
        ;

        select
            xa.jumlahdata::integer as jumlahdata
        from probi.SLIK_H_Textfile as xa
        where xa.guid = z_cGuid
        and xa.formid = 'K01'
        into
            z_nDataCount_12
        ;

        select
            sum(xa.jumlahdata::integer) as jumlahdata
        from probi.SLIK_H_Textfile as xa
        where xa.guid = z_cGuid
        into
            z_nDataCount_13
        ;

        Z_cSubject =
            '[SLIK] Proses Textfile dan FTP Berhasil Untuk User '
            || z_cUserSlik || ' ('
            || z_cUserSlik || '-'
            || z_cCurrDate || '-'
            || z_cCurrTime || '-'
            || z_cKodeLJK || ')'
        ;

        Z_cBody = '';
        Z_cBody = Z_cBody || 'DH Bapak / Ibu ' || z_cUserName || ', <br><br>';
        Z_cBody = Z_cBody || 'Textfile sudah tersedia di share. Silahkan dicek kembali. <br><br>';
        Z_cBody = Z_cBody || '<table border=0>';
        Z_cBody = Z_cBody || '  <tr>';
        Z_cBody = Z_cBody || '      <td colspan=3>Keterangan Jumlah Data</td>';
        Z_cBody = Z_cBody || '  </tr>';
        Z_cBody = Z_cBody || '  <tr>';
        Z_cBody = Z_cBody || '      <td>D01</td>';
        Z_cBody = Z_cBody || '      <td>:</td>';
        Z_cBody = Z_cBody || '      <td>' || z_nDataCount_01 || '</td>';
        Z_cBody = Z_cBody || '  </tr>';
        Z_cBody = Z_cBody || '  <tr>';
        Z_cBody = Z_cBody || '      <td>D02</td>';
        Z_cBody = Z_cBody || '      <td>:</td>';
        Z_cBody = Z_cBody || '      <td>' || z_nDataCount_02 || '</td>';
        Z_cBody = Z_cBody || '  </tr>';
        Z_cBody = Z_cBody || '  <tr>';
        Z_cBody = Z_cBody || '      <td>F01</td>';
        Z_cBody = Z_cBody || '      <td>:</td>';
        Z_cBody = Z_cBody || '      <td>' || z_nDataCount_03 || '</td>';
        Z_cBody = Z_cBody || '  </tr>';
        Z_cBody = Z_cBody || '  <tr>';
        Z_cBody = Z_cBody || '      <td>F02</td>';
        Z_cBody = Z_cBody || '      <td>:</td>';
        Z_cBody = Z_cBody || '      <td>' || z_nDataCount_04 || '</td>';
        Z_cBody = Z_cBody || '  </tr>';
        Z_cBody = Z_cBody || '  <tr>';
        Z_cBody = Z_cBody || '      <td>F03</td>';
        Z_cBody = Z_cBody || '      <td>:</td>';
        Z_cBody = Z_cBody || '      <td>' || z_nDataCount_05 || '</td>';
        Z_cBody = Z_cBody || '  </tr>';
        Z_cBody = Z_cBody || '  <tr>';
        Z_cBody = Z_cBody || '      <td>F04</td>';
        Z_cBody = Z_cBody || '      <td>:</td>';
        Z_cBody = Z_cBody || '      <td>' || z_nDataCount_06 || '</td>';
        Z_cBody = Z_cBody || '  </tr>';
        Z_cBody = Z_cBody || '  <tr>';
        Z_cBody = Z_cBody || '      <td>F05</td>';
        Z_cBody = Z_cBody || '      <td>:</td>';
        Z_cBody = Z_cBody || '      <td>' || z_nDataCount_07 || '</td>';
        Z_cBody = Z_cBody || '  </tr>';
        Z_cBody = Z_cBody || '  <tr>';
        Z_cBody = Z_cBody || '      <td>F06</td>';
        Z_cBody = Z_cBody || '      <td>:</td>';
        Z_cBody = Z_cBody || '      <td>' || z_nDataCount_08 || '</td>';
        Z_cBody = Z_cBody || '  </tr>';
        Z_cBody = Z_cBody || '  <tr>';
        Z_cBody = Z_cBody || '      <td>A01</td>';
        Z_cBody = Z_cBody || '      <td>:</td>';
        Z_cBody = Z_cBody || '      <td>' || z_nDataCount_09 || '</td>';
        Z_cBody = Z_cBody || '  </tr>';
        Z_cBody = Z_cBody || '  <tr>';
        Z_cBody = Z_cBody || '      <td>P01</td>';
        Z_cBody = Z_cBody || '      <td>:</td>';
        Z_cBody = Z_cBody || '      <td>' || z_nDataCount_10 || '</td>';
        Z_cBody = Z_cBody || '  </tr>';
        Z_cBody = Z_cBody || '  <tr>';
        Z_cBody = Z_cBody || '      <td>M01</td>';
        Z_cBody = Z_cBody || '      <td>:</td>';
        Z_cBody = Z_cBody || '      <td>' || z_nDataCount_11 || '</td>';
        Z_cBody = Z_cBody || '  </tr>';
        Z_cBody = Z_cBody || '  <tr>';
        Z_cBody = Z_cBody || '      <td>K01</td>';
        Z_cBody = Z_cBody || '      <td>:</td>';
        Z_cBody = Z_cBody || '      <td>' || z_nDataCount_12 || '</td>';
        Z_cBody = Z_cBody || '  </tr>';
        Z_cBody = Z_cBody || '  <tr>';
        Z_cBody = Z_cBody || '      <td>Total</td>';
        Z_cBody = Z_cBody || '      <td>:</td>';
        Z_cBody = Z_cBody || '      <td>' || z_nDataCount_13 || '</td>';
        Z_cBody = Z_cBody || '  </tr>';
        Z_cBody = Z_cBody || '</table> <br>';
        Z_cBody = Z_cBody || 'Terima kasih. <br>';
    end if;

    z_cErrMsg = public.serene(1, 'send mail');
    perform public.dca_sendmail2
    (
         Z_cRecipients -- receiver --
        ,Z_cSubject -- subject --
        ,Z_cBody -- send_message --
        ,Z_cCCRecipients
        ,null
    );
end if;

return 0;

----------------------------------------------------------------------------------------------------------
-- Exception --
----------------------------------------------------------------------------------------------------------
EXCEPTION
when OTHERS then
z_cFuncName = COALESCE(z_cFuncName, '[UNSPECIFIED FUNCTION NAME]');
z_cErrMsg   = COALESCE(z_cErrMsg, 'Error#00 - Unspecified Error. Please review the function definition.');
z_cSQLState = SQLSTATE;
z_cSQLMsg   = SQLERRM;
z_cUser     = USER;

perform public.DailyProcessErrorMessageInsert
(
     z_cFuncName -- z_pcFunctionName --
    ,z_cErrMsg -- z_pcErrorMessage --
    ,z_cSQLState -- z_pcSQLErrNo --
    ,z_cSQLMsg -- z_pcSQLErrMessage --
    ,z_cUser -- z_pcUserId --
);

raise EXCEPTION '[ERROR - %]: % | % - %', z_cFuncName, z_cErrMsg, z_cSQLState, z_cSQLMsg;

return 1;

----------------------------------------------------------------------------------------------------------
-- Object Usage List --
----------------------------------------------------------------------------------------------------------
/*
-- Table --
probi.SLIK_F_OrderList
probi.SLIK_ParamFormList
probi.SLIK_ParamReportGroup
mis.misemailalertrecipient
public.FTP_FILE_TM

-- Function --
probi.SLIK_SendReport_TextfileCreate
public.ftp_process

-- Result --
probi.SLIK_F_OrderList
probi.SLIK_H_Textfile
*/
--========================================================================================================
END;--FUNCTION--
--========================================================================================================
$BODY$
language plpgsql volatile;
please remove this line if you wish to create or replace this function
"