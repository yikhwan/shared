"create or replace function probi.slik_sendreport_textfilecreate
(
     z_pdperiod date
    ,z_pcuserslik character varying
    ,z_pcform character varying
    ,z_pcstatusidkantor character varying
)
returns integer
as
$BODY$
----------------------------------------------------------------------------------------------------------
-- Variable Declaration --
----------------------------------------------------------------------------------------------------------
declare
---- system variable ----
z_cFuncName             character varying;
z_cErrMsg               character varying;
z_cSQLState             character varying;
z_cSQLMsg               character varying;
z_cUser                 character varying;
z_cQuery                character varying;
z_cColumnList           character varying;

---- procedure variable ----
z_dCurrEOD              date;
z_cUserSLIK             character varying;
z_dPeriod               date;
z_cForm                 character varying;
z_cStatusIdKantor       character varying;
z_nTotalD01             integer;
z_cHeader               character varying;
z_cTahun                character varying;
z_cBulan                character varying;
z_cKodeLJK              character varying;
z_cSandiLJK             character varying;
z_nTotalRow             integer;
z_nTotalSegmentData     integer;

--========================================================================================================
BEGIN--FUNCTION--
--========================================================================================================
----------------------------------------------------------------------------------------------------------
-- Variable Assignment --
----------------------------------------------------------------------------------------------------------
z_cFuncName = 'SLIK_SendReport_TextfileCreate';

select
    xa.ops_date
from ads.DOPS_Parameters as xa
into
    z_dCurrEOD
;

z_cUserSlik = z_pcUserSlik;
z_dPeriod = coalesce(z_pdPeriod, '19000101');
z_cForm = z_pcForm;
z_cStatusIdKantor = z_pcStatusIdKantor;
z_cTahun = to_char(z_dPeriod, 'yyyy');
z_cBulan = to_char(z_dPeriod, 'mm');
z_nTotalRow = 0;
z_cKodeLJK =
    case
        when z_cStatusIdKantor = 'K' then '0101'
        else '0102'
    end
;
z_cSandiLJK = '028';

----------------------------------------------------------------------------------------------------------
-- Variable Debug --
----------------------------------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------------
-- Preliminary Validation --
----------------------------------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------------
-- Temporary Procedure Table Declaration --
----------------------------------------------------------------------------------------------------------
z_cErrMsg = public.serene(1, '010');

z_cErrMsg = public.serene(1, 'Gagal create temp table tmp_TextFile!');
perform public.fnDropTemporaryTable('tmp_TextFile');
create temporary table tmp_TextFile
(
     txt            character varying not null
    ,rowid          integer
    ,rowcount       integer
    ,totalsegment   integer
    ,kodeljk        character varying
)
distributed randomly;

z_cErrMsg = public.serene(1, 'Gagal create temp table tmp_SLIK_Group_Pelaporan!');
perform public.fnDropTemporaryTable('tmp_SLIK_Group_Pelaporan');
create temporary table tmp_SLIK_Group_Pelaporan
(
    BIBankID    character varying
)
distributed randomly;

z_cErrMsg = public.serene(1, 'Gagal create temp table tmp_Customer!');
perform public.fnDropTemporaryTable('tmp_Customer');
create temporary table tmp_Customer
(
     cif                character varying
    ,idkantorcabang     character varying
)
distributed randomly;

z_cErrMsg = public.serene(1, 'Gagal create temp table tmp_CustomerAll!');
perform public.fnDropTemporaryTable('tmp_CustomerAll');
create temporary table tmp_CustomerAll
(
     cif                character varying
    ,idkantorcabang     character varying
)
distributed randomly;

----------------------------------------------------------------------------------------------------------
-- Temporary Source Table Declaration --
----------------------------------------------------------------------------------------------------------
z_cErrMsg = public.serene(1, '020');

-- ads.office_information_v --
z_cErrMsg = public.serene(1, 'Gagal create temp table tmp_office_information!');
perform public.fnDropTemporaryTable('tmp_office_information');
create temporary table tmp_office_information
(
     bi_bank_id      character varying
)
distributed randomly;

z_cErrMsg = public.serene(1, 'Gagal insert temp table tmp_office_information!');
insert into tmp_office_information
(
     bi_bank_id
)
select distinct
     public.util_right(xa.bi_bank_id, 3) as bi_bank_id
from ads.office_information_v as xa
where xa.scd_end = z_dPeriod
and case
        when xa.office_id_sibs like '7%' and length(xa.office_id_sibs) = 5 then 'S'
        else 'K'
    end = z_cStatusIdKantor
;

----------------------------------------------------------------------------------------------------------
-- Main Process --
----------------------------------------------------------------------------------------------------------
z_cErrMsg = public.serene(1, '030');

z_cErrMsg = public.serene(1, 'Gagal insert temp table tmp_SLIK_Group_Pelaporan!');
insert into tmp_SLIK_Group_Pelaporan
(
     BIBankId
)
select distinct
     xb.BI_Bank_Id as BIBankId
from probi.SLIK_ParamReportGroup as xa
inner join tmp_office_information as xb
    on  public.util_right(xa.BIBankId, 3) = xb.bi_bank_id

;

z_cErrMsg = public.serene(1, 'Gagal insert temp table tmp_Customer!');
insert into tmp_Customer
(
     cif
    ,idkantorcabang
)
select distinct
     xa.cif as cif
    ,xa.kodekantorcabang as idkantorcabang
from probi.SLIK_F_D01 as xa
inner join tmp_SLIK_Group_Pelaporan as xb
    on  xa.kodekantorcabang = xb.BIBankId
where xa.period = z_dPeriod
union all
select distinct
     xa.cif as cif
    ,xa.kodekantorcabang as idkantorcabang
from probi.SLIK_F_D02 as xa
inner join tmp_SLIK_Group_Pelaporan as xb
    on  xa.kodekantorcabang = xb.BIBankId
where xa.period = z_dPeriod
;

z_cErrMsg = public.serene(1, 'Gagal insert temp table tmp_CustomerAll!');
insert into tmp_CustomerAll
(
     cif
    ,idkantorcabang
)
select distinct
     xa.cif as cif
    ,xa.kodekantorcabang as idkantorcabang
from probi.SLIK_F_D01 as xa
where xa.period = z_dPeriod
union all
select distinct
     xa.cif as cif
    ,xa.kodekantorcabang as idkantorcabang
from probi.SLIK_F_D02 as xa
where xa.period = z_dPeriod
;

-- header
z_cErrMsg = public.serene(1, 'Gagal insert temp table tmp_TextFile (1)!');
insert into tmp_TextFile
(
     txt
    ,rowid
)
select
     '%HeaderTextFile%' as txt
    ,1 as rowid
;

-- body
z_nTotalSegmentData =
    case
        when z_cForm = 'D01' then
            (
                select count(1)
                from probi.SLIK_F_D01 as xa
                inner join tmp_CustomerAll as xb
                    on  xa.cif = xb.cif
                    and xb.idkantorcabang = xa.kodekantorcabang
                inner join tmp_office_information as xc
                    on  xb.idkantorcabang = xc.bi_bank_id
                where xa.period = z_dPeriod
            )
        when z_cForm = 'D02' then
            (
                select count(1)
                from probi.SLIK_F_D02 as xa
                inner join tmp_CustomerAll as xb
                    on  xa.cif = xb.cif
                    and xb.idkantorcabang = xa.kodekantorcabang
                inner join tmp_office_information as xc
                    on  xb.idkantorcabang = xc.bi_bank_id
                where xa.period = z_dPeriod
            )
        when z_cForm = 'F01' then
            (
                select count(1)
                from probi.SLIK_F_F01 as xa
                inner join tmp_CustomerAll as xb
                    on  xa.cif = xb.cif
                inner join tmp_office_information as xc
                    on  xb.idkantorcabang = xc.bi_bank_id
                where xa.period = z_dPeriod
            )
        when z_cForm = 'F02' then
            (
                select count(1)
                from probi.SLIK_F_F02 as xa
                inner join tmp_CustomerAll as xb
                    on  xa.cif = xb.cif
                inner join tmp_office_information as xc
                    on  xb.idkantorcabang = xc.bi_bank_id
                where xa.period = z_dPeriod
            )
        when z_cForm = 'F03' then
            (
                select count(1)
                from probi.SLIK_F_F03 as xa
                inner join tmp_CustomerAll as xb
                    on  xa.cif = xb.cif
                inner join tmp_office_information as xc
                    on  xb.idkantorcabang = xc.bi_bank_id
                where xa.period = z_dPeriod
                and xa.statussyariah = case
                                           when z_cStatusIdKantor = 'S' then 'Y'
                                           else 'T'
                                       end
            )
        when z_cForm = 'F04' then
            (
                select count(1)
                from probi.SLIK_F_F04 as xa
                inner join tmp_CustomerAll as xb
                    on  xa.cif = xb.cif
                inner join tmp_office_information as xc
                    on  xb.idkantorcabang = xc.bi_bank_id
                where xa.period = z_dPeriod
            )
        when z_cForm = 'F05' then
            (
                select count(1)
                from probi.SLIK_F_F05 as xa
                inner join tmp_CustomerAll as xb
                    on  xa.cif = xb.cif
                inner join tmp_office_information as xc
                    on  xb.idkantorcabang = xc.bi_bank_id
                where xa.period = z_dPeriod
            )
        when z_cForm = 'F06' then
            (
                select count(1)
                from probi.SLIK_F_F06 as xa
                inner join tmp_CustomerAll as xb
                    on  xa.cif = xb.cif
                inner join tmp_office_information as xc
                    on  xb.idkantorcabang = xc.bi_bank_id
                where xa.period = z_dPeriod
                and xa.statussyariah = case
                                           when z_cStatusIdKantor = 'S' then 'Y'
                                           else 'T'
                                       end
            )
        when z_cForm = 'A01' then
            (
                select count(1)
                from probi.SLIK_F_A01 as xa
                inner join tmp_CustomerAll as xb
                    on  xa.cif = xb.cif
                inner join tmp_office_information as xc
                    on  xb.idkantorcabang = xc.bi_bank_id
                where xa.period = z_dPeriod
            )
        when z_cForm = 'P01' then
            (
                select count(1)
                from probi.SLIK_F_P01 as xa
                inner join tmp_CustomerAll as xb
                    on  xa.cif = xb.cif
                inner join tmp_office_information as xc
                    on  xb.idkantorcabang = xc.bi_bank_id
                where xa.period = z_dPeriod
            )
        when z_cForm = 'M01' then
            (
                select count(1)
                from probi.SLIK_F_M01 as xa
                inner join tmp_CustomerAll as xb
                    on  xa.cif = xb.cif
                    and xb.idkantorcabang = xa.kodekantorcabang
                inner join tmp_office_information as xc
                    on  xb.idkantorcabang = xc.bi_bank_id
                where xa.period = z_dPeriod
            )
        when z_cForm = 'K01' then
            (
                select count(1)
                from probi.SLIK_F_K01 as xa
                inner join tmp_CustomerAll as xb
                    on  xa.cif = xb.cif
                    and xb.idkantorcabang = xa.kodekantorcabang
                inner join tmp_office_information as xc
                    on  xb.idkantorcabang = xc.bi_bank_id
                where xa.period = z_dPeriod
            )
        when z_cForm = 'S01' then
            (
                select count(1)
                from probi.SLIK_F_Summary as xa
                inner join tmp_CustomerAll as xb
                    on  xa.cif = xb.cif
                inner join tmp_office_information as xc
                    on  xb.idkantorcabang = xc.bi_bank_id
                where xa.period = z_dPeriod
            )
        else 0
    end
;

-- D01
z_cErrMsg = public.serene(1, 'Gagal insert temp table tmp_TextFile (2)!');
insert into tmp_TextFile
(
     txt
    ,rowid
)
select
               coalesce(xa.flagdetail, '')
     || '|' || coalesce(xa.cif, '')
     || '|' || coalesce(xa.jenisidentitas, '')
     || '|' || coalesce(xa.nikpassport, '')
     || '|' || coalesce(xa.namasesuaiidentitas, '')
     || '|' || coalesce(xa.namalengkap, '')
     || '|' || coalesce(xa.kodestatusgelardebitur, '')
     || '|' || coalesce(xa.jeniskelamin, '')
     || '|' || coalesce(xa.tempatlahirktp, '')
     || '|' || coalesce(xa.tanggallahir, '')
     || '|' || coalesce(xa.npwp, '')
     || '|' || coalesce(xa.alamat, '')
     || '|' || coalesce(xa.kelurahan, '')
     || '|' || coalesce(xa.kecamatan, '')
     || '|' || coalesce(xa.kodedatiii, '')
     || '|' || coalesce(xa.kodepos, '')
     || '|' || coalesce(xa.telepon, '')
     || '|' || coalesce(xa.nomortelepongenggam, '')
     || '|' || coalesce(xa.alamatemail, '')
     || '|' || coalesce(xa.kodenegara, '')
     || '|' || coalesce(xa.kodepekerjaan, '')
     || '|' || coalesce(xa.tempatbekerja, '')
     || '|' || coalesce(xa.kodebidangusaha, '')
     || '|' || coalesce(xa.alamattempatbekerja, '')
     || '|' || coalesce(xa.penghasilankotorpertahun, '')
     || '|' || coalesce(xa.kodesumberpenghasilan, '')
     || '|' || coalesce(xa.jumlahtanggungan, '')
     || '|' || coalesce(xa.kodehubungandenganljk, '')
     || '|' || coalesce(xa.kodegolongandebitur, '')
     || '|' || coalesce(xa.statusperkawinandebitur, '')
     || '|' || coalesce(xa.nikpassportpasangan, '')
     || '|' || coalesce(xa.namapasangan, '')
     || '|' || coalesce(xa.tanggallahirpasangan, '')
     || '|' || coalesce(xa.perjanjianpisahharta, '')
     || '|' || coalesce(xa.melanggarbm, '')
     || '|' || coalesce(xa.melampauibm, '')
     || '|' || coalesce(xa.namagadisibukandung, '')
     || '|' || coalesce(xa.kodekantorcabang, '')
     || '|' || coalesce(xa.operationdata, '')
     as txt
    ,row_number() over (order by xa.cif asc, xa.nikpassport asc) + 1 as rowid
from probi.SLIK_F_D01 as xa
inner join tmp_SLIK_Group_Pelaporan as xb
    on  xa.kodekantorcabang = xb.BIBankId
where xa.period = z_dPeriod
and z_cForm = 'D01'
;

-- D02
z_cErrMsg = public.serene(1, 'Gagal insert temp table tmp_TextFile (3)!');
insert into tmp_TextFile
(
     txt
    ,rowid
)
select
               coalesce(xa.flagdetail, '')
     || '|' || coalesce(xa.cif, '')
     || '|' || coalesce(xa.noidentitasbadanusaha, '')
     || '|' || coalesce(xa.namabadanusaha, '')
     || '|' || coalesce(xa.kodejenisbadanusaha, '')
     || '|' || coalesce(xa.tempatpendirian, '')
     || '|' || coalesce(xa.noaktependirian, '')
     || '|' || coalesce(xa.tanggalaktependirian, '')
     || '|' || coalesce(xa.noakteperubahanterakhir, '')
     || '|' || coalesce(xa.tanggalakteperubahanterakhir, '')
     || '|' || coalesce(xa.telepon, '')
     || '|' || coalesce(xa.nomortelepongenggam, '')
     || '|' || coalesce(xa.alamatemail, '')
     || '|' || coalesce(xa.alamat, '')
     || '|' || coalesce(xa.kelurahan, '')
     || '|' || coalesce(xa.kecamatan, '')
     || '|' || coalesce(xa.kodedatiii, '')
     || '|' || coalesce(xa.kodepos, '')
     || '|' || coalesce(xa.kodenegara, '')
     || '|' || coalesce(xa.kodebidangusaha, '')
     || '|' || coalesce(xa.kodehubungandenganljk, '')
     || '|' || coalesce(xa.melanggarbm, '')
     || '|' || coalesce(xa.melampauibm, '')
     || '|' || coalesce(xa.gopublic, '')
     || '|' || coalesce(xa.kodegolongandebitur, '')
     || '|' || coalesce(xa.peringkatdebitur, '')
     || '|' || coalesce(xa.lembagapemeringkat, '')
     || '|' || coalesce(xa.tanggalpemeringkatan, '')
     || '|' || coalesce(xa.namagroupdebitur, '')
     || '|' || coalesce(xa.kodekantorcabang, '')
     || '|' || coalesce(xa.operasidata, '')
     as txt
    ,row_number() over (order by xa.cif asc, xa.noidentitasbadanusaha asc) + 1 as rowid
from probi.SLIK_F_D02 as xa
inner join tmp_SLIK_Group_Pelaporan as xb
    on  xa.kodekantorcabang = xb.BIBankId
where xa.period = z_dPeriod
and z_cForm = 'D02'
;

-- F01
z_cErrMsg = public.serene(1, 'Gagal insert temp table tmp_TextFile (4)!');
insert into tmp_TextFile
(
     txt
    ,rowid
)
select
               coalesce(xa.flagdetail, '')
     || '|' || coalesce(xa.norekening, '')
     || '|' || coalesce(xa.cif, '')
     || '|' || coalesce(xa.kodesifatkredit, '')
     || '|' || coalesce(xa.kodejeniskredit, '')
     || '|' || coalesce(xa.kodeskimakadpembiayaan, '')
     || '|' || coalesce(xa.noakadawal, '')
     || '|' || coalesce(xa.tanggalakadawal, '')
     || '|' || coalesce(xa.noakadakhir, '')
     || '|' || coalesce(xa.tanggalakadakhir, '')
     || '|' || coalesce(xa.baruperpanjangan, '')
     || '|' || coalesce(xa.tanggalawalkredit, '')
     || '|' || coalesce(xa.tanggalmulai, '')
     || '|' || coalesce(xa.tanggaljatuhtempo, '')
     || '|' || coalesce(xa.kodekategoridebitur, '')
     || '|' || coalesce(xa.kodejenispenggunaan, '')
     || '|' || coalesce(xa.kodeorientasipenggunaan, '')
     || '|' || coalesce(xa.kodesektorekonomi, '')
     || '|' || coalesce(xa.dati2lokasiproyek, '')
     || '|' || coalesce(xa.nilaiproyek, '')
     || '|' || coalesce(xa.kodevaluta, '')
     || '|' || coalesce(xa.prosentasisukubungaimbalan, '')
     || '|' || coalesce(xa.jenissukubungaimbalan, '')
     || '|' || coalesce(xa.kreditprogrampemerintah, '')
     || '|' || coalesce(xa.takeoverdari, '')
     || '|' || coalesce(xa.sumberdana, '')
     || '|' || coalesce(xa.plafonawal, '')
     || '|' || coalesce(xa.plafon, '')
     || '|' || coalesce(xa.realisasipencairanbulanberjalan, '')
     || '|' || coalesce(xa.denda, '')
     || '|' || coalesce(xa.bakidebet, '')
     || '|' || coalesce(xa.nilaidalammatauangasal, '')
     || '|' || coalesce(xa.kodekolektibilitas, '')
     || '|' || coalesce(xa.tanggalmacet, '')
     || '|' || coalesce(xa.kodesebabmacet, '')
     || '|' || coalesce(xa.tunggakanpokok, '')
     || '|' || coalesce(xa.tunggakanbunga, '')
     || '|' || coalesce(xa.jumlahharitunggakan, '')
     || '|' || coalesce(xa.frekuensitunggakan, '')
     || '|' || coalesce(xa.frekuensirestrukturisasi, '')
     || '|' || coalesce(xa.tanggalrestrukturisasiawal, '')
     || '|' || coalesce(xa.tanggalrestrukturisasiakhir, '')
     || '|' || coalesce(xa.kodecararestrukturisasi, '')
     || '|' || coalesce(xa.kodekondisi, '')
     || '|' || coalesce(xa.tanggalkondisi, '')
     || '|' || coalesce(xa.keterangan, '')
     || '|' || coalesce(xa.kodekantorcabang, '')
     || '|' || coalesce(xa.operasidata, '')
     as txt
    ,row_number() over (order by xa.cif asc, xa.norekening asc) + 1 as rowid
from probi.SLIK_F_F01 as xa
inner join tmp_Customer as xb
    on  xa.cif = xb.cif
where xa.period = z_dPeriod
and z_cForm = 'F01'
;

-- F02
z_cErrMsg = public.serene(1, 'Gagal insert temp table tmp_TextFile (5)!');
insert into tmp_TextFile
(
     txt
    ,rowid
)
select
               coalesce(xa.flagdetail, '')
     || '|' || coalesce(xa.norekening, '')
     || '|' || coalesce(xa.cif, '')
     || '|' || coalesce(xa.SequenceDebiturAnggotaJoinAccount, '')
     || '|' || coalesce(xa.kodesifatkredit, '')
     || '|' || coalesce(xa.kodejeniskredit, '')
     || '|' || coalesce(xa.kodeskimakadpembiayaan, '')
     || '|' || coalesce(xa.noakadawal, '')
     || '|' || coalesce(xa.tanggalakadawal, '')
     || '|' || coalesce(xa.noakadakhir, '')
     || '|' || coalesce(xa.tanggalakadakhir, '')
     || '|' || coalesce(xa.baruperpanjangan, '')
     || '|' || coalesce(xa.tanggalawalkredit, '')
     || '|' || coalesce(xa.tanggalmulai, '')
     || '|' || coalesce(xa.tanggaljatuhtempo, '')
     || '|' || coalesce(xa.kodekategoridebitur, '')
     || '|' || coalesce(xa.kodejenispenggunaan, '')
     || '|' || coalesce(xa.kodeorientasipenggunaan, '')
     || '|' || coalesce(xa.kodesektorekonomi, '')
     || '|' || coalesce(xa.dati2lokasiproyek, '')
     || '|' || coalesce(xa.nilaiproyek, '')
     || '|' || coalesce(xa.kodevaluta, '')
     || '|' || coalesce(xa.prosentasisukubungaimbalan, '')
     || '|' || coalesce(xa.jenissukubungaimbalan, '')
     || '|' || coalesce(xa.kreditprogrampemerintah, '')
     || '|' || coalesce(xa.takeoverdari, '')
     || '|' || coalesce(xa.sumberdana, '')
     || '|' || coalesce(xa.plafonawal, '')
     || '|' || coalesce(xa.plafon, '')
     || '|' || coalesce(xa.realisasipencairanbulanberjalan, '')
     || '|' || coalesce(xa.denda, '')
     || '|' || coalesce(xa.bakidebet, '')
     || '|' || coalesce(xa.nilaidalammatauangasal, '')
     || '|' || coalesce(xa.kodekolektibilitas, '')
     || '|' || coalesce(xa.tanggalmacet, '')
     || '|' || coalesce(xa.kodesebabmacet, '')
     || '|' || coalesce(xa.tunggakanpokok, '')
     || '|' || coalesce(xa.tunggakanbunga, '')
     || '|' || coalesce(xa.jumlahharitunggakan, '')
     || '|' || coalesce(xa.frekuensitunggakan, '')
     || '|' || coalesce(xa.frekuensirestrukturisasi, '')
     || '|' || coalesce(xa.tanggalrestrukturisasiawal, '')
     || '|' || coalesce(xa.tanggalrestrukturisasiakhir, '')
     || '|' || coalesce(xa.kodecararestrukturisasi, '')
     || '|' || coalesce(xa.kodekondisi, '')
     || '|' || coalesce(xa.tanggalkondisi, '')
     || '|' || coalesce(xa.keterangan, '')
     || '|' || coalesce(xa.kodekantorcabang, '')
     || '|' || coalesce(xa.operasidata, '')
     as txt
    ,row_number() over (order by xa.cif asc, xa.norekening asc) + 1 as rowid
from probi.SLIK_F_F02 as xa
inner join tmp_Customer as xb
    on  xa.cif = xb.cif
where xa.period = z_dPeriod
and z_cForm = 'F02'
;

-- F03
z_cErrMsg = public.serene(1, 'Gagal insert temp table tmp_TextFile (6)!');
insert into tmp_TextFile
(
     txt
    ,rowid
)
select
               coalesce(xa.flagdetail, '')
     || '|' || coalesce(xa.norekening, '')
     || '|' || coalesce(xa.cif, '')
     || '|' || coalesce(xa.kodejenissuratberharga, '')
     || '|' || coalesce(xa.sovereignrate, '')
     || '|' || coalesce(xa.listing, '')
     || '|' || coalesce(xa.peringkatsuratberharga, '')
     || '|' || coalesce(xa.kodetujuankepemilikan, '')
     || '|' || coalesce(xa.tanggalterbit, '')
     || '|' || coalesce(xa.tanggalbeli, '')
     || '|' || coalesce(xa.tanggaljatuhtempo, '')
     || '|' || coalesce(xa.kodevaluta, '')
     || '|' || coalesce(xa.nominal, '')
     || '|' || coalesce(xa.nilaidalammatauangasal, '')
     || '|' || coalesce(xa.nilaipasar, '')
     || '|' || coalesce(xa.nilaiperolehan, '')
     || '|' || coalesce(xa.sukubungaimbalan, '')
     || '|' || coalesce(xa.tunggakan, '')
     || '|' || coalesce(xa.jumlahharitunggakan, '')
     || '|' || coalesce(xa.kodekolektibilitas, '')
     || '|' || coalesce(xa.tanggalmacet, '')
     || '|' || coalesce(xa.kodesebabmacet, '')
     || '|' || coalesce(xa.kodekondisi, '')
     || '|' || coalesce(xa.tanggalkondisi, '')
     || '|' || coalesce(xa.keterangan, '')
     || '|' || coalesce(xa.kodekantorcabang, '')
     || '|' || coalesce(xa.operasidata, '')
     as txt
    ,row_number() over (order by xa.cif asc, xa.norekening asc) + 1 as rowid
from probi.SLIK_F_F03 as xa
inner join tmp_Customer as xb
    on  xa.cif = xb.cif
where xa.period = z_dPeriod
and z_cForm = 'F03'
and xa.statussyariah = case
                           when z_cStatusIdKantor = 'S' then 'Y'
                           else 'T'
                       end
;

-- F04
z_cErrMsg = public.serene(1, 'Gagal insert temp table tmp_TextFile (7)!');
insert into tmp_TextFile
(
     txt
    ,rowid
)
select
               coalesce(xa.flagdetail, '')
     || '|' || coalesce(xa.norekening, '')
     || '|' || coalesce(xa.cif, '')
     || '|' || coalesce(xa.kodejenislc, '')
     || '|' || coalesce(xa.kodetujuanlc, '')
     || '|' || coalesce(xa.tanggalkeluar, '')
     || '|' || coalesce(xa.tanggaljatuhtempo, '')
     || '|' || coalesce(xa.noakadawal, '')
     || '|' || coalesce(xa.tanggalakadawal, '')
     || '|' || coalesce(xa.noakadakhir, '')
     || '|' || coalesce(xa.tanggalakadakhir, '')
     || '|' || coalesce(xa.bankcounterparty, '')
     || '|' || coalesce(xa.kodevaluta, '')
     || '|' || coalesce(xa.plafon, '')
     || '|' || coalesce(xa.nominal, '')
     || '|' || coalesce(xa.setoranjaminan, '')
     || '|' || coalesce(xa.kodekolektibilitas, '')
     || '|' || coalesce(xa.tanggalwanprestasi, '')
     || '|' || coalesce(xa.kodekondisi, '')
     || '|' || coalesce(xa.tanggalkondisi, '')
     || '|' || coalesce(xa.keterangan, '')
     || '|' || coalesce(xa.kodekantorcabang, '')
     || '|' || coalesce(xa.operasidata, '')
     as txt
    ,row_number() over (order by xa.cif asc, xa.norekening asc) + 1 as rowid
from probi.SLIK_F_F04 as xa
inner join tmp_Customer as xb
    on  xa.cif = xb.cif
where xa.period = z_dPeriod
and z_cForm = 'F04'
;

-- F05
z_cErrMsg = public.serene(1, 'Gagal insert temp table tmp_TextFile (8)!');
insert into tmp_TextFile
(
     txt
    ,rowid
)
select
               coalesce(xa.flagdetail, '')
     || '|' || coalesce(xa.norekening, '')
     || '|' || coalesce(xa.cif, '')
     || '|' || coalesce(xa.kodejenisgaransi, '')
     || '|' || coalesce(xa.kodetujuangaransi, '')
     || '|' || coalesce(xa.tanggalterbit, '')
     || '|' || coalesce(xa.tanggaljatuhtempo, '')
     || '|' || coalesce(xa.noakadawal, '')
     || '|' || coalesce(xa.tanggalakadawal, '')
     || '|' || coalesce(xa.noakadakhir, '')
     || '|' || coalesce(xa.tanggalakadakhir, '')
     || '|' || coalesce(xa.namaygdijamin, '')
     || '|' || coalesce(xa.kodevaluta, '')
     || '|' || coalesce(xa.plafon, '')
     || '|' || coalesce(xa.nominal, '')
     || '|' || coalesce(xa.setoranjaminan, '')
     || '|' || coalesce(xa.kodekolektibilitas, '')
     || '|' || coalesce(xa.tanggalwanprestasi, '')
     || '|' || coalesce(xa.kodekondisi, '')
     || '|' || coalesce(xa.tanggalkondisi, '')
     || '|' || coalesce(xa.keterangan, '')
     || '|' || coalesce(xa.kodekantorcabang, '')
     || '|' || coalesce(xa.operasidata, '')
     as txt
    ,row_number() over (order by xa.cif asc, xa.norekening asc) + 1 as rowid
from probi.SLIK_F_F05 as xa
inner join tmp_Customer as xb
    on  xa.cif = xb.cif
where xa.period = z_dPeriod
and z_cForm = 'F05'
;

-- F06
z_cErrMsg = public.serene(1, 'Gagal insert temp table tmp_TextFile (9)!');
insert into tmp_TextFile
(
     txt
    ,rowid
)
select
               coalesce(xa.flagdetail, '')
     || '|' || coalesce(xa.norekening, '')
     || '|' || coalesce(xa.cif, '')
     || '|' || coalesce(xa.kodejenisfasilitas, '')
     || '|' || coalesce(xa.sumberdana, '')
     || '|' || coalesce(xa.tanggalmulai, '')
     || '|' || coalesce(xa.tanggaljatuhtempo, '')
     || '|' || coalesce(xa.sukubungaimbalan, '')
     || '|' || coalesce(xa.kodevaluta, '')
     || '|' || coalesce(xa.nominaljumlahkewajiban, '')
     || '|' || coalesce(xa.nilaidalammatauangasal, '')
     || '|' || coalesce(xa.kodekolektibilitas, '')
     || '|' || coalesce(xa.tanggalmacet, '')
     || '|' || coalesce(xa.kodesebabmacet, '')
     || '|' || coalesce(xa.tunggakan, '')
     || '|' || coalesce(xa.jumlahharitunggakan, '')
     || '|' || coalesce(xa.kodekondisi, '')
     || '|' || coalesce(xa.tanggalkondisi, '')
     || '|' || coalesce(xa.keterangan, '')
     || '|' || coalesce(xa.kodekantorcabang, '')
     || '|' || coalesce(xa.operasidata, '')
     as txt
    ,row_number() over (order by xa.cif asc, xa.norekening asc) + 1 as rowid
from probi.SLIK_F_F06 as xa
inner join tmp_Customer as xb
    on  xa.cif = xb.cif
where xa.period = z_dPeriod
and z_cForm = 'F06'
and xa.statussyariah = case
                           when z_cStatusIdKantor = 'S' then 'Y'
                           else 'T'
                       end
;

-- A01
z_cErrMsg = public.serene(1, 'Gagal insert temp table tmp_TextFile (10)!');
insert into tmp_TextFile
(
     txt
    ,rowid
)
select
               coalesce(xa.flagdetail, '')
     || '|' || coalesce(xa.koderegistrasiagunan, '')
     || '|' || coalesce(xa.norekening, '')
     || '|' || coalesce(xa.cif, '')
     || '|' || coalesce(xa.kodesegmenfasilitas, '')
     || '|' || coalesce(xa.kodestatusagunan, '')
     || '|' || coalesce(xa.kodejenisagunan, '')
     || '|' || coalesce(xa.peringkatagunan, '')
     || '|' || coalesce(xa.kodelembagapemeringkat, '')
     || '|' || coalesce(xa.kodejenispengikatan, '')
     || '|' || coalesce(xa.tanggalpengikatan, '')
     || '|' || coalesce(xa.namapemilikagunan, '')
     || '|' || coalesce(xa.buktikepemilikan, '')
     || '|' || coalesce(xa.alamatagunan, '')
     || '|' || coalesce(xa.kodedatiiiagunan, '')
     || '|' || coalesce(xa.nilaiagunan, '')
     || '|' || coalesce(xa.nilaiagunanmenurutljk, '')
     || '|' || coalesce(xa.tanggalpenilaianljk, '')
     || '|' || coalesce(xa.nilaiagunanpenilaiindependen, '')
     || '|' || coalesce(xa.namapenilaiindependen, '')
     || '|' || coalesce(xa.tanggalpenilaianpenilaiindependen, '')
     || '|' || coalesce(xa.statusparipasu, '')
     || '|' || coalesce(xa.prosentaseparipasu, '')
     || '|' || coalesce(xa.statuskreditjoin, '')
     || '|' || coalesce(xa.diasuransikan, '')
     || '|' || coalesce(xa.keterangan, '')
     || '|' || coalesce(xa.kodekantorcabang, '')
     || '|' || coalesce(xa.operasidata, '')
     as txt
    ,row_number() over (order by xa.cif asc, xa.koderegistrasiagunan asc, xa.norekening asc) + 1 as rowid
from probi.SLIK_F_A01 as xa
inner join tmp_Customer as xb
    on  xa.cif = xb.cif
where xa.period = z_dPeriod
and z_cForm = 'A01'
;

-- P01
z_cErrMsg = public.serene(1, 'Gagal insert temp table tmp_TextFile (11)!');
insert into tmp_TextFile
(
     txt
    ,rowid
)
select
               coalesce(xa.flagdetail, '')
     || '|' || coalesce(xa.noidentitaspenjamin, '')
     || '|' || coalesce(xa.norekening, '')
     || '|' || coalesce(xa.cif, '')
     || '|' || coalesce(xa.kodesegmenfasilitas, '')
     || '|' || coalesce(xa.jenisidentitas, '')
     || '|' || coalesce(xa.namaidentitas, '')
     || '|' || coalesce(xa.namalengkap, '')
     || '|' || coalesce(xa.kodegolonganpenjamin, '')
     || '|' || coalesce(xa.alamatpenjamin, '')
     || '|' || coalesce(xa.prosentasedijamin, '')
     || '|' || coalesce(xa.keterangan, '')
     || '|' || coalesce(xa.kodekantorcabang, '')
     || '|' || coalesce(xa.operasidata, '')
     as txt
    ,row_number() over (order by xa.cif asc, xa.noidentitaspenjamin asc) + 1 as rowid
from probi.SLIK_F_P01 as xa
inner join tmp_Customer as xb
    on  xa.cif = xb.cif
where xa.period = z_dPeriod
and z_cForm = 'P01'
;

-- M01
z_cErrMsg = public.serene(1, 'Gagal insert temp table tmp_TextFile (12)!');
insert into tmp_TextFile
(
     txt
    ,rowid
)
select
               coalesce(xa.flagdetail, '')
     || '|' || coalesce(xa.nomoridentitas, '')
     || '|' || coalesce(xa.cif, '')
     || '|' || coalesce(xa.jenisidentitas, '')
     || '|' || coalesce(xa.namapengurus, '')
     || '|' || coalesce(xa.jeniskelamin, '')
     || '|' || coalesce(xa.alamat, '')
     || '|' || coalesce(xa.kelurahan, '')
     || '|' || coalesce(xa.kecamatan, '')
     || '|' || coalesce(xa.kodedatiii, '')
     || '|' || coalesce(xa.kodejabatan, '')
     || '|' || coalesce(xa.pangsakepemilikan, '')
     || '|' || coalesce(xa.statuspengurus, '')
     || '|' || coalesce(xa.kodekantorcabang, '')
     || '|' || coalesce(xa.operasidata, '')
     as txt
    ,row_number() over (order by xa.cif asc, xa.nomoridentitas asc) + 1 as rowid
from probi.SLIK_F_M01 as xa
inner join tmp_Customer as xb
    on  xa.cif = xb.cif
    and xb.idkantorcabang = xa.kodekantorcabang
where xa.period = z_dPeriod
and z_cForm = 'M01'
;

-- K01
z_cErrMsg = public.serene(1, 'Gagal insert temp table tmp_TextFile (13)!');
insert into tmp_TextFile
(
     txt
    ,rowid
)
select
               coalesce(xa.flagdetail, '')
     || '|' || coalesce(xa.cif, '')
     || '|' || coalesce(xa.posisilaporankeuangantahunan, '')
     || '|' || coalesce(xa.aset, '')
     || '|' || coalesce(xa.asetlancar, '')
     || '|' || coalesce(xa.kasasetlancar, '')
     || '|' || coalesce(xa.piutangusahaasetlancar, '')
     || '|' || coalesce(xa.investasiasetlancar, '')
     || '|' || coalesce(xa.asetlancarlainnya, '')
     || '|' || coalesce(xa.asettidaklancar, '')
     || '|' || coalesce(xa.piutangusahaasettidaklancar, '')
     || '|' || coalesce(xa.investasiasettidaklancar, '')
     || '|' || coalesce(xa.asettidaklancarlainnya, '')
     || '|' || coalesce(xa.liabilitas, '')
     || '|' || coalesce(xa.liabilitasjangkapendek, '')
     || '|' || coalesce(xa.pinjamanjangkapendek, '')
     || '|' || coalesce(xa.utangusahajangkapendek, '')
     || '|' || coalesce(xa.liabilitasjangkapendeklainnya, '')
     || '|' || coalesce(xa.liabilitasjangkapanjang, '')
     || '|' || coalesce(xa.pinjamanjangkapanjang, '')
     || '|' || coalesce(xa.utangusahajangkapanjang, '')
     || '|' || coalesce(xa.liabilitasjangkapanjanglainnya, '')
     || '|' || coalesce(xa.ekuitas, '')
     || '|' || coalesce(xa.pendapatanusaha, '')
     || '|' || coalesce(xa.bebanpokokpendapatan, '')
     || '|' || coalesce(xa.labarugibruto, '')
     || '|' || coalesce(xa.pendapatanlainlain, '')
     || '|' || coalesce(xa.bebanlainlain, '')
     || '|' || coalesce(xa.labarugisebelumpajak, '')
     || '|' || coalesce(xa.labarugiberjalan, '')
     || '|' || coalesce(xa.kodekantorcabang, '')
     || '|' || coalesce(xa.operasidata, '')
     as txt
    ,row_number() over (order by xa.cif asc) + 1 as rowid
from probi.SLIK_f_K01 as xa
inner join tmp_Customer as xb
    on  xa.cif = xb.cif
    and xb.idkantorcabang = xa.kodekantorcabang
where xa.period = z_dPeriod
and z_cForm = 'K01'
;

-- S01
z_cErrMsg = public.serene(1, 'Gagal insert temp table tmp_TextFile (13)!');
insert into tmp_TextFile
(
     txt
    ,rowid
)
select
               coalesce(xa.flagdetail, '')
     || '|' || coalesce(xa.norekening, '')
     || '|' || coalesce(xa.cif, '')
     || '|' || coalesce(xa.kodejenisfasilitas, '')
     || '|' || coalesce(xa.kolektibilitas1, '')
     || '|' || coalesce(xa.haritunggakan1, '')
     || '|' || coalesce(xa.kolektibilitas2, '')
     || '|' || coalesce(xa.haritunggakan2, '')
     || '|' || coalesce(xa.kolektibilitas3, '')
     || '|' || coalesce(xa.haritunggakan3, '')
     || '|' || coalesce(xa.kolektibilitas4, '')
     || '|' || coalesce(xa.haritunggakan4, '')
     || '|' || coalesce(xa.kolektibilitas5, '')
     || '|' || coalesce(xa.haritunggakan5, '')
     || '|' || coalesce(xa.kolektibilitas6, '')
     || '|' || coalesce(xa.haritunggakan6, '')
     || '|' || coalesce(xa.kolektibilitas7, '')
     || '|' || coalesce(xa.haritunggakan7, '')
     || '|' || coalesce(xa.kolektibilitas8, '')
     || '|' || coalesce(xa.haritunggakan8, '')
     || '|' || coalesce(xa.kolektibilitas9, '')
     || '|' || coalesce(xa.haritunggakan9, '')
     || '|' || coalesce(xa.kolektibilitas10, '')
     || '|' || coalesce(xa.haritunggakan10, '')
     || '|' || coalesce(xa.kolektibilitas11, '')
     || '|' || coalesce(xa.haritunggakan11, '')
     || '|' || '' -- coalesce(xa.kolektibilitas12, '')
     || '|' || '' -- coalesce(xa.haritunggakan12, '')
--     || '|' || coalesce(xa.kolektibilitas13, '')
--     || '|' || coalesce(xa.haritunggakan13, '')
     as txt
    ,row_number() over (order by xa.cif asc, xa.norekening asc) + 1 as rowid
from probi.SLIK_f_Summary as xa
inner join tmp_Customer as xb
    on  xa.cif = xb.cif
where xa.period = z_dPeriod
and z_cForm = 'S01'
;

z_nTotalRow =
    count(1)
    from tmp_TextFile
;

z_nTotalRow = z_nTotalRow - 1; -- exclude header

z_cHeader =
            'H'
  || '|' || z_cKodeLJK
  || '|' || z_cSandiLJK
  || '|' || z_cTahun
  || '|' || z_cBulan
  || '|' || z_cForm
  || '|' || z_nTotalRow
  || '|' || z_nTotalSegmentData
;

raise notice '%', z_cHeader;

z_cErrMsg = public.serene(1, 'Gagal update temp table tmp_TextFile!');
update tmp_TextFile as xa
set
     txt = z_cHeader
    ,rowcount = z_nTotalRow
    ,totalsegment = z_nTotalSegmentData
    ,kodeljk = z_cKodeLJK
where xa.txt = '%HeaderTextFile%'
and xa.rowid = 1
;

----------------------------------------------------------------------------------------------------------
-- Main Process Result --
----------------------------------------------------------------------------------------------------------
z_cErrMsg = public.serene(1, '040');

---- this function only returns temporary table ----

return 0;

----------------------------------------------------------------------------------------------------------
-- Exception --
----------------------------------------------------------------------------------------------------------
EXCEPTION
when OTHERS then
z_cFuncName = COALESCE(z_cFuncName, '[UNSPECIFIED FUNCTION NAME]');
z_cErrMsg   = COALESCE(z_cErrMsg, 'Error#00 - Unspecified Error. Please review the function definition.');
z_cSQLState = SQLSTATE;
z_cSQLMsg   = SQLERRM;
z_cUser     = USER;

perform public.DailyProcessErrorMessageInsert
(
     z_cFuncName -- z_pcFunctionName --
    ,z_cErrMsg -- z_pcErrorMessage --
    ,z_cSQLState -- z_pcSQLErrNo --
    ,z_cSQLMsg -- z_pcSQLErrMessage --
    ,z_cUser -- z_pcUserId --
);

raise EXCEPTION '[ERROR - %]: % | % - %', z_cFuncName, z_cErrMsg, z_cSQLState, z_cSQLMsg;

return 1;

----------------------------------------------------------------------------------------------------------
-- Object Usage List --
----------------------------------------------------------------------------------------------------------
/*
-- Table --
probi.SLIK_ParamReportGroup
probi.SLIK_F_D01
probi.SLIK_F_D02
probi.SLIK_F_F01
probi.SLIK_F_F02
probi.SLIK_F_F03
probi.SLIK_F_F04
probi.SLIK_F_F05
probi.SLIK_F_F06
probi.SLIK_F_A01
probi.SLIK_F_P01
probi.SLIK_F_M01
probi.SLIK_f_K01
probi.SLIK_F_Summary
ads.office_information_v

-- Function --

-- Result --

*/
--========================================================================================================
END;--FUNCTION--
--========================================================================================================
$BODY$
language plpgsql volatile;
please remove this line if you wish to create or replace this function
"