"create or replace function ads.ssrs_slik_ideb_d01
(
     z_pcperiod character varying
    ,z_pcsegment character varying
    ,z_pccif character varying
    ,z_pcpart character varying
    ,z_pcagunanid character varying
    ,z_pcpenjaminid character varying
    ,z_pcpengurusid character varying
)
returns setof record
as
$BODY$
----------------------------------------------------------------------------------------------------------
-- Variable Declaration --
----------------------------------------------------------------------------------------------------------
declare
---- system variable ----
z_cFuncName         character varying;
z_cErrMsg           character varying;
z_cSQLState         character varying;
z_cSQLMsg           character varying;
z_cUser             character varying;
z_cQuery            character varying;
z_cColumnList       character varying;
z_nMaxResult        integer;
z_nCountResult      integer;
z_rResult           record;

---- procedure variable ----
z_dCurrEOD          date;
z_cPeriod           character varying;
z_cSegment          character varying;
z_cCIF              character varying;
z_cPart             character varying;
z_nCountSegment     integer;
z_nCountPart        integer;
z_nRowPerSegment    integer;
z_cAgunanId         character varying;
z_nCountAgunan      integer;
z_cPenjaminId       character varying;
z_nCountPenjamin    integer;
z_dMaxPeriod        date;
z_cPengurusId       character varying;
z_nCountPengurus    integer;
z_dMinPeriod date;
z_dApplyNeoCredit date;

--========================================================================================================
BEGIN--FUNCTION--
--========================================================================================================
----------------------------------------------------------------------------------------------------------
-- Variable Assignment --
----------------------------------------------------------------------------------------------------------
-- set optimizer = true;

z_cFuncName = 'SSRS_SLIK_iDeb_D01';

select
 xa.ops_date
from ads.DOPS_Parameters as xa
into
 z_dCurrEOD
;

select
 xa.MaximumNumberOfRows
from mis.SL_ParamVolumeTable as xa
where xa.VolumeId = 1
into
 z_nMaxResult
;

z_cPeriod = coalesce(trim(z_pcPeriod), '');
z_cSegment = coalesce(trim(z_pcSegment), '');
z_cCIF = coalesce(trim(z_pcCIF), '');
z_cPart = coalesce(trim(z_pcPart), '');
z_cAgunanId = coalesce(trim(z_pcAgunanId), '');
z_cPenjaminId = coalesce(trim(z_pcPenjaminId), '');
z_cPengurusId = coalesce(trim(z_pcPengurusId), '');
z_dApplyNeoCredit = '20240131'::date;
----------------------------------------------------------------------------------------------------------
-- Variable Debug --
----------------------------------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------------
-- Preliminary Validation --
----------------------------------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------------
-- Temporary Procedure Table Declaration --
----------------------------------------------------------------------------------------------------------
z_cErrMsg = public.serene(1, 'A010');

if public.fnCheckTemporaryTableExistence('TMP_Result') = 0
then
    create temporary table TMP_Result
    (
         period                   character varying
        ,flagdetail               character varying
        ,cif                      character varying
        ,jenisidentitas           character varying
        ,nikpassport              character varying
        ,namasesuaiidentitas      character varying
        ,namalengkap              character varying
        ,kodestatusgelardebitur   character varying
        ,jeniskelamin             character varying
        ,tempatlahirktp           character varying
        ,tanggallahir             character varying
        ,npwp                     character varying
        ,alamat                   character varying
        ,kelurahan                character varying
        ,kecamatan                character varying
        ,kodedatiii               character varying
        ,kodepos                  character varying
        ,telepon                  character varying
        ,nomortelepongenggam      character varying
        ,alamatemail              character varying
        ,kodenegara               character varying
        ,kodepekerjaan            character varying
        ,tempatbekerja            character varying
        ,kodebidangusaha          character varying
        ,alamattempatbekerja      character varying
        ,penghasilankotorpertahun character varying
        ,kodesumberpenghasilan    character varying
        ,jumlahtanggungan         character varying
        ,kodehubungandenganljk    character varying
        ,kodegolongandebitur      character varying
        ,statusperkawinandebitur  character varying
        ,nikpassportpasangan      character varying
        ,namapasangan             character varying
        ,tanggallahirpasangan     character varying
        ,perjanjianpisahharta     character varying
        ,melanggarbm              character varying
        ,melampauibm              character varying
        ,namagadisibukandung      character varying
        ,kodekantorcabang         character varying
        ,operationdata            character varying
        ,tahundata                character varying
        ,bulandata                character varying
        ,sandiljk                 character varying
        ,kodejenisljk             character varying
        ,createdate               character varying
        ,rownumber                integer
        ,partnumber               integer
        ,part                     character varying
        ,nikpelaku                character varying
        ,flagdelete               character varying
        ,functionalgroup          character varying
        ,flagsyariah              character varying
    )
    distributed randomly;
else
    truncate table TMP_Result;
end if;

z_cErrMsg = public.serene(1, 'A020');

if public.fnCheckTemporaryTableExistence('TMP_Period') = 0
then
    create temporary table TMP_Period
    (
        period  character varying
    )
    distributed randomly;
else
    truncate table TMP_Period;
end if;

z_cErrMsg = public.serene(1, 'A030');

if public.fnCheckTemporaryTableExistence('TMP_Segment') = 0
then
    create temporary table TMP_Segment
    (
        segment character varying
    )
    distributed randomly;
else
    truncate table TMP_Segment;
end if;

z_cErrMsg = public.serene(1, 'A040');

if public.fnCheckTemporaryTableExistence('TMP_CIF') = 0
then
    create temporary table TMP_CIF
    (
        cif character varying
    )
    distributed randomly;
else
    truncate table TMP_CIF;
end if;

z_cErrMsg = public.serene(1, 'A050');

if public.fnCheckTemporaryTableExistence('TMP_Part') = 0
then
    create temporary table TMP_Part
    (
        part    character varying
    )
    distributed randomly;
else
    truncate table TMP_Part;
end if;

z_cErrMsg = public.serene(1, 'A070');
if public.fnCheckTemporaryTableExistence('tmp_ListAgunanId_15548662') = 0
then
    create temporary table tmp_ListAgunanId_15548662
    (
         agunanid       character varying
    )
    distributed randomly;
else
    truncate table tmp_ListAgunanId_15548662;
end if;

z_cErrMsg = public.serene(1, 'A080');
if public.fnCheckTemporaryTableExistence('tmp_CollateralDetailDistinct_15548662') = 0
then
    create temporary table tmp_CollateralDetailDistinct_15548662
    (
         cif                        character varying
        ,period                     date
    )
    distributed randomly;
else
    truncate table tmp_CollateralDetailDistinct_15548662;
end if;

z_cErrMsg = public.serene(1, 'A090');
if public.fnCheckTemporaryTableExistence('TMP_ResultFinal_15548662') = 0
then
    create temporary table TMP_ResultFinal_15548662
    (
         period                   character varying
        ,flagdetail               character varying
        ,cif                      character varying
        ,jenisidentitas           character varying
        ,nikpassport              character varying
        ,namasesuaiidentitas      character varying
        ,namalengkap              character varying
        ,kodestatusgelardebitur   character varying
        ,jeniskelamin             character varying
        ,tempatlahirktp           character varying
        ,tanggallahir             character varying
        ,npwp                     character varying
        ,alamat                   character varying
        ,kelurahan                character varying
        ,kecamatan                character varying
        ,kodedatiii               character varying
        ,kodepos                  character varying
        ,telepon                  character varying
        ,nomortelepongenggam      character varying
        ,alamatemail              character varying
        ,kodenegara               character varying
        ,kodepekerjaan            character varying
        ,tempatbekerja            character varying
        ,kodebidangusaha          character varying
        ,alamattempatbekerja      character varying
        ,penghasilankotorpertahun character varying
        ,kodesumberpenghasilan    character varying
        ,jumlahtanggungan         character varying
        ,kodehubungandenganljk    character varying
        ,kodegolongandebitur      character varying
        ,statusperkawinandebitur  character varying
        ,nikpassportpasangan      character varying
        ,namapasangan             character varying
        ,tanggallahirpasangan     character varying
        ,perjanjianpisahharta     character varying
        ,melanggarbm              character varying
        ,melampauibm              character varying
        ,namagadisibukandung      character varying
        ,kodekantorcabang         character varying
        ,operationdata            character varying
        ,tahundata                character varying
        ,bulandata                character varying
        ,sandiljk                 character varying
        ,kodejenisljk             character varying
        ,createdate               character varying
        ,rownumber                integer
        ,partnumber               integer
        ,part                     character varying
        ,nikpelaku                character varying
        ,flagdelete               character varying
        ,functionalgroup          character varying
        ,flagsyariah              character varying
    )
    distributed randomly;
else
    truncate table TMP_ResultFinal_15548662;
end if;

z_cErrMsg = public.serene(1, 'A100');

if public.fnCheckTemporaryTableExistence('tmp_ListPenjaminId_15548662') = 0
then
    create temporary table tmp_ListPenjaminId_15548662
    (
         penjaminid       character varying
    )
    distributed randomly;
else
    truncate table tmp_ListPenjaminId_15548662;
end if;

z_cErrMsg = public.serene(1, 'A110');

if public.fnCheckTemporaryTableExistence('tmp_PenjaminDetailDistinct_15548662') = 0
then
    create temporary table tmp_PenjaminDetailDistinct_15548662
    (
         cif                        character varying
        ,period                     date
    )
    distributed randomly;
else
    truncate table tmp_PenjaminDetailDistinct_15548662;
end if;

z_cErrMsg = public.serene(1, 'A120');

if public.fnCheckTemporaryTableExistence('tmp_flagsyariah_15548662') = 0
then
    create temporary table tmp_flagsyariah_15548662
    (
        period                      character varying
        ,cif                        character varying
        ,flagsyariah                character varying
    )
    distributed randomly;
else
    truncate table tmp_flagsyariah_15548662;
end if;

z_cErrMsg = public.serene(1, 'A130');


z_cErrMsg = public.serene(1, 'A140');

if public.fnCheckTemporaryTableExistence('tmp_ListPengurusId_15548662') = 0
then
    create temporary table tmp_ListPengurusId_15548662
    (
         pengurusid       character varying
    )
    distributed randomly;
else
    truncate table tmp_ListPengurusId_15548662;
end if;

z_cErrMsg = public.serene(1, 'A130');
perform public.fnDropTemporaryTable('TMP_Account_15548662');
create temporary table TMP_Account_15548662
(
     accountid      character varying
    ,accountidori   character varying
    ,cifori         character varying
    ,cif            character varying
    ,insertquery    character varying
    ,form           character varying
    ,dtuflag        character varying
    ,accountstatus  character varying
    ,productcode    character varying
    ,source         character varying
    ,statussyariah  character varying
    ,accounttype    character varying
    ,period         date
    ,sourcequery_tmp character varying
) distributed randomly;
----------------------------------------------------------------------------------------------------------
-- Temporary Source Table Declaration --
----------------------------------------------------------------------------------------------------------
z_cErrMsg = public.serene(1, 'B010');

----------------------------------------------------------------------------------------------------------
-- Main Process --
----------------------------------------------------------------------------------------------------------
z_cErrMsg = public.serene(1, 'C010');

insert into TMP_Segment
(
     segment
)
select distinct
 TRIM(result)
from UNNEST(STRING_TO_ARRAY(z_cSegment, '#')) as result
where TRIM(result) <> ''
;

z_cErrMsg = public.serene(1, 'C020');
    z_cErrMsg = public.serene(1, 'C030');

    insert into TMP_Period
    (
         period
    )
    select distinct
     TRIM(result)
    from UNNEST(STRING_TO_ARRAY(z_cPeriod, '#')) as result
    where TRIM(result) <> ''
    ;

    z_cErrMsg = public.serene(1, 'C031');

    select
         max(xa.Period)::date as CountSegment
        ,min(period)::date
    from TMP_Period as xa
    into
         z_dMaxPeriod
        ,z_dMinPeriod
    ;

    z_cErrMsg = public.serene(1, 'C031.3');
    ---- probi.slik_accountdetail ----
    perform public.fnDropTemporaryView('TMPV_slik_accountdetail_15548662');

    z_cColumnList = ''
    || CHR(10) || ' accountid        ,accountidori     ,cifori           ,form'
    || CHR(10) || ',statussyariah    ,keterangan       ,kodejenis        ,insertquery'
    || CHR(10) || ',source           ,productcode      ,kodekantorcabang ,accounttype'
    || CHR(10) || ',cif              ,lastchangeduser'
    ;

    z_cQuery = public.fnGenQuery4RangedPartition('probi', 'slik_accountdetail', z_dMinPeriod, z_dMaxPeriod, NULL, z_cColumnList);
    z_cQuery = ''
    || CHR(10) || 'create or replace temporary view TMPV_slik_accountdetail_15548662 as'
    || CHR(10) || 'select'
    || CHR(10) || '     xa.*'
    || CHR(10) || 'from (' || z_cQuery || ') as xa'
    || CHR(10) || ';'
    ;

    execute z_cQuery;

    z_cErrMsg = public.serene(1, 'C031.4');
    ---- probi.slik_f_d01 ----
    perform public.fnDropTemporaryView('TMPV_slik_f_d01_15548662');

    z_cColumnList = ''
    || CHR(10) || ' flagdetail               ,cif                      ,jenisidentitas'
    || CHR(10) || ',nikpassport              ,namasesuaiidentitas      ,namalengkap'
    || CHR(10) || ',kodestatusgelardebitur   ,jeniskelamin             ,tempatlahirktp'
    || CHR(10) || ',tanggallahir             ,npwp                     ,alamat'
    || CHR(10) || ',kelurahan                ,kecamatan                ,kodedatiii'
    || CHR(10) || ',kodepos                  ,telepon                  ,nomortelepongenggam'
    || CHR(10) || ',alamatemail              ,kodenegara               ,kodepekerjaan'
    || CHR(10) || ',tempatbekerja            ,kodebidangusaha          ,alamattempatbekerja'
    || CHR(10) || ',penghasilankotorpertahun ,kodesumberpenghasilan    ,jumlahtanggungan'
    || CHR(10) || ',kodehubungandenganljk    ,kodegolongandebitur      ,statusperkawinandebitur'
    || CHR(10) || ',nikpassportpasangan      ,namapasangan             ,tanggallahirpasangan'
    || CHR(10) || ',perjanjianpisahharta     ,melanggarbm              ,melampauibm'
    || CHR(10) || ',namagadisibukandung      ,kodekantorcabang         ,operationdata'
    || CHR(10) || ',tahundata                ,bulandata                ,sandiljk'
    || CHR(10) || ',kodejenisljk             ,createdate'
    ;

    z_cQuery = public.fnGenQuery4RangedPartition('probi', 'slik_f_d01', z_dMinPeriod, z_dMaxPeriod, NULL, z_cColumnList);
    z_cQuery = ''
    || CHR(10) || 'create or replace temporary view TMPV_slik_f_d01_15548662 as'
    || CHR(10) || 'select'
    || CHR(10) || '     xa.*'
    || CHR(10) || 'from (' || z_cQuery || ') as xa'
    || CHR(10) || ';'
    ;

    execute z_cQuery;


    z_cErrMsg = public.serene(1, 'C031.5');
    ---- dmt.datamart_lv2b_accountcredit ----
    perform public.fnDropTemporaryView('TMPV_datamart_lv2b_accountcredit_15548662');

    z_cColumnList = ''
    || CHR(10) || ' accountid           ,accountid_reg       ,customerid          ,customerid_reg'
    || CHR(10) || ',productcode         ,accountstatus       ,source              ,bibankid       ,accounttype'
    ;

    z_cQuery = public.fnGenQuery4RangedPartition('dmt', 'datamart_lv2b_accountcredit', z_dMinPeriod, z_dMaxPeriod, 'where deletequery_slk is null', z_cColumnList);
    z_cQuery = ''
    || CHR(10) || 'create or replace temporary view TMPV_datamart_lv2b_accountcredit_15548662 as'
    || CHR(10) || 'select'
    || CHR(10) || '     xa.*'
    || CHR(10) || 'from (' || z_cQuery || ') as xa'
    || CHR(10) || ';'
    ;

    execute z_cQuery;

    z_cErrMsg = public.serene(1, 'C031.6');
---- mis.accountmapping ----
    perform public.fnDropTemporaryView('TMP_accountmapping_15548662');

    z_cColumnList = ''
    || CHR(10) || ' accountid       ,accounttype     ,customerid      ,functionalgroup ,lp'
    || CHR(10) || ',name            ,productcode'
    ;

    z_cQuery = public.fnGenQuery4Partition('mis', 'accountmapping', z_dMaxPeriod, z_dCurrEOD, NULL, z_cColumnList);
    z_cQuery = ''
    || CHR(10) || 'create or replace temporary view TMP_accountmapping_15548662 as'
    || CHR(10) || 'select'
    || CHR(10) || '     xa.*'
    || CHR(10) || 'from (' || z_cQuery || ') as xa'
    || CHR(10) || ';'
    ;

    execute z_cQuery;

    z_cErrMsg = public.serene(1, 'C031.7');
if exists
(
    select 1
    from TMP_Segment as xa
    where xa.segment = 'D01'
    limit 1
)
then
    z_cErrMsg = public.serene(1, 'C040');

    insert into TMP_CIF
    (
         cif
    )
    select distinct
     TRIM(result)
    from UNNEST(STRING_TO_ARRAY(z_cCIF, '#')) as result
    where TRIM(result) <> ''
    ;

    z_cErrMsg = public.serene(1, 'C050');

    insert into TMP_Part
    (
         part
    )
    select distinct
     TRIM(result)
    from UNNEST(STRING_TO_ARRAY(z_cPart, '#')) as result
    where TRIM(result) <> ''
    ;

    z_cErrMsg = public.serene(1, 'C060');

    select
     count(1) as CountSegment
    from TMP_Segment as xa
    into
     z_nCountSegment
    ;

    z_cErrMsg = public.serene(1, 'C061');

    insert into tmp_ListAgunanId_15548662
    (
         agunanid
    )
    select distinct
     TRIM(xa.result) as agunanid
    from UNNEST(STRING_TO_ARRAY(z_cAgunanId, '#')) as xa(result)
    where TRIM(xa.result) <> ''
    ;

    select
         count(1) as CountAgunan
    from tmp_ListAgunanId_15548662 as xa
    into
         z_nCountAgunan
    ;

    z_cErrMsg = public.serene(1, 'C062');

    if coalesce(z_nCountAgunan,0) = 0
    then
        z_cErrMsg = public.serene(1, 'C063');

        insert into tmp_ListAgunanId_15548662
        (
             agunanid
        )
        select
             'all' as agunanid
        ;
    end if;

    z_cErrMsg = public.serene(1, 'C063');

    insert into tmp_ListPenjaminId_15548662
    (
         penjaminid
    )
    select distinct
         TRIM(xa.result) as penjaminid
    from UNNEST(STRING_TO_ARRAY(z_cPenjaminId, '#')) as xa(result)
    where TRIM(xa.result) <> ''
    ;

    select
         count(1) as CountPenjamin
    from tmp_ListPenjaminId_15548662 as xa
    into
         z_nCountPenjamin
    ;

    z_cErrMsg = public.serene(1, 'C062');

    if coalesce(z_nCountPenjamin, 0) = 0
    then
        z_cErrMsg = public.serene(1, 'C063');

        insert into tmp_ListPenjaminId_15548662
        (
             penjaminid
        )
        select
             'all' as penjaminid
        ;
    end if;

    z_cErrMsg = public.serene(1, 'C065');

    insert into tmp_ListPengurusId_15548662
    (
         Pengurusid
    )
    select distinct
         TRIM(xa.result) as Pengurusid
    from UNNEST(STRING_TO_ARRAY(z_cPengurusId, '#')) as xa(result)
    where TRIM(xa.result) <> ''
    ;

    select
         count(1) as CountPengurus
    from tmp_ListPengurusId_15548662 as xa
    into
         z_nCountPengurus
    ;

    if coalesce(z_nCountPengurus, 0) <> 0
    then
        insert into TMP_CIF
        (
             CIF
        )
        select distinct
            xa.cif
        from probi.slik_f_m01 as xa
        inner join TMP_Period as xb
            on  xb.period::date = xa.period::date
        inner join tmp_ListPengurusId_15548662 as xc
            on  xc.Pengurusid = xa.nomoridentitas
        ;

        delete from TMP_CIF as xz
        where xz.cif = 'ALL' -- karena di ssrs_slik_param_cif di hardcode
        ;
    end if;


    z_cErrMsg = public.serene(1, 'C063');




    select
     count(1) as CountPart
    from TMP_Part as xa
    into
     z_nCountPart
    ;

    z_nRowPerSegment = (ceiling(z_nMaxResult / (z_nCountSegment * 1000)) * 1000)::integer;

    if (z_nCountPart * z_nRowPerSegment) > z_nMaxResult
    then
        z_cErrMsg = 'Error#01 - Report produces ' || ((z_nCountPart * z_nRowPerSegment)::integer)::character varying || ' rows, which exceeds the maximum ' || z_nMaxResult::character varying || ' rows allowed. Please reconsider your choice of parameters.';
        raise EXCEPTION 'Exception Raised';
    end if;

    z_cErrMsg = public.serene(1, 'C070');

    if exists
    (
        select 1
        from TMP_CIF as xa
        where xa.CIF = 'ALL'
        limit 1
    )
    then
        z_cErrMsg = public.serene(1, 'C080');

        insert into TMP_Result
        (
             period
            ,flagdetail
            ,cif
            ,jenisidentitas
            ,nikpassport
            ,namasesuaiidentitas
            ,namalengkap
            ,kodestatusgelardebitur
            ,jeniskelamin
            ,tempatlahirktp
            ,tanggallahir
            ,npwp
            ,alamat
            ,kelurahan
            ,kecamatan
            ,kodedatiii
            ,kodepos
            ,telepon
            ,nomortelepongenggam
            ,alamatemail
            ,kodenegara
            ,kodepekerjaan
            ,tempatbekerja
            ,kodebidangusaha
            ,alamattempatbekerja
            ,penghasilankotorpertahun
            ,kodesumberpenghasilan
            ,jumlahtanggungan
            ,kodehubungandenganljk
            ,kodegolongandebitur
            ,statusperkawinandebitur
            ,nikpassportpasangan
            ,namapasangan
            ,tanggallahirpasangan
            ,perjanjianpisahharta
            ,melanggarbm
            ,melampauibm
            ,namagadisibukandung
            ,kodekantorcabang
            ,operationdata
            ,tahundata
            ,bulandata
            ,sandiljk
            ,kodejenisljk
            ,createdate
            ,rownumber
        )
        select
             xb.period -- period
            ,xa.flagdetail -- flagdetail
            ,xa.cif -- cif
            ,xa.jenisidentitas -- jenisidentitas
            ,xa.nikpassport -- nikpassport
            ,xa.namasesuaiidentitas -- namasesuaiidentitas
            ,xa.namalengkap -- namalengkap
            ,xa.kodestatusgelardebitur -- kodestatusgelardebitur
            ,xa.jeniskelamin -- jeniskelamin
            ,xa.tempatlahirktp -- tempatlahirktp
            ,xa.tanggallahir -- tanggallahir
            ,xa.npwp -- npwp
            ,xa.alamat -- alamat
            ,xa.kelurahan -- kelurahan
            ,xa.kecamatan -- kecamatan
            ,xa.kodedatiii -- kodedatiii
            ,xa.kodepos -- kodepos
            ,xa.telepon -- telepon
            ,xa.nomortelepongenggam -- nomortelepongenggam
            ,xa.alamatemail -- alamatemail
            ,xa.kodenegara -- kodenegara
            ,xa.kodepekerjaan -- kodepekerjaan
            ,xa.tempatbekerja -- tempatbekerja
            ,xa.kodebidangusaha -- kodebidangusaha
            ,xa.alamattempatbekerja -- alamattempatbekerja
            ,xa.penghasilankotorpertahun -- penghasilankotorpertahun
            ,xa.kodesumberpenghasilan -- kodesumberpenghasilan
            ,xa.jumlahtanggungan -- jumlahtanggungan
            ,xa.kodehubungandenganljk -- kodehubungandenganljk
            ,xa.kodegolongandebitur -- kodegolongandebitur
            ,xa.statusperkawinandebitur -- statusperkawinandebitur
            ,xa.nikpassportpasangan -- nikpassportpasangan
            ,xa.namapasangan -- namapasangan
            ,xa.tanggallahirpasangan -- tanggallahirpasangan
            ,xa.perjanjianpisahharta -- perjanjianpisahharta
            ,xa.melanggarbm -- melanggarbm
            ,xa.melampauibm -- melampauibm
            ,xa.namagadisibukandung -- namagadisibukandung
            ,xa.kodekantorcabang -- kodekantorcabang
            ,xa.operationdata -- operationdata
            ,xa.tahundata -- tahundata
            ,xa.bulandata -- bulandata
            ,xa.sandiljk -- sandiljk
            ,xa.kodejenisljk -- kodejenisljk
            ,xa.createdate -- createdate
            ,ROW_NUMBER() over(order by xa.period desc, xa.cif asc) -- rownumber
--         from probi.slik_f_D01 as xa
        from tmpv_slik_f_D01_15548662 as xa
        inner join TMP_Period as xb
            on xb.period::date = xa.period
        ;
    else
        z_cErrMsg = public.serene(1, 'C090');

        insert into TMP_Result
        (
             period
            ,flagdetail
            ,cif
            ,jenisidentitas
            ,nikpassport
            ,namasesuaiidentitas
            ,namalengkap
            ,kodestatusgelardebitur
            ,jeniskelamin
            ,tempatlahirktp
            ,tanggallahir
            ,npwp
            ,alamat
            ,kelurahan
            ,kecamatan
            ,kodedatiii
            ,kodepos
            ,telepon
            ,nomortelepongenggam
            ,alamatemail
            ,kodenegara
            ,kodepekerjaan
            ,tempatbekerja
            ,kodebidangusaha
            ,alamattempatbekerja
            ,penghasilankotorpertahun
            ,kodesumberpenghasilan
            ,jumlahtanggungan
            ,kodehubungandenganljk
            ,kodegolongandebitur
            ,statusperkawinandebitur
            ,nikpassportpasangan
            ,namapasangan
            ,tanggallahirpasangan
            ,perjanjianpisahharta
            ,melanggarbm
            ,melampauibm
            ,namagadisibukandung
            ,kodekantorcabang
            ,operationdata
            ,tahundata
            ,bulandata
            ,sandiljk
            ,kodejenisljk
            ,createdate
            ,rownumber
        )
        select
             xb.period -- period
            ,xa.flagdetail -- flagdetail
            ,xa.cif -- cif
            ,xa.jenisidentitas -- jenisidentitas
            ,xa.nikpassport -- nikpassport
            ,xa.namasesuaiidentitas -- namasesuaiidentitas
            ,xa.namalengkap -- namalengkap
            ,xa.kodestatusgelardebitur -- kodestatusgelardebitur
            ,xa.jeniskelamin -- jeniskelamin
            ,xa.tempatlahirktp -- tempatlahirktp
            ,xa.tanggallahir -- tanggallahir
            ,xa.npwp -- npwp
            ,xa.alamat -- alamat
            ,xa.kelurahan -- kelurahan
            ,xa.kecamatan -- kecamatan
            ,xa.kodedatiii -- kodedatiii
            ,xa.kodepos -- kodepos
            ,xa.telepon -- telepon
            ,xa.nomortelepongenggam -- nomortelepongenggam
            ,xa.alamatemail -- alamatemail
            ,xa.kodenegara -- kodenegara
            ,xa.kodepekerjaan -- kodepekerjaan
            ,xa.tempatbekerja -- tempatbekerja
            ,xa.kodebidangusaha -- kodebidangusaha
            ,xa.alamattempatbekerja -- alamattempatbekerja
            ,xa.penghasilankotorpertahun -- penghasilankotorpertahun
            ,xa.kodesumberpenghasilan -- kodesumberpenghasilan
            ,xa.jumlahtanggungan -- jumlahtanggungan
            ,xa.kodehubungandenganljk -- kodehubungandenganljk
            ,xa.kodegolongandebitur -- kodegolongandebitur
            ,xa.statusperkawinandebitur -- statusperkawinandebitur
            ,xa.nikpassportpasangan -- nikpassportpasangan
            ,xa.namapasangan -- namapasangan
            ,xa.tanggallahirpasangan -- tanggallahirpasangan
            ,xa.perjanjianpisahharta -- perjanjianpisahharta
            ,xa.melanggarbm -- melanggarbm
            ,xa.melampauibm -- melampauibm
            ,xa.namagadisibukandung -- namagadisibukandung
            ,xa.kodekantorcabang -- kodekantorcabang
            ,xa.operationdata -- operationdata
            ,xa.tahundata -- tahundata
            ,xa.bulandata -- bulandata
            ,xa.sandiljk -- sandiljk
            ,xa.kodejenisljk -- kodejenisljk
            ,xa.createdate -- createdate
            ,ROW_NUMBER() over(order by xa.period desc, xa.cif asc) -- rownumber
--         from probi.slik_f_D01 as xa
        from tmpv_slik_f_d01_15548662 as xa
        inner join TMP_Period as xb
            on xb.period::date = xa.period
        inner join TMP_CIF as xc
            on xc.cif = xa.cif
        ;
    end if;

    z_cErrMsg = public.serene(1, 'C100');

    update TMP_Result as xz
    set
         partnumber = ceiling(xz.rownumber::numeric / z_nRowPerSegment)
    ;

    z_cErrMsg = public.serene(1, 'C110');

    update TMP_Result as xz
    set
         part = 'D01 Part ' || lpad(xz.partnumber, 3, '0')
    ;
end if;

z_cErrMsg = public.serene(1, 'C111');

insert into tmp_CollateralDetailDistinct_15548662
(
     cif
    ,period
)
select distinct
     xa.cif
    ,xa.period
from probi.slik_f_a01 as xa
inner join TMP_Period as xb
    on  xb.period::date = xa.period::date
inner join tmp_ListAgunanId_15548662 as xc
    on  xc.agunanid = xa.koderegistrasiagunan
;

z_cErrMsg = public.serene(1, 'C112');

insert into tmp_PenjaminDetailDistinct_15548662
(
     cif
    ,period
)
select distinct
     xa.cif
    ,xa.period
from probi.slik_f_P01 as xa
inner join TMP_Period as xb
    on  xb.period::date = xa.period::date
inner join tmp_ListPenjaminId_15548662 as xc
    on  xc.penjaminid = xa.noidentitaspenjamin
;

z_cErrMsg = public.serene(1, 'C165');

if exists
(
    select 1
    from tmp_ListAgunanId_15548662 as xa
    where lower(xa.agunanid) <> 'all'
    limit 1
)
then
    z_cErrMsg = public.serene(1, 'C170');

    if exists
    (
        select 1
        from tmp_ListPenjaminId_15548662 as xa
        where lower(xa.penjaminid) <> 'all'
        limit 1
    )
    then
        z_cErrMsg = public.serene(1, 'C171');

        update TMP_Result as xz
        set
             flagdelete = 'N'
        from tmp_CollateralDetailDistinct_15548662 as xa
        inner join tmp_PenjaminDetailDistinct_15548662 as xb
            on xb.cif = xa.cif
            and xb.period = xa.period
        where xz.cif = xa.cif
        and xz.period::date = xa.period::date
        ;
    else
        z_cErrMsg = public.serene(1, 'C172');

        update TMP_Result as xz
        set
             flagdelete = 'N'
        from tmp_CollateralDetailDistinct_15548662 as xa
        where xz.cif = xa.cif
        and xz.period::date = xa.period::date
        ;
    end if;
else
    z_cErrMsg = public.serene(1, 'C173');

    if exists
    (
        select 1
        from tmp_ListPenjaminId_15548662 as xa
        where lower(xa.penjaminid) <> 'all'
        limit 1
    )
    then
        z_cErrMsg = public.serene(1, 'C174');

        update TMP_Result as xz
        set
             flagdelete = 'N'
        from tmp_PenjaminDetailDistinct_15548662 as xa
        where xz.cif = xa.cif
        and xz.period::date = xa.period::date
        ;
    else
        z_cErrMsg = public.serene(1, 'C175');

        update TMP_Result as xz
        set
             flagdelete = 'N'
        ;
    end if;
end if;

z_cErrMsg = public.serene(1, 'C172');

delete from TMP_Result as xa
where coalesce(xa.flagdelete, '') <> 'N'
;

z_cErrMsg = public.serene(1, 'C175');

update TMP_Result as xz
set
     nikpelaku = coalesce(xa.lastchangeduser,'')
from probi.SLIK_customerdetail as xa
where xz.period::date = xa.period
and xz.cif = xa.cif
;

z_cErrMsg = public.serene(1, 'C180');

update TMP_Result as xz
set
     nikpelaku = coalesce(xz.nikpelaku,'') || ' ' || xa.employeename
from mis.employeepeoplesoft as xa
where xa.scd_end = z_dCurrEOD
and xz.nikpelaku = xa.employeeid
;

z_cErrMsg = public.serene(1, 'C181');

-- update functional group
update TMP_Result as xz
set
     functionalgroup = xa.functionalgroup
from TMP_accountmapping_15548662 as xa
inner join probi.slik_customermaster xb
    on  xb.periodpelaporan = xa.scd_end
    and xb.cifori = xa.customerid
where xa.accounttype = 'C'
and xz.cif = xb.cif
;

    z_cErrMsg = public.serene(1, 'C151');
    insert into tmp_account_15548662
    (
         accountid
        ,accountidori
        ,cifori
        ,cif
        ,insertquery
        ,form
        ,productcode
        ,source
        ,period
        ,sourcequery_tmp
        ,statussyariah
    )
    select
         xa.accountid as accountid
        ,xa.accountidori as accountidori
        ,xa.cifori as cifori
        ,xa.cif as cif
        ,xa.insertquery as insertquery
        ,xa.form as form
        ,xa.productcode as productcode
        ,xa.source as source
        ,xa.period as period
        ,'slik old' as sourcequery_tmp
        ,xa.statussyariah as statussyariah
    from tmpv_slik_accountdetail_15548662 as xa
    ;

    z_cErrMsg = public.serene(1, 'C151.1');
    -- hapus yang slik f01 yang datanya diatas data setelah apply neo, karena akan diinsert dibawah
    delete 
    from tmp_account_15548662  as xa
    where xa.sourcequery_tmp = 'slik old'
    and lower(xa.form) = 'f01'
    and xa.period >= z_dApplyNeoCredit
    ;

    z_cErrMsg = public.serene(1, 'C152');
    insert into tmp_account_15548662
    (
         accountid
        ,accountidori
        ,cifori
        ,cif
        ,form
        ,accountstatus
        ,productcode
        ,source
        ,period
        ,sourcequery_tmp
        ,statussyariah
    )
    select
         xa.accountid_reg as accountid
        ,xa.accountid as accountidori
        ,xa.customerid as cifori
        ,xa.customerid_reg as cif
        ,'F01' as form
        ,xa.accountstatus as accountstatus
        ,xa.productcode as productcode
        ,xa.source
        ,xa.hkeep_dt as period
        ,'neo credit' as sourcequery_tmp
        ,case
            when xa.bibankid >= 28900 then 'Y'
            else null
         end as statussyariah
    from tmpv_datamart_lv2b_accountcredit_15548662 as xa
    ;

    z_cErrMsg = public.serene(1, 'C152.1');
    -- hapus yang period nya sebelum apply neo
    delete 
    from tmp_account_15548662  as xa
    where xa.sourcequery_tmp = 'neo credit'
    and lower(xa.form) = 'f01'
    and xa.period < z_dApplyNeoCredit
    ;

z_cErrMsg = public.serene(1, 'C183');

insert into tmp_flagsyariah_15548662
(
     period
    ,cif
    ,flagsyariah
)
select distinct
     xa.period
    ,xa.cif
    ,case
         when coalesce(xb.statussyariah, '') = 'Y' then 'Y'
         else 'T'
     end as flagsyariah
from TMP_Result as xa
-- inner join probi.slik_accountdetail as xb
inner join tmp_account_15548662 as xb
    on  xb.CIF = xa.CIF
    and xb.period::date = xa.period::date
;

z_cErrMsg = public.serene(1, 'C184');

-- update flag syariah
update TMP_Result as xz
set
     flagsyariah = xa.flagsyariah
from tmp_flagsyariah_15548662 xa
where xz.cif = xa.cif
and xz.period = xa.period
;

z_cErrMsg = public.serene(1, 'C190');

insert into TMP_ResultFinal_15548662
(
     period                   ,flagdetail               ,cif
    ,jenisidentitas           ,nikpassport              ,namasesuaiidentitas
    ,namalengkap              ,kodestatusgelardebitur   ,jeniskelamin
    ,tempatlahirktp           ,tanggallahir             ,npwp
    ,alamat                   ,kelurahan                ,kecamatan
    ,kodedatiii               ,kodepos                  ,telepon
    ,nomortelepongenggam      ,alamatemail              ,kodenegara
    ,kodepekerjaan            ,tempatbekerja            ,kodebidangusaha
    ,alamattempatbekerja      ,penghasilankotorpertahun ,kodesumberpenghasilan
    ,jumlahtanggungan         ,kodehubungandenganljk    ,kodegolongandebitur
    ,statusperkawinandebitur  ,nikpassportpasangan      ,namapasangan
    ,tanggallahirpasangan     ,perjanjianpisahharta     ,melanggarbm
    ,melampauibm              ,namagadisibukandung      ,kodekantorcabang
    ,operationdata            ,tahundata                ,bulandata
    ,sandiljk                 ,kodejenisljk             ,createdate
    ,rownumber                ,partnumber               ,part
    ,nikpelaku                ,flagdelete
    ,functionalgroup          ,flagsyariah
)
select
     xa.period as period
    ,xa.flagdetail as flagdetail
    ,xa.cif as cif
    ,xa.jenisidentitas as jenisidentitas
    ,xa.nikpassport as nikpassport
    ,xa.namasesuaiidentitas as namasesuaiidentitas
    ,xa.namalengkap as namalengkap
    ,xa.kodestatusgelardebitur as kodestatusgelardebitur
    ,xa.jeniskelamin as jeniskelamin
    ,xa.tempatlahirktp as tempatlahirktp
    ,xa.tanggallahir as tanggallahir
    ,xa.npwp as npwp
    ,xa.alamat as alamat
    ,xa.kelurahan as kelurahan
    ,xa.kecamatan as kecamatan
    ,xa.kodedatiii as kodedatiii
    ,xa.kodepos as kodepos
    ,xa.telepon as telepon
    ,xa.nomortelepongenggam as nomortelepongenggam
    ,xa.alamatemail as alamatemail
    ,xa.kodenegara as kodenegara
    ,xa.kodepekerjaan as kodepekerjaan
    ,xa.tempatbekerja as tempatbekerja
    ,xa.kodebidangusaha as kodebidangusaha
    ,xa.alamattempatbekerja as alamattempatbekerja
    ,xa.penghasilankotorpertahun as penghasilankotorpertahun
    ,xa.kodesumberpenghasilan as kodesumberpenghasilan
    ,xa.jumlahtanggungan as jumlahtanggungan
    ,xa.kodehubungandenganljk as kodehubungandenganljk
    ,xa.kodegolongandebitur as kodegolongandebitur
    ,xa.statusperkawinandebitur as statusperkawinandebitur
    ,xa.nikpassportpasangan as nikpassportpasangan
    ,xa.namapasangan as namapasangan
    ,xa.tanggallahirpasangan as tanggallahirpasangan
    ,xa.perjanjianpisahharta as perjanjianpisahharta
    ,xa.melanggarbm as melanggarbm
    ,xa.melampauibm as melampauibm
    ,xa.namagadisibukandung as namagadisibukandung
    ,xa.kodekantorcabang as kodekantorcabang
    ,xa.operationdata as operationdata
    ,xa.tahundata as tahundata
    ,xa.bulandata as bulandata
    ,xa.sandiljk as sandiljk
    ,xa.kodejenisljk as kodejenisljk
    ,xa.createdate as createdate
    ,ROW_NUMBER() over(order by xa.period desc, xa.cif asc) as rownumber
    ,xa.partnumber as partnumber
    ,xa.part as part
    ,xa.nikpelaku as nikpelaku
    ,xa.flagdelete as flagdelete
    ,xa.functionalgroup as functionalgroup
    ,xa.flagsyariah as flagsyariah
from tmp_result as xa
;

z_cErrMsg = public.serene(1, 'C200');

update TMP_ResultFinal_15548662 as xz
set
     partnumber = ceiling(xz.rownumber::numeric / z_nRowPerSegment)
;

z_cErrMsg = public.serene(1, 'C210');

update TMP_ResultFinal_15548662 as xz
set
     part = 'D01 Part ' || lpad(xz.partnumber, 3, '0')
;

----------------------------------------------------------------------------------------------------------
-- Main Process Result --
----------------------------------------------------------------------------------------------------------
z_cErrMsg = public.serene(1, 'D010');

for z_rResult in
    select
         xa.period
        ,xa.flagdetail
        ,xa.cif
        ,xa.jenisidentitas
        ,xa.nikpassport
        ,xa.namasesuaiidentitas
        ,xa.namalengkap
        ,xa.kodestatusgelardebitur
        ,xa.jeniskelamin
        ,xa.tempatlahirktp
        ,xa.tanggallahir
        ,xa.npwp
        ,xa.alamat
        ,xa.kelurahan
        ,xa.kecamatan
        ,xa.kodedatiii
        ,xa.kodepos
        ,xa.telepon
        ,xa.nomortelepongenggam
        ,xa.alamatemail
        ,xa.kodenegara
        ,xa.kodepekerjaan
        ,xa.tempatbekerja
        ,xa.kodebidangusaha
        ,xa.alamattempatbekerja
        ,xa.penghasilankotorpertahun
        ,xa.kodesumberpenghasilan
        ,xa.jumlahtanggungan
        ,xa.kodehubungandenganljk
        ,xa.kodegolongandebitur
        ,xa.statusperkawinandebitur
        ,xa.nikpassportpasangan
        ,xa.namapasangan
        ,xa.tanggallahirpasangan
        ,xa.perjanjianpisahharta
        ,xa.melanggarbm
        ,xa.melampauibm
        ,xa.namagadisibukandung
        ,xa.kodekantorcabang
        ,xa.operationdata
        ,xa.tahundata
        ,xa.bulandata
        ,xa.sandiljk
        ,xa.kodejenisljk
        ,xa.createdate
    -- from TMP_Result as xa
        ,xa.nikpelaku
        ,xa.functionalgroup
        ,xa.flagsyariah
    from TMP_ResultFinal_15548662 as xa
    inner join TMP_Part as xb
        on xb.part = xa.part
    order by
         xa.rownumber asc
        ,xa.part asc
loop
    return next z_rResult;
end loop;

z_cErrMsg = public.serene(1, 'D020');

return;

----------------------------------------------------------------------------------------------------------
-- Exception --
----------------------------------------------------------------------------------------------------------
EXCEPTION
when OTHERS then
z_cFuncName = COALESCE(z_cFuncName, '[UNSPECIFIED FUNCTION NAME]');
z_cErrMsg   = COALESCE(z_cErrMsg, 'Error#00 - Unspecified Error. Please review the function definition.');
z_cSQLState = SQLSTATE;
z_cSQLMsg   = SQLERRM;
z_cUser     = USER;

raise EXCEPTION '[ERROR - %]: % | % - %', z_cFuncName, z_cErrMsg, z_cSQLState, z_cSQLMsg;

return;

----------------------------------------------------------------------------------------------------------
-- Object Usage List --
----------------------------------------------------------------------------------------------------------
/*
-- Table --

-- Function --

*/

--========================================================================================================
END;--FUNCTION--
--========================================================================================================
$BODY$
language plpgsql volatile;
please remove this line if you wish to create or replace this function
"