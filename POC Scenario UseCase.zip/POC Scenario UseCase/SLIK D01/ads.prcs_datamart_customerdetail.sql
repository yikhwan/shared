create or replace function ads.prcs_datamart_customerdetail
(
     z_pdperiod date
)
returns integer
as
$BODY$
----------------------------------------------------------------------------------------------------------
-- Variable Declaration --
----------------------------------------------------------------------------------------------------------
declare
---- system variable ----
z_cFuncName   character varying;
z_cErrMsg     character varying;
z_cSQLState   character varying;
z_cSQLMsg     character varying;
z_cUser       character varying;
z_cQuery      character varying;
z_cColumnList character varying;

---- procedure variable ----
z_dCurrEOD       date;
z_dPeriod        date;
z_cHKeepYN       character varying;
z_dCurrEOM       date;
z_dPeriodHC      date;
z_cIdOperasional character varying;
Z_cResult        character varying;

--========================================================================================================
BEGIN--FUNCTION--
--========================================================================================================
----------------------------------------------------------------------------------------------------------
-- Variable Assignment --
----------------------------------------------------------------------------------------------------------
set optimizer = true;

z_cFuncName = 'prcs_datamart_customerdetail';

select
 xa.ops_date
from ads.DOPS_Parameters as xa
into
 z_dCurrEOD
;

z_dCurrEOM = DATE_TRUNC('MONTH', z_dCurrEOD + '0 MONTH'::interval) - '1 DAY'::interval;

z_dPeriod = COALESCE(z_pdPeriod, z_dCurrEOD);
z_cIdOperasional  = '1'; -- 1 = baru, 2 = update , 3 = hapus

if DATE_PART('DAY', z_dPeriod + '1 DAY'::interval) = 1 -- end of month date --
then
    z_dPeriodHC = z_dPeriod;
    z_cHKeepYN = 'N'; -- N = will not be deleted --
else
    z_dPeriodHC = DATE_TRUNC('MONTH', z_dPeriod + '0 MONTH'::interval) - '1 DAY'::interval;
    z_cHKeepYN = 'Y'; -- Y = will be deleted --
end if;

----------------------------------------------------------------------------------------------------------
-- Variable Debug --
----------------------------------------------------------------------------------------------------------
raise notice 'z_dPeriod : %', z_dPeriod;

----------------------------------------------------------------------------------------------------------
-- Preliminary Validation --
----------------------------------------------------------------------------------------------------------
if z_dPeriod > z_dCurrEOD
then
    raise notice 'Error#01 - Cannot accept period greater than %.', TO_CHAR(z_dCurrEOD, 'DD FMMonth YYYY');
    return 1;
end if;

if z_dPeriod < DATE_TRUNC('MONTH', z_dCurrEOD + '-13 MONTH'::interval)
then
    raise notice 'Error#02 - Cannot accept period older than %.', TO_CHAR(DATE_TRUNC('MONTH', z_dCurrEOD + '-13 MONTH'::interval), 'DD FMMonth YYYY');
    return 1;
end if;

if date_part('day', current_date) = 2
and not exists
(
    select 1
    from ads.ps_n_debtur_org_slik_vw as xa
    where xa.load_dt = z_dPeriodHC
    limit 1
)
then
    raise notice 'Error#03 - Tidak ada data di ads. ps_n_debtur_org_slik_vw periode %', TO_CHAR(z_dPeriodHC, 'DD FMMonth YYYY');
    return 1;
end if;

----------------------------------------------------------------------------------------------------------
-- Temporary Procedure Table Declaration --
----------------------------------------------------------------------------------------------------------
z_cErrMsg = public.serene(1, 'A010');

perform public.fnDropTemporaryTable('tmp_datamart_customerdetail');
create temporary table tmp_datamart_customerdetail
(
     hkeep_dt                               date
    ,customerid_ori                         character varying
    ,customerid_konven                      character varying
    ,customerid_syariah                     character varying
    ,customertype                           character varying
    ,officecustomer                         character varying
    ,officecustomer_ori                     character varying
    ,customername                           character varying
    ,namalengkap                            character varying
    ,telepon                                character varying
    ,nomortelepongenggam                    character varying
    ,alamatemail                            character varying
    ,alamat                                 character varying
    ,kelurahan                              character varying
    ,kecamatan                              character varying
    ,kodedatiii                             character varying
    ,kodepos                                character varying
    ,kodenegara                             character varying
    ,kodepekerjaan                          character varying
    ,melanggarbm                            character varying
    ,melampauibm                            character varying
    ,kodebidangusaha                        character varying
    ,idnumber                               character varying
    ,idtype                                 character varying
    ,flagwniwna                             character varying
    ,kewarganegaraan                        character varying
    ,kodestatusgelardebitur                 character varying
    ,jeniskelamin                           character varying
    ,tempatlahirktp                         character varying
    ,tanggallahir                           date
    ,npwp                                   character varying
    ,tempatbekerja                          character varying
    ,alamattempatbekerja                    character varying
    ,penghasilankotorpertahun               numeric
    ,kodesumberpenghasilan                  character varying
    ,kodehubungandenganljk                  character varying
    ,kodegolongandebitur                    character varying
    ,statusperkawinandebitur                character varying
    ,namagadisibukandung                    character varying
    ,kodejenisbadanusaha                    character varying
    ,gopublic                               character varying
    ,idgroupdebitur                         numeric(10,0)
    ,NamaGroupDebitur                       character varying
    ,NoAktePendirian                        character varying
    ,NoAktePerubahanTerakhir                character varying
    ,source                                 character varying
    ,lastchangeduser                        character varying
    ,PeringkatDebitur                       character varying
    ,LembagaPemeringkat                     character varying
    ,TanggalPemeringkatan                   date
    ,idoperasional                          character varying
    ,idpihaklawan                           character varying
    ,bibankid                               integer
    ,bibankid_syariah                       integer
    ,kodekantorcabang                       character varying
    ,insertquery                            character varying
    ,updatequery                            character varying default ''
    ,deletequery                            character varying
    ,alamat_code                            character varying
    ,nikpassportpasangan                    character varying
    ,namapasangan                           character varying
    ,tanggallahirpasangan                   date
    ,perjanjianpisahharta                   character varying
    ,jumlahtanggungan                       integer
    ,tanggalaktependirian                   date
    ,tanggalakteperubahanterakhir           date
    ,riskprofile_status                     character varying
    ,riskprofile_totalpoint                 integer
    ,datapekerjaan_cfoccd                   character varying
    ,datapekerjaan_cfejcd                   character varying
    ,hrparam_cfjobc                         character varying
    ,hrparam_cfjobdep                       character varying
    ,hrparam_cfjobsts                       character varying
    ,hrparam_cfjobcsts                      character varying
    ,hrcmaintenance_cfstsh                  character varying
    ,hrcmaintenance_cfjobsts                character varying
    ,hrcmaintenance_cfind7                  timestamp without time zone
    ,risk_rating                            character varying
    ,resiko_nasabah                         character varying
    ,penghasilankotorpertahun_ori_cfzemp    numeric
    ,currencycode_cfzemp                    character varying
    ,kodejenisbadanusaha_desc               character varying
    ,CustomerName_ORI                       character varying
    ,NamaGadisIbuKandung_ORI                character varying
)
distributed randomly;

z_cErrMsg = public.serene(1, 'A020');

perform public.fnDropTemporaryTable('tmp_cif_data');
create temporary table tmp_cif_data
(
     cif            character varying
    ,cifori         character varying
    ,asset          numeric(30,4)
    ,omset          numeric(30,4)
    ,gaji           numeric(30,4)
    ,gajipasangan   numeric(30,4)
    ,lainnya        numeric(30,4)
    ,individualbit  integer default 0
)
distributed randomly;

z_cErrMsg = public.serene(1, 'A030');

perform public.fnDropTemporaryTable('tmp_cif_assetdata');
create temporary table tmp_cif_assetdata
(
     cif    character varying
    ,cifori character varying
    ,asset  numeric(30,4)
)
distributed randomly;

z_cErrMsg = public.serene(1, 'A040');

perform public.fnDropTemporaryTable('tmp_cif_omsetdata');
create temporary table tmp_cif_omsetdata
(
     cif    character varying
    ,cifori character varying
    ,omset  numeric(30,4)
)
distributed randomly;

z_cErrMsg = public.serene(1, 'A050');

perform public.fnDropTemporaryTable('tmp_cif_gajidata');
create temporary table tmp_cif_gajidata
(
     cif    character varying
    ,cifori character varying
    ,gaji   numeric(30,4)
)
distributed randomly;

z_cErrMsg = public.serene(1, 'A060');

perform public.fnDropTemporaryTable('tmp_cif_lainnyadata');
create temporary table tmp_cif_lainnyadata
(
     cif        character varying
    ,cifori     character varying
    ,kode       character varying
    ,lainnya    numeric(30,4)
    ,rowid      integer
)
distributed randomly;

z_cErrMsg = public.serene(1, 'A070');

perform public.fnDropTemporaryTable('tmp_cif_gajipasangandata');
create temporary table tmp_cif_gajipasangandata
(
     cif            character varying
    ,cifori         character varying
    ,gajipasangan   numeric(30,4)
)
distributed randomly;

z_cErrMsg = public.serene(1, 'A080');

perform public.fnDropTemporaryTable('tmp_jumlahtanggungan');
create temporary table tmp_jumlahtanggungan
(
     cifori             character varying
    ,jumlahtanggungan   integer
)
distributed randomly;


z_cErrMsg = public.serene(1, 'A100');

perform public.fnDropTemporaryTable('TMP_cfaidn_distinct_v_Priority');
create temporary table TMP_cfaidn_distinct_v_Priority
(
     cfcif_2    character varying(40)
    ,cfsscd     character varying
    ,cfssno     character varying
    ,scd_end    date
    ,rownumber  integer
)
distributed randomly;
z_cErrMsg = public.serene(1, 'A110');

perform public.fnDropTemporaryTable('tmp_omsetaset_ultron');
create temporary table tmp_omsetaset_ultron
(
     cif_no      character varying
    ,app_omset   numeric(30,0)
    ,total_asset numeric(30,0)
    ,rownumber   integer
)
distributed randomly;
z_cErrMsg = public.serene(1, 'A130');

perform public.fnDropTemporaryTable('TMP_17319884_customername_cleansing');
create temporary table TMP_17319884_customername_cleansing
(
     customerid                character varying
    ,customertype              character varying
    ,customername_ori          character varying
    ,customername_replacement  character varying
    ,customername_alphanumeric character varying
    ,customername_clean        character varying
    ,removedkeyword            character varying
       ,functionname              character varying
)
distributed randomly;

----------------------------------------------------------------------------------------------------------
-- Temporary Source Table Declaration --
----------------------------------------------------------------------------------------------------------
z_cErrMsg = public.serene(1, 'B010');

perform public.fnDropTemporaryTable('TMP_ps_n_debtur_org_slik_vw');
create temporary table TMP_ps_n_debtur_org_slik_vw
(
     c_cif_nbr          character varying(40)
    ,national_id_type   character varying
    ,national_id        character varying
    ,name               character varying
    ,education_lvl_achv character varying
    ,sex                character varying
    ,birthplace         character varying
    ,birthdate          character varying
    ,idn_tax_ee_id      character varying
    ,addresslong        character varying
    ,address3           character varying
    ,address4           character varying
    ,postal             character varying
    ,phone              character varying
    ,phone1             character varying
    ,email_addr         character varying
    ,descr              character varying
    ,addresslong10      character varying
    ,annual_rt          numeric(30,4)
    ,mar_status         character varying
    ,name2              character varying
    ,load_dt            date
    ,rowid              integer
    ,idn_tax_status     character varying
    ,national_id2       character varying
    ,name3              character varying
    ,date3              date
    ,n_c_pisah_harta    character varying
)
distributed randomly;

insert into TMP_ps_n_debtur_org_slik_vw
(
     c_cif_nbr          ,national_id_type   ,national_id    ,name
    ,education_lvl_achv ,sex                ,birthplace     ,birthdate
    ,idn_tax_ee_id      ,addresslong        ,address3       ,address4
    ,postal             ,phone              ,phone1         ,email_addr
    ,descr              ,addresslong10      ,annual_rt      ,mar_status
    ,name2              ,load_dt            ,rowid
    ,idn_tax_status
    ,national_id2
    ,name3
    ,date3
    ,n_c_pisah_harta
)
select
     xa.c_cif_nbr
    ,TRIM(xa.national_id_type)
    ,TRIM(xa.national_id)
    ,TRIM(xa.name)
    ,TRIM(xa.education_lvl_achv)
    ,TRIM(xa.sex)
    ,TRIM(xa.birthplace)
    ,TRIM(xa.birthdate)
    ,TRIM(xa.idn_tax_ee_id)
    ,TRIM(xa.addresslong)
    ,TRIM(xa.address3)
    ,TRIM(xa.address4)
    ,TRIM(xa.postal)
    ,TRIM(xa.phone)
    ,TRIM(xa.phone1)
    ,TRIM(xa.email_addr)
    ,TRIM(xa.descr)
    ,TRIM(xa.addresslong10)
    ,xa.annual_rt
    ,TRIM(xa.mar_status)
    ,TRIM(xa.name2)
    ,xa.load_dt
    ,ROW_NUMBER() OVER (partition by xa.c_cif_nbr order by xa.date_applied desc) as rowid
    ,TRIM(xa.idn_tax_status) as idn_tax_status
    ,TRIM(xa.national_id2) as national_id2
    ,TRIM(xa.name3) as name3
    ,xa.date3::date as date3
    ,TRIM(xa.n_c_pisah_harta) as n_c_pisah_harta
from ads.ps_n_debtur_org_slik_vw as xa
where xa.load_dt = z_dPeriodHC
;

delete from TMP_ps_n_debtur_org_slik_vw as xz
where xz.rowid <> 1
;

z_cErrMsg = public.serene(1, 'B020');

---- ads.cfbicd ----
perform public.fnDropTemporaryTable('TMP_cfbicd');
create temporary table TMP_cfbicd
(
     bihub1  numeric
    ,bijdsn  numeric
    ,bilok1  numeric
    ,bipemi  numeric
    ,bipfix  numeric
    ,cfcif_2 character varying(40)
    ,scd_end date
    ,bijndb  numeric
)
distributed randomly;

z_cColumnList = ''
|| CHR(10) || ' bihub1  ,bijdsn  ,bilok1  ,bipemi  ,bipfix  ,cfcif_2'
|| CHR(10) || ',bijndb'
;

z_cQuery = public.fnGenQuery4Partition('ads', 'cfbicd', z_dPeriod, z_dCurrEOD, NULL, z_cColumnList);
z_cQuery = ''
|| CHR(10) || 'insert into TMP_cfbicd'
|| CHR(10) || '('
|| CHR(10) || '     scd_end ,' || z_cColumnList
|| CHR(10) || ')'
|| CHR(10) || 'select'
|| CHR(10) || ' xa.scd_end'
|| CHR(10) || ',' || z_cColumnList
|| CHR(10) || 'from (' || z_cQuery || ') as xa'
|| CHR(10) || ';'
;

execute z_cQuery;

z_cErrMsg = public.serene(1, 'B030');

---- ads.cfmast ----
perform public.fnDropTemporaryTable('TMP_cfmast');
create temporary table TMP_cfmast
(
     cfbird  timestamp without time zone
    ,cfbrnn  character varying(10)
    ,cfcif_2 character varying(40)
    ,cfcitz  character varying
    ,cfclas  character varying
    ,cfcoun  character varying
    ,cfmotn  character varying
    ,cfna1   character varying
    ,cfsex   character varying
    ,cfsscd  character varying
    ,cfssno  character varying
    ,cfuic2  character varying
    ,cfuic3  character varying
    ,cfvusr  character varying
    ,cfybip  character varying
    ,scd_end date
    ,cfisd7  timestamp without time zone
    ,cfna1a  character varying
    ,cfytib  character varying
    ,cfytia  character varying
)
distributed randomly;

z_cColumnList = ''
|| CHR(10) || ' cfbird  ,cfbrnn  ,cfcif_2 ,cfcitz  ,cfclas  ,cfcoun'
|| CHR(10) || ',cfmotn  ,cfna1   ,cfsex   ,cfsscd  ,cfssno  ,cfuic2'
|| CHR(10) || ',cfuic3  ,cfvusr  ,cfybip'
|| CHR(10) || ',cfisd7'
|| CHR(10) || ',cfna1a'
|| CHR(10) || ',cfytib  ,cfytia'
;

z_cQuery = public.fnGenQuery4Partition('ads', 'cfmast', z_dPeriod, z_dCurrEOD, NULL, z_cColumnList);
z_cQuery = ''
|| CHR(10) || 'insert into TMP_cfmast'
|| CHR(10) || '('
|| CHR(10) || '     scd_end ,' || z_cColumnList
|| CHR(10) || ')'
|| CHR(10) || 'select'
|| CHR(10) || ' xa.scd_end'
|| CHR(10) || ',' || z_cColumnList
|| CHR(10) || 'from (' || z_cQuery || ') as xa'
|| CHR(10) || ';'
;

execute z_cQuery;

z_cErrMsg = public.serene(1, 'B040');

---- probi.cfpar2_log ----
perform public.fnDropTemporaryTable('tmp_cfpar2_log');
create temporary table tmp_cfpar2_log
(
     cp2cid     character varying
    ,cp2zip     numeric
    ,cpdtcd     numeric
    ,rowid      integer
)
distributed randomly;

insert into tmp_cfpar2_log
(
     cp2cid     ,cp2zip     ,cpdtcd
    ,rowid
)
select
     xa.cp2cid::integer as cp2cid
    ,xa.cp2zip as cp2zip
    ,xa.cpdtcd as cpdtcd
    ,row_number() OVER(partition by xa.hkeep_dt ,xa.cp2zip order by xa.cpdtcd asc, xa.cp2cid desc) as Rowid
from probi.cfpar2_log as xa
where xa.hkeep_dt = z_dPeriod
and xa.cpdtcd <> 0
;

delete from tmp_cfpar2_log as xz
where xz.rowid <> 1
;

z_cErrMsg = public.serene(1, 'B050');

---- ads.cfaddr_distinct_year_v ----
perform public.fnDropTemporaryTable('TMP_cfaddr_distinct_v');
create temporary table TMP_cfaddr_distinct_v
(
     cf2kec     character varying
    ,cf2kel     character varying
    ,cfcif_2    character varying(40)
    ,cfinvc     character varying
    ,cfmail     character varying
    ,cfna2      character varying
    ,cfna3      character varying
    ,cfna4      character varying
    ,cfzip      numeric
    ,scd_end    date
    ,cf2dt2     character varying
    ,cfcddt     integer
    ,cfna5      character varying
    ,priority   integer
    ,cfaseq     numeric
    ,priority_wni integer
    ,priority_wna integer
    ,rowid_wni integer
    ,rowid_wna integer
)
distributed randomly;

insert into TMP_cfaddr_distinct_v
(
     cf2kec
    ,cf2kel
    ,cfcif_2
    ,cfinvc
    ,cfmail
    ,cfna2
    ,cfna3
    ,cfna4
    ,cfzip
    ,scd_end
    ,cf2dt2
    ,cfcddt
    ,cfna5
    ,cfaseq
    ,priority_wni
    ,priority_wna
    ,rowid_wni
    ,rowid_wna
)
select
     xa.cf2kec
    ,xa.cf2kel
    ,xa.cfcif_2
    ,xa.cfinvc
    ,xa.cfmail
    ,xa.cfna2
    ,xa.cfna3
    ,xa.cfna4
    ,xa.cfzip
    ,xa.scd_end
    ,xa.cf2dt2
    ,xa.cfcddt
    ,xa.cfna5
    ,xa.cfaseq
    ,xb.value1::integer as priority_wni
    ,xc.value1::integer as priority_wna
    ,ROW_NUMBER() OVER(partition by xa.cfcif_2 order by xb.value1::integer asc) as rowid_wni
    ,ROW_NUMBER() OVER(partition by xa.cfcif_2 order by xc.value1::integer asc) as rowid_wna
from ads.cfaddr_distinct_year_v as xa
left join probi.regulatory_mapping_tr as xb
    on  xb.hkeep_dt = xa.scd_end
    and xb.mappingcode = 'priorityaddress'
    and xb.isactive = 'A'
    and xb.addmappingcode1 = 'WNI'
    and xb.hostvalue = xa.cfinvc
left join probi.regulatory_mapping_tr as xc
    on  xc.hkeep_dt = xa.scd_end
    and xc.mappingcode = 'priorityaddress'
    and xc.isactive = 'A'
    and xc.addmappingcode1 = 'WNA'
    and xc.hostvalue = xa.cfinvc
where xa.scd_end = z_dPeriod
and xa.cfinvc_rowid = 1
;

z_cErrMsg = public.serene(1, 'B060');

---- ads.cfconn_distinct_year_v ----
perform public.fnDropTemporaryTable('TMP_cfconn_distinct_v');
create temporary table TMP_cfconn_distinct_v
(
     cfcif_2 character varying(40)
    ,cfeadc  character varying
    ,cfeadd  character varying
    ,scd_end date
)
distributed randomly;

insert into TMP_cfconn_distinct_v
(
     cfcif_2
    ,cfeadc
    ,cfeadd
    ,scd_end
)
select
     xa.cfcif_2
    ,xa.cfeadc
    ,xa.cfeadd
    ,xa.scd_end
from ads.cfconn_distinct_year_v as xa
where xa.scd_end = z_dPeriod
;


z_cErrMsg = public.serene(1, 'B061');

---- ads.cfconn ----
perform public.fnDropTemporaryTable('tmp_cfconn_cleansing');
create temporary table tmp_cfconn_cleansing
(
     cfcif_2        character varying(40)
    ,cfeadc         character varying
    ,cfzseq         numeric
    ,cfeadd         character varying
    ,cfeadd_cleanse character varying
    ,scd_end        date
)
distributed randomly;

z_cColumnList = ''
|| CHR(10) || ' cfcif_2 ,cfeadc  ,cfeadd  ,cfzseq'
;

z_cQuery = public.fnGenQuery4Partition('ads', 'cfconn', z_dPeriod, z_dCurrEOD, NULL, z_cColumnList);
z_cQuery = ''
|| CHR(10) || 'insert into tmp_cfconn_cleansing'
|| CHR(10) || '('
|| CHR(10) || '     scd_end ,' || z_cColumnList
|| CHR(10) || ')'
|| CHR(10) || 'select'
|| CHR(10) || '     xa.scd_end'
|| CHR(10) || '    ,' || z_cColumnList
|| CHR(10) || 'from (' || z_cQuery || ') as xa'
|| CHR(10) || ';'
;

execute z_cQuery;

z_cErrMsg = public.serene(1, 'B061.1');
-- cleansing no telepon dan hp yang kode TR, TK, FR, FK dan HP, jika ketemu tanda / ambil sampai ketemu tanda / --
update tmp_cfconn_cleansing as xz
set
     cfeadd_cleanse = case
                          when position('/' in xz.cfeadd) = 0 then xz.cfeadd
                          else trim(substring(xz.cfeadd, 1, position('/' in xz.cfeadd) - 1))
                      end
where xz.scd_end = z_dPeriod
and xz.cfeadc in
(
     'TR'
    ,'TK'
    ,'FR'
    ,'FK'
    ,'HP'
)
;

z_cErrMsg = public.serene(1, 'B061.2');

-- cleansing no telepon dan hp yang kode TR, TK, FR, FK dan HP, jika ketemu tanda , ambil sampai ketemu tanda , --
update tmp_cfconn_cleansing as xz
set
     cfeadd_cleanse = case
                          when position(',' in xz.cfeadd_cleanse) = 0 then xz.cfeadd_cleanse
                          else trim(substring(xz.cfeadd_cleanse, 1, position(',' in xz.cfeadd_cleanse) - 1))
                      end
where xz.scd_end = z_dPeriod
and xz.cfeadc in
(
     'TR'
    ,'TK'
    ,'FR'
    ,'FK'
    ,'HP'
)
;

z_cErrMsg = public.serene(1, 'B061.3');

-- cleansing no telepon dan hp yang kode TR, TK, FR, FK dan HP, jika ketemu tanda - ambil sampai ketemu tanda - --
update tmp_cfconn_cleansing as xz
set
     cfeadd_cleanse = case
                          when position('-' in xz.cfeadd_cleanse)  = 0 then xz.cfeadd_cleanse
                          when position('-' in xz.cfeadd_cleanse) <= 5 then xz.cfeadd_cleanse
                          else trim(substring(xz.cfeadd_cleanse, 1, position('-' in xz.cfeadd_cleanse) - 1))
                      end
where xz.scd_end = z_dPeriod
and xz.cfeadc in
(
     'TR'
    ,'TK'
    ,'FR'
    ,'FK'
    ,'HP'
)
;

z_cErrMsg = public.serene(1, 'B061.4');

-- regexp_replace no telepon dan hp yang kode TR, TK, FR, FK dan HP --
update tmp_cfconn_cleansing as xz
set
     cfeadd_cleanse = regexp_replace(xz.cfeadd_cleanse, '[^0-9 ]', ' ', 'g')
where xz.scd_end = z_dPeriod
and xz.cfeadc in
(
     'TR'
    ,'TK'
    ,'FR'
    ,'FK'
    ,'HP'
)
;

z_cErrMsg = public.serene(1, 'B061.5');

-- cleansing no telepon dan hp yang kode TR, TK, FR, FK dan HP, jika ketemu tanda ' ' ambil sampai ketemu tanda ' ' --
update tmp_cfconn_cleansing as xz
set
     cfeadd_cleanse = case
                          when position(' ' in xz.cfeadd_cleanse)  = 0 then xz.cfeadd_cleanse
                          when position(' ' in xz.cfeadd_cleanse) <= 5 then xz.cfeadd_cleanse
                          else trim(substring(xz.cfeadd_cleanse, 1, position(' ' in xz.cfeadd_cleanse) - 1))
                      end
where xz.scd_end = z_dPeriod
and xz.cfeadc in
(
     'TR'
    ,'TK'
    ,'FR'
    ,'FK'
    ,'HP'
)
;

z_cErrMsg = public.serene(1, 'B061.6');

-- cleansing tanda baca yang kode TR, TK, FR dan FK --
update tmp_cfconn_cleansing as xz
set
     cfeadd_cleanse = substring(replace(public.fnReplaceAlphaNumeric(xz.cfeadd_cleanse), ' ', ''), 1, 11)
where xz.scd_end = z_dPeriod
and xz.cfeadc in
(
     'TR'
    ,'TK'
    ,'FR'
    ,'FK'
)
;

z_cErrMsg = public.serene(1, 'B061.7');

-- cleansing tanda baca yang kode HP --
update tmp_cfconn_cleansing as xz
set
     cfeadd_cleanse = substring(replace(public.fnReplaceAlphaNumeric(xz.cfeadd_cleanse), ' ', ''), 1, 13)
where xz.scd_end = z_dPeriod
and xz.cfeadc in
(
     'HP'
)
;

z_cErrMsg = public.serene(1, 'B062');

-- telepon untuk debitur perorangan --
perform public.fnDropTemporaryTable('tmp_telepon_perorangan');
create temporary table tmp_telepon_perorangan
(
     cfcif_2        character varying(40)
    ,cfeadc         character varying
    ,cfeadc_prio    integer
    ,cfzseq         numeric
    ,cfeadd_cleanse character varying
    ,validflag      integer
    ,rownumber      integer
    ,scd_end        date
)
distributed randomly;

z_cErrMsg = public.serene(1, 'B062.1');

-- telepon untuk debitur perorangan final yang ambil validflag = 1 (true) --
perform public.fnDropTemporaryTable('tmp_telepon_perorangan_final');
create temporary table tmp_telepon_perorangan_final
(
     cfcif_2            character varying(40)
    ,cfeadc             character varying
    ,cfeadc_prio        integer
    ,cfzseq             numeric
    ,cfeadd_cleanse     character varying
    ,validflag          integer
    ,rownumber          integer
    ,rownumber_pilih    integer
    ,scd_end            date
)
distributed randomly;

z_cErrMsg = public.serene(1, 'B062.2');

-- telepon untuk debitur perorangan default jika tidak ada yang validflag = 1 (true) --
perform public.fnDropTemporaryTable('tmp_telepon_perorangan_default');
create temporary table tmp_telepon_perorangan_default
(
     cfcif_2            character varying(40)
    ,cfeadc             character varying
    ,cfeadc_prio        integer
    ,cfzseq             numeric
    ,cfeadd_cleanse     character varying
    ,validflag          integer
    ,rownumber          integer
    ,rownumber_pilih    integer
    ,scd_end            date
)
distributed randomly;

z_cErrMsg = public.serene(1, 'B063');

-- telepon untuk debitur badan usaha --
perform public.fnDropTemporaryTable('tmp_telepon_badanusaha');
create temporary table tmp_telepon_badanusaha
(
     cfcif_2        character varying(40)
    ,cfeadc         character varying
    ,cfeadc_prio    integer
    ,cfzseq         numeric
    ,cfeadd_cleanse character varying
    ,validflag      integer
    ,rownumber      integer
    ,scd_end        date
)
distributed randomly;

z_cErrMsg = public.serene(1, 'B063.1');

-- telepon untuk debitur badan usaha final yang ambil validflag = 1 (true) --
perform public.fnDropTemporaryTable('tmp_telepon_badanusaha_final');
create temporary table tmp_telepon_badanusaha_final
(
     cfcif_2            character varying(40)
    ,cfeadc             character varying
    ,cfeadc_prio        integer
    ,cfzseq             numeric
    ,cfeadd_cleanse     character varying
    ,validflag          integer
    ,rownumber          integer
    ,rownumber_pilih    integer
    ,scd_end            date
)
distributed randomly;

z_cErrMsg = public.serene(1, 'B063.2');

-- telepon untuk debitur badan usaha default jika tidak ada yang validflag = 1 (true) --
perform public.fnDropTemporaryTable('tmp_telepon_badanusaha_default');
create temporary table tmp_telepon_badanusaha_default
(
     cfcif_2            character varying(40)
    ,cfeadc             character varying
    ,cfeadc_prio        integer
    ,cfzseq             numeric
    ,cfeadd_cleanse     character varying
    ,validflag          integer
    ,rownumber          integer
    ,rownumber_pilih    integer
    ,scd_end            date
)
distributed randomly;

z_cErrMsg = public.serene(1, 'B064');

-- no telepon genggam untuk debitur perorangan dan badan usaha --
perform public.fnDropTemporaryTable('tmp_notelepongenggam');
create temporary table tmp_notelepongenggam
(
     cfcif_2        character varying(40)
    ,cfeadc         character varying
    ,cfzseq         numeric
    ,cfeadd_cleanse character varying
    ,validflag      integer
    ,scd_end        date
)
distributed randomly;

z_cErrMsg = public.serene(1, 'B064.1');

-- no telepon genggam untuk debitur perorangan dan badan usaha final yang ambil validflag = 1 (true) --
perform public.fnDropTemporaryTable('tmp_notelepongenggam_final');
create temporary table tmp_notelepongenggam_final
(
     cfcif_2            character varying(40)
    ,cfeadc             character varying
    ,cfzseq             numeric
    ,cfeadd_cleanse     character varying
    ,validflag          integer
    ,rownumber_pilih    integer
    ,scd_end            date
)
distributed randomly;

z_cErrMsg = public.serene(1, 'B064.2');

-- no telepon genggam untuk debitur perorangan dan badan usaha default jika tidak ada yang validflag = 1 (true) --
perform public.fnDropTemporaryTable('tmp_notelepongenggam_default');
create temporary table tmp_notelepongenggam_default
(
     cfcif_2            character varying(40)
    ,cfeadc             character varying
    ,cfzseq             numeric
    ,cfeadd_cleanse     character varying
    ,validflag          integer
    ,rownumber_pilih    integer
    ,scd_end            date
)
distributed randomly;


z_cErrMsg = public.serene(1, 'B070');

---- ads.cfzemp_distinct_year_v ----
perform public.fnDropTemporaryTable('TMP_cfzemp_distinct_v');
create temporary table TMP_cfzemp_distinct_v
(
     cfcif_2 character varying(40)
    ,cfecur  numeric
    ,cfena1  character varying
    ,cfenin  character varying
    ,cfoccd  character varying
    ,scd_end date
    ,cfcurr  character varying
)
distributed randomly;

insert into TMP_cfzemp_distinct_v
(
     cfcif_2
    ,cfecur
    ,cfena1
    ,cfenin
    ,cfoccd
    ,scd_end
    ,cfcurr
)
select
     xa.cfcif_2
    ,xa.cfecur
    ,xa.cfena1
    ,xa.cfenin
    ,xa.cfoccd
    ,xa.scd_end
    ,upper(xa.cfcurr) as cfcurr
from ads.cfzemp_distinct_year_v as xa
where xa.scd_end = z_dPeriod
;

z_cErrMsg = public.serene(1, 'B080');

---- ads.cfaidn_distinct_year_v ----
perform public.fnDropTemporaryTable('TMP_cfaidn_distinct_v');
create temporary table TMP_cfaidn_distinct_v
(
     cfcif_2    character varying(40)
    ,cfsscd     character varying
    ,cfssno     character varying
    ,scd_end    date
    ,priority   integer
    ,cfisd7     timestamp without time zone
)
distributed randomly;

insert into TMP_cfaidn_distinct_v
(
     cfcif_2 ,cfsscd ,cfssno ,scd_end
    ,cfisd7
)
select
     xa.cfcif_2
    ,xa.cfsscd
    ,xa.cfssno
    ,xa.scd_end
    ,xa.cfisd7
from ads.cfaidn_distinct_year_v as xa
where xa.scd_end = z_dperiod
;

z_cErrMsg = public.serene(1, 'B090');

---- probi.regulatory_mapping_tr ----
perform public.fnDropTemporaryTable('tmp_regulatory_mapping_tr');
create temporary table tmp_regulatory_mapping_tr
(
     mappingcode     character varying
    ,hostvalue       character varying
    ,antasenavalue   character varying
    ,slikvalue       character varying
    ,isactive        character varying
    ,addmappingcode1 character varying
    ,hkeep_dt        date
)
distributed randomly;

insert into tmp_regulatory_mapping_tr
(
     mappingcode     ,hostvalue       ,antasenavalue   ,slikvalue       ,isactive
    ,addmappingcode1 ,hkeep_dt
)
select
     xa.mappingcode
    ,xa.hostvalue
    ,xa.antasenavalue
    ,xa.slikvalue
    ,xa.isactive
    ,xa.addmappingcode1
    ,xa.hkeep_dt
from probi.regulatory_mapping_tr as xa
where xa.hkeep_dt = z_dPeriod
;


z_cErrMsg = public.serene(1, 'B091');

---- ads.cfysie ----
perform public.fnDropTemporaryTable('TMP_cfysie');
create temporary table TMP_cfysie
(
     cfcif_2 character varying(40)
    ,cfvusr  character varying
    ,cfyamt  numeric
    ,cfycur  character varying
    ,cfyiec  character varying
    ,scd_end date
)
distributed randomly;

z_cColumnList = ''
|| CHR(10) || ' cfcif_2 ,cfvusr  ,cfyamt  ,cfycur  ,cfyiec'
;

z_cQuery = public.fnGenQuery4Partition('ads', 'cfysie', z_dPeriod, z_dCurrEOD, NULL, z_cColumnList);
z_cQuery = ''
|| CHR(10) || 'insert into TMP_cfysie'
|| CHR(10) || '('
|| CHR(10) || '     scd_end ,' || z_cColumnList
|| CHR(10) || ')'
|| CHR(10) || 'select'
|| CHR(10) || ' xa.scd_end'
|| CHR(10) || ',' || z_cColumnList
|| CHR(10) || 'from (' || z_cQuery || ') as xa'
|| CHR(10) || ';'
;

execute z_cQuery;
z_cErrMsg = public.serene(1, 'B110');

---- ads.lms_workflow_log_history ----
perform public.fnDropTemporaryView('TMPV_lms_workflow_log_history');

z_cColumnList = ''
|| CHR(10) || ' update_date ,decision    ,app_omset   ,cst_cif     ,total_asset'
;

z_cQuery = public.fnGenQuery4Partition('ads', 'lms_workflow_log_history', z_dPeriod, z_dCurrEOD, NULL, z_cColumnList);
z_cQuery = ''
|| CHR(10) || 'create or replace temporary view TMPV_lms_workflow_log_history as'
|| CHR(10) || 'select'
|| CHR(10) || '     xa.*'
|| CHR(10) || 'from (' || z_cQuery || ') as xa'
|| CHR(10) || ';'
;

execute z_cQuery;

z_cErrMsg = public.serene(1, 'B120');

perform public.fnDropTemporaryTable('tmp_lms_workflow_log_history_AssetOmset');
create temporary table tmp_lms_workflow_log_history_AssetOmset
(
     cst_cif        character varying
    ,app_omset      numeric(30,4)
    ,total_asset    numeric(30,4)
    ,update_date    timestamp without time zone
    ,rownumber      integer
)
distributed randomly;

insert into tmp_lms_workflow_log_history_AssetOmset
(
     cst_cif
    ,app_omset
    ,total_asset
    ,update_date
    ,rownumber
)
select
     xa.cst_cif
    ,xa.app_omset
    ,xa.total_asset
    ,xa.update_date
    ,ROW_NUMBER() OVER (partition by xa.cst_cif order by (xa.update_date::date) desc) as rownumber
from TMPV_lms_workflow_log_history as xa
inner join mis.manparam_lmsparametermapping as xb
    on xb.parametertype = 'lms_decision'
    and xb.isactive = 1
    and lower(xb.parametercode) = lower(xa.decision)
where xa.hkeep_dt = z_dPeriod
;

delete from tmp_lms_workflow_log_history_AssetOmset as xz
where xz.rownumber <> 1
;

----------------------------------------------------------------------------------------------------------
-- Main Process --
----------------------------------------------------------------------------------------------------------
z_cErrMsg = public.serene(1, 'C010');

insert into tmp_datamart_customerdetail
(
     hkeep_dt                 ,customerid_ori           ,customerid_konven
    ,customerid_syariah       ,customertype             ,officecustomer
    ,customername             ,namalengkap              ,kodenegara
    ,flagwniwna               ,kodestatusgelardebitur   ,jeniskelamin
    ,tempatlahirktp           ,tanggallahir             ,penghasilankotorpertahun
    ,statusperkawinandebitur  ,namagadisibukandung      ,source
    ,insertquery              ,officecustomer_ori       ,kewarganegaraan
)
select
     z_dPeriod as period
    ,xa.cfcif_2 as customerid_ori
    ,xa.cfcif_2 as customerid_konven
    ,'' as customerid_syariah
    ,xa.cfclas as customertype
    ,xa.cfbrnn as officecustomer
    ,xa.cfna1 as customername
    ,xa.cfna1 as namalengkap
    ,xa.cfcoun as kodenegara
    ,case
         when xa.cfcitz = '000' then 'WNI'
         else 'WNA'
     end as flagwniwna
    ,xa.cfuic3 as kodestatusgelardebitur
    ,xa.cfsex as jeniskelamin
    ,xa.cfybip as tempatlahirktp
    ,COALESCE(xa.cfbird, '19000101'::date) as tanggallahir
    ,0 as penghasilankotorpertahun
    ,xa.cfuic2 as statusperkawinandebitur
    ,xa.cfmotn as namagadisibukandung
    ,'cfmast' as source
    ,'IQ-01' as insertquery
    ,xa.cfbrnn as officecustomer_ori
    ,xa.cfcitz as kewarganegaraan
from tmp_cfmast as xa
where xa.scd_end = z_dPeriod
;

z_cErrMsg = public.serene(1, 'C020');

----update CIF syariah
----baik untuk customer yang punya loan atau tidak
update tmp_datamart_customerdetail as xz
set
     customerid_syariah = xa.cfsyr_2
    ,updatequery = xz.updatequery || 'UQ-001#'
from ads.cfsyrmp as xa
where xa.hkeep_dt = z_dPeriod
and xz.customerid_ori = xa.cfcif_2
;

z_cErrMsg = public.serene(1, 'C030');

---- update IDType, IdNumber dari ads. cfmast berdasarkan FlagWNIWNA yang debitur perorangan WNI ----
update tmp_datamart_customerdetail as xz
set
     IDType = xa.cfsscd
    ,IdNumber = xa.cfssno
    ,updatequery = xz.updatequery || 'UQ-002#'
from tmp_cfmast as xa
where xa.scd_end = z_dPeriod
and xa.cfsscd in
(
     'KTP', 'KTPS'
    ,'KK'
)
and xz.flagwniwna = 'WNI'
and xz.customertype = 'A'
and xz.customerid_ori = xa.cfcif_2
;

z_cErrMsg = public.serene(1, 'C040');

---- update IDType, IdNumber dari ads. cfmast berdasarkan FlagWNIWNA yang debitur perorangan WNA ----
update tmp_datamart_customerdetail as xz
set
     IDType = xa.cfsscd
    ,IdNumber = xa.cfssno
    ,updatequery = xz.updatequery || 'UQ-003#'
from tmp_cfmast as xa
where xa.scd_end = z_dPeriod
and xa.cfsscd in
(
     'PP'
)
and xz.flagwniwna = 'WNA'
and xz.customertype = 'A'
and xz.customerid_ori = xa.cfcif_2
;


z_cErrMsg = public.serene(1, 'B081');

update TMP_cfaidn_distinct_v as xz
set
    priority = xa.paramvalue::integer
from probi.regulatory_param as xa
where xa.paramgroup = 'PriorityIDType'
and xa.notes = 'datamart_customerdetail'
and xz.scd_end = xa.hkeep_dt
and xz.cfsscd = xa.paramdescription
;

insert into TMP_cfaidn_distinct_v_Priority
(
     cfcif_2 ,cfsscd ,cfssno ,scd_end
    ,rownumber
)
select
     xa.cfcif_2
    ,xa.cfsscd
    ,xa.cfssno
    ,xa.scd_end
    ,ROW_NUMBER() OVER (partition by xa.cfcif_2 order by  (xa.priority) asc) as rownumber
from TMP_cfaidn_distinct_v as xa
where xa.cfsscd in
(
     'KTP'
    ,'KTPS'
    ,'KK'
)
;

delete from TMP_cfaidn_distinct_v_Priority as xz
where xz.rownumber <> 1
;


z_cErrMsg = public.serene(1, 'C050');

--Jika masih kosong update dari cfaidn
update tmp_datamart_customerdetail as xz
set
     IDType = xa.cfsscd
    ,IdNumber = xa.cfssno
    ,updatequery = xz.updatequery || 'UQ-004#'
from TMP_cfaidn_distinct_v_Priority as xa
where xa.scd_end = z_dPeriod
and xa.cfsscd in
(
     'KTP', 'KTPS'
    ,'KK'
)
and xz.flagwniwna = 'WNI'
and xz.customertype = 'A'
and coalesce(xz.IDType, '') = ''
and xz.customerid_ori = xa.cfcif_2
;

z_cErrMsg = public.serene(1, 'C060');

update tmp_datamart_customerdetail as xz
set
     IDType = xa.cfsscd
    ,IdNumber = xa.cfssno
    ,updatequery = xz.updatequery || 'UQ-005#'
from tmp_cfaidn_distinct_v as xa
where xa.scd_end = z_dPeriod
and xa.cfsscd in
(
     'PP'
)
and xz.flagwniwna = 'WNA'
and xz.customertype = 'A'
and coalesce(xz.IDType, '') = ''
and xz.customerid_ori = xa.cfcif_2
;

--ini untuk idtype munculin dulu saja semua nya untuk yang selain KTP, KTPS, PP --> biar ketahuan tidak ada mappingnya
--KITS -- kartu izin tinggal terbatas
z_cErrMsg = public.serene(1, 'C490');

update tmp_datamart_customerdetail as xz
set
     IDType = xa.cfsscd
    ,IdNumber = xa.cfssno
    ,updatequery = xz.updatequery || 'UQ-006#'
from tmp_cfmast as xa
where xa.scd_end = z_dPeriod
and xa.cfsscd  in
(
     'KIMS' -- kartu izin menetap sementara
    ,'KITS' -- kartu izin tinggal terbatas
)
and xz.customertype = 'A'
and coalesce(xz.IDType, '') = ''
and xz.flagwniwna = 'WNA'
and xz.customerid_ori = xa.cfcif_2
;

z_cErrMsg = public.serene(1, 'C460');

update tmp_datamart_customerdetail as xz
set
     IDType = xa.cfsscd
    ,IdNumber = xa.cfssno
    ,updatequery = xz.updatequery || 'UQ-007#'
from tmp_cfmast as xa
where xa.scd_end = z_dPeriod
and xz.customertype = 'A'
and coalesce(xz.IDType, '') = ''
and xz.customerid_ori = xa.cfcif_2
;

z_cErrMsg = public.serene(1, 'C070');

---update untuk badan usaha
update tmp_datamart_customerdetail as xz
set
     IDType = xa.cfsscd
    ,IdNumber = xa.cfssno
    ,updatequery = xz.updatequery || 'UQ-008#'
from tmp_cfaidn_distinct_v as xa
where xa.scd_end = z_dPeriod
and xa.cfsscd in
(
     'NPWP'
)
and xz.customertype <> 'A'
and xz.customerid_ori = xa.cfcif_2
;

z_cErrMsg = public.serene(1, 'C080');

--update NPWP
update tmp_datamart_customerdetail as xz
set
     npwp = xa.cfssno
    ,updatequery = xz.updatequery || 'UQ-009#'
from tmp_cfmast as xa
where xa.scd_end = z_dPeriod
and xa.cfsscd in
(
     'NPWP'
)
and xz.customerid_ori = xa.cfcif_2
;

z_cErrMsg = public.serene(1, 'C090');

--jika masih kosong npwp nya ambil dari cfaidn
update tmp_datamart_customerdetail as xz
set
     npwp = xa.cfssno
    ,updatequery = xz.updatequery || 'UQ-010#'
from tmp_cfaidn_distinct_v as xa
where xa.scd_end = z_dPeriod
and xa.cfsscd in
(
     'NPWP'
)
and coalesce(xz.npwp, '') = ''
and xz.customerid_ori = xa.cfcif_2
;

z_cErrMsg = public.serene(1, 'C091');
-- jika masih kosong ambil apaadanya dari cfmast
update tmp_datamart_customerdetail as xz
set
     IDType = xa.cfsscd
    ,IdNumber = xa.cfssno
    ,updatequery = xz.updatequery || 'UQ-0101#'
from tmp_cfmast as xa
where xa.scd_end = z_dPeriod
and coalesce(xz.idtype,'') = ''
and xz.customertype <> 'A'
and xz.customerid_ori = xa.cfcif_2
;


z_cErrMsg = public.serene(1, 'C100');

---update nama lengkap
-- tambah update dari cfmast kolom cfna1a klo ga ada di cfna1 --
update tmp_datamart_customerdetail as xz
set
     NamaLengkap = xa.cfna1a
    ,customername = xa.cfna1a
    ,updatequery = xz.updatequery || 'UQ-011#'
from tmp_cfmast as xa
where xa.scd_end = z_dPeriod
and coalesce(xz.NamaLengkap, '') = ''
and coalesce(xz.customername, '') = ''
and xz.customerid_ori = xa.cfcif_2
;


z_cErrMsg = public.serene(1, 'C120.1');

insert into tmp_telepon_perorangan
(
     cfcif_2
    ,cfeadc
    ,cfeadc_prio
    ,cfzseq
    ,cfeadd_cleanse
    ,validflag
    ,rownumber
    ,scd_end
)
select
     xa.cfcif_2 as cfcif_2
    ,xa.cfeadc as cfeadc
    ,xc.value::integer as cfeadc_prio
    ,xa.cfzseq as cfzseq
    ,xa.cfeadd_cleanse as cfeadd_cleanse
    ,case
         when length(xa.cfeadd_cleanse) >= 7 then 1 -- true --
         else 0 -- false --
     end as validflag
    ,row_number() OVER(partition by xa.scd_end, xa.cfcif_2, xa.cfeadc order by xa.cfzseq asc) as rownumber
    ,xa.scd_end as scd_end
from tmp_cfconn_cleansing as xa
inner join tmp_datamart_customerdetail as xb
    on  xb.customerid_ori = xa.cfcif_2
    and xb.customertype = 'A' -- Debitur Perorangan --
inner join probi.slik_setting_param as xc
    on  xc.detail = xa.cfeadc
    and xc.parameterid = 'priority - telepon - d01'
where xa.scd_end = z_dPeriod
;

z_cErrMsg = public.serene(1, 'C120.2');

insert into tmp_telepon_perorangan_final
(
     cfcif_2
    ,cfeadc
    ,cfeadc_prio
    ,cfzseq
    ,cfeadd_cleanse
    ,validflag
    ,rownumber
    ,rownumber_pilih
    ,scd_end
)
select
     xa.cfcif_2 as cfcif_2
    ,xa.cfeadc as cfeadc
    ,xa.cfeadc_prio as cfeadc_prio
    ,xa.cfzseq as cfzseq
    ,xa.cfeadd_cleanse as cfeadd_cleanse
    ,xa.validflag as validflag
    ,xa.rownumber as rownumber
    ,row_number() OVER(partition by xa.scd_end, xa.cfcif_2 order by xa.cfeadc_prio asc, xa.cfzseq asc) as rownumber_pilih
    ,xa.scd_end as scd_end
from tmp_telepon_perorangan as xa
where xa.scd_end = z_dPeriod
and xa.validflag = 1
;

z_cErrMsg = public.serene(1, 'C120.3');

insert into tmp_telepon_perorangan_default
(
     cfcif_2
    ,cfeadc
    ,cfeadc_prio
    ,cfzseq
    ,cfeadd_cleanse
    ,validflag
    ,rownumber
    ,rownumber_pilih
    ,scd_end
)
select
     xa.cfcif_2 as cfcif_2
    ,xa.cfeadc as cfeadc
    ,xa.cfeadc_prio as cfeadc_prio
    ,xa.cfzseq as cfzseq
    ,xa.cfeadd_cleanse as cfeadd_cleanse
    ,xa.validflag as validflag
    ,xa.rownumber as rownumber
    ,row_number() OVER(partition by xa.scd_end, xa.cfcif_2 order by xa.cfeadc_prio asc, xa.cfzseq asc) as rownumber_pilih
    ,xa.scd_end as scd_end
from tmp_telepon_perorangan as xa
left join tmp_telepon_perorangan_final as xb
    on  xb.cfcif_2 = xa.cfcif_2
    and xb.scd_end = xa.scd_end
where xa.scd_end = z_dPeriod
and xb.cfcif_2 is null -- ambil yang validflag = 0 --
;

z_cErrMsg = public.serene(1, 'C121.1');

---- update telepon dari tmp_telepon_perorangan_final untuk debitur perorangan ----
update tmp_datamart_customerdetail as xz
set
     telepon = xa.cfeadd_cleanse
    ,updatequery = xz.updatequery || 'UQ-013.1#'
from tmp_telepon_perorangan_final as xa
where xa.scd_end = z_dPeriod
and xa.rownumber_pilih = 1
and xz.customerid_ori = xa.cfcif_2
;

z_cErrMsg = public.serene(1, 'C121.2');
---- update telepon dari tmp_telepon_perorangan_default untuk debitur perorangan jika tidak ada validflag = 1 (true) ----
update tmp_datamart_customerdetail as xz
set
     telepon = xa.cfeadd_cleanse
    ,updatequery = xz.updatequery || 'UQ-013.2#'
from tmp_telepon_perorangan_default as xa
where xa.scd_end = z_dPeriod
and xa.rownumber_pilih = 1
and xz.customerid_ori = xa.cfcif_2
;

z_cErrMsg = public.serene(1, 'C122.1');

insert into tmp_telepon_badanusaha
(
     cfcif_2
    ,cfeadc
    ,cfeadc_prio
    ,cfzseq
    ,cfeadd_cleanse
    ,validflag
    ,rownumber
    ,scd_end
)
select
     xa.cfcif_2 as cfcif_2
    ,xa.cfeadc as cfeadc
    ,xc.value::integer as cfeadc_prio
    ,xa.cfzseq as cfzseq
    ,xa.cfeadd_cleanse as cfeadd_cleanse
    ,case
         when length(xa.cfeadd_cleanse) >= 7 then 1 -- true --
         else 0 -- false --
     end as validflag
    ,row_number() OVER(partition by xa.scd_end, xa.cfcif_2, xa.cfeadc order by xa.cfzseq asc) as rownumber
    ,xa.scd_end as scd_end
from tmp_cfconn_cleansing as xa
inner join tmp_datamart_customerdetail as xb
    on  xb.customerid_ori = xa.cfcif_2
    and xb.customertype <> 'A' -- Debitur Badan Usaha --
inner join probi.slik_setting_param as xc
    on  xc.detail = xa.cfeadc
    and xc.parameterid = 'priority - telepon - d02'
where xa.scd_end = z_dPeriod
;

z_cErrMsg = public.serene(1, 'C122.2');

insert into tmp_telepon_badanusaha_final
(
     cfcif_2
    ,cfeadc
    ,cfeadc_prio
    ,cfzseq
    ,cfeadd_cleanse
    ,validflag
    ,rownumber
    ,rownumber_pilih
    ,scd_end
)
select
     xa.cfcif_2 as cfcif_2
    ,xa.cfeadc as cfeadc
    ,xa.cfeadc_prio as cfeadc_prio
    ,xa.cfzseq as cfzseq
    ,xa.cfeadd_cleanse as cfeadd_cleanse
    ,xa.validflag as validflag
    ,xa.rownumber as rownumber
    ,row_number() OVER(partition by xa.scd_end, xa.cfcif_2 order by xa.cfeadc_prio asc, xa.cfzseq asc) as rownumber_pilih
    ,xa.scd_end as scd_end
from tmp_telepon_badanusaha as xa
where xa.scd_end = z_dPeriod
and xa.validflag = 1
;

z_cErrMsg = public.serene(1, 'C122.3');

insert into tmp_telepon_badanusaha_default
(
     cfcif_2
    ,cfeadc
    ,cfeadc_prio
    ,cfzseq
    ,cfeadd_cleanse
    ,validflag
    ,rownumber
    ,rownumber_pilih
    ,scd_end
)
select
     xa.cfcif_2 as cfcif_2
    ,xa.cfeadc as cfeadc
    ,xa.cfeadc_prio as cfeadc_prio
    ,xa.cfzseq as cfzseq
    ,xa.cfeadd_cleanse as cfeadd_cleanse
    ,xa.validflag as validflag
    ,xa.rownumber as rownumber
    ,row_number() OVER(partition by xa.scd_end, xa.cfcif_2 order by xa.cfeadc_prio asc, xa.cfzseq asc) as rownumber_pilih
    ,xa.scd_end as scd_end
from tmp_telepon_badanusaha as xa
left join tmp_telepon_badanusaha_final as xb
    on  xb.cfcif_2 = xa.cfcif_2
    and xb.scd_end = xa.scd_end
where xa.scd_end = z_dPeriod
and xb.cfcif_2 is null -- ambil yang validflag = 0 --
;

z_cErrMsg = public.serene(1, 'C124.1');

---- update telepon dari tmp_telepon_badanusaha_final untuk debitur badan usaha ----
update tmp_datamart_customerdetail as xz
set
     telepon = xa.cfeadd_cleanse
    ,updatequery = xz.updatequery || 'UQ-014.1#'
from tmp_telepon_badanusaha_final as xa
where xa.scd_end = z_dPeriod
and xa.rownumber_pilih = 1
and xz.customerid_ori = xa.cfcif_2
;

z_cErrMsg = public.serene(1, 'C124.2');

---- update telepon dari tmp_telepon_badanusaha_default untuk debitur badan usaha jika tidak ada validflag = 1 (true) ----
update tmp_datamart_customerdetail as xz
set
     telepon = xa.cfeadd_cleanse
    ,updatequery = xz.updatequery || 'UQ-014.2#'
from tmp_telepon_badanusaha_default as xa
where xa.scd_end = z_dPeriod
and xa.rownumber_pilih = 1
and xz.customerid_ori = xa.cfcif_2
;

z_cErrMsg = public.serene(1, 'C125');

---- update telepon jadi '0' untuk debitur perorangan dan badan usaha, jika tidak ada yang TR, TK, FR dan FK ----
update tmp_datamart_customerdetail as xz
set
     telepon = '0'
    ,updatequery = xz.updatequery || 'UQ-015#'
from tmp_cfconn_cleansing as xa
where xa.scd_end = z_dPeriod
and xa.cfeadc not in ('TR','TK','FR','FK')
and coalesce(xz.telepon, '') = ''
and xz.customerid_ori = xa.cfcif_2
;

z_cErrMsg = public.serene(1, 'C126.1');

insert into tmp_notelepongenggam
(
     cfcif_2
    ,cfeadc
    ,cfzseq
    ,cfeadd_cleanse
    ,validflag
    ,scd_end
)
select
     xa.cfcif_2 as cfcif_2
    ,xa.cfeadc as cfeadc
    ,xa.cfzseq as cfzseq
    ,xa.cfeadd_cleanse as cfeadd_cleanse
    ,case
         when length(xa.cfeadd_cleanse) >= 7 then 1 -- true --
         else 0 -- false --
     end as validflag
    ,xa.scd_end as scd_end
from tmp_cfconn_cleansing as xa
inner join tmp_datamart_customerdetail as xb
    on  xb.customerid_ori = xa.cfcif_2
where xa.scd_end = z_dPeriod
and xa.cfeadc = 'HP'
;

z_cErrMsg = public.serene(1, 'C126.2');

insert into tmp_notelepongenggam_final
(
     cfcif_2
    ,cfeadc
    ,cfzseq
    ,cfeadd_cleanse
    ,validflag
    ,rownumber_pilih
    ,scd_end
)
select
     xa.cfcif_2 as cfcif_2
    ,xa.cfeadc as cfeadc
    ,xa.cfzseq as cfzseq
    ,xa.cfeadd_cleanse as cfeadd_cleanse
    ,xa.validflag as validflag
    ,row_number() OVER(partition by xa.scd_end, xa.cfcif_2 order by xa.cfzseq asc) as rownumber_pilih
    ,xa.scd_end as scd_end
from tmp_notelepongenggam as xa
where xa.scd_end = z_dPeriod
and xa.validflag = 1
;

z_cErrMsg = public.serene(1, 'C126.3');

insert into tmp_notelepongenggam_default
(
     cfcif_2
    ,cfeadc
    ,cfzseq
    ,cfeadd_cleanse
    ,validflag
    ,rownumber_pilih
    ,scd_end
)
select
     xa.cfcif_2 as cfcif_2
    ,xa.cfeadc as cfeadc
    ,xa.cfzseq as cfzseq
    ,xa.cfeadd_cleanse as cfeadd_cleanse
    ,xa.validflag as validflag
    ,row_number() OVER(partition by xa.scd_end, xa.cfcif_2 order by xa.cfzseq asc) as rownumber_pilih
    ,xa.scd_end as scd_end
from tmp_notelepongenggam as xa
left join tmp_notelepongenggam_final as xb
    on  xb.cfcif_2 = xa.cfcif_2
    and xb.scd_end = xa.scd_end
where xa.scd_end = z_dPeriod
and xb.cfcif_2 is null -- ambil yang validflag = 0 --
;

z_cErrMsg = public.serene(1, 'C127.1');

---- update nomortelepongenggam dari tmp_notelepongenggam_final untuk debitur perorangan dan badan usaha ----
update tmp_datamart_customerdetail as xz
set
     nomortelepongenggam = xa.cfeadd_cleanse
    ,updatequery = xz.updatequery || 'UQ-016.1#'
from tmp_notelepongenggam_final as xa
where xa.scd_end = z_dPeriod
and xa.rownumber_pilih = 1
and xz.customerid_ori = xa.cfcif_2
;

z_cErrMsg = public.serene(1, 'C127.2');

---- update nomortelepongenggam dari tmp_notelepongenggam_default untuk debitur perorangan dan badan usaha jika tidak ada validflag = 1 (true) ----
update tmp_datamart_customerdetail as xz
set
     nomortelepongenggam = xa.cfeadd_cleanse
    ,updatequery = xz.updatequery || 'UQ-016.2#'
from tmp_notelepongenggam_default as xa
where xa.scd_end = z_dPeriod
and xa.rownumber_pilih = 1
and xz.customerid_ori = xa.cfcif_2
;

z_cErrMsg = public.serene(1, 'C128');

---- update nomortelepongenggam jadi '' untuk debitur perorangan dan badan usaha, jika tidak ada yang HP ----
update tmp_datamart_customerdetail as xz
set
     nomortelepongenggam = ''
    ,updatequery = xz.updatequery || 'UQ-017#'
from tmp_cfconn_cleansing as xa
where xa.scd_end = z_dPeriod
and xa.cfeadc not in ('HP')
and coalesce(xz.nomortelepongenggam, '') = ''
and xz.customerid_ori = xa.cfcif_2
;

z_cErrMsg = public.serene(1, 'C270');

---- update AlamatEmail dari cfconn_distinct_v yang cfeadc = EM ----
update tmp_datamart_customerdetail as xz
set
     AlamatEmail = xa.cfeadd
    ,updatequery = xz.updatequery || 'UQ-028#'
from tmp_cfconn_distinct_v as xa
where xa.scd_end = z_dPeriod
and xa.cfeadc = 'EM'
and xz.customerid_ori = xa.cfcif_2
;


z_cErrMsg = public.serene(1, 'C290');

---- update Alamat, Kelurahan, Kecamatan, KodePos dari ads. cfaddr_distinct_year_v berdasarkan FlagWNIWNA ----
update tmp_datamart_customerdetail as xz
set
     Alamat = TRIM(TRIM(xa.cfna2) || ' ' || TRIM(xa.cfna3) || ' ' || TRIM(xa.cfna4) || ' ' || TRIM(xa.cfna5))
    ,Kelurahan = xa.cf2kel
    ,Kecamatan = xa.cf2kec
    ,KodePos = xa.cfzip
    ,KodeDATIII = case
                      when xa.cfcddt = 0 then null
                      else public.util_right('0000' || coalesce(xa.cfcddt, 0)::character varying, 4)
                  end
    ,alamat_code = xa.cfinvc
    ,updatequery = xz.updatequery || 'UQ-030#'
from tmp_cfaddr_distinct_v as xa
where xa.scd_end = z_dPeriod
and xz.customerid_ori = xa.cfcif_2
and case
         when xz.flagwniwna = 'WNI' then xa.rowid_wni
         when xz.flagwniwna <> 'WNI' then xa.rowid_wna
    end = 1
;



z_cErrMsg = public.serene(1, 'C480');

--jika kodepos masih kosong, hardocde ke kodepos ONT 12950
update tmp_datamart_customerdetail as xz
set
     kodepos = '12950'
    ,updatequery = xz.updatequery || 'UQ-032#'
where
(
       coalesce(xz.kodepos, '') = ''
    or xz.kodepos = '0'
)
;

z_cErrMsg = public.serene(1, 'C310');

---- update AlamatTempatBekerja dari ads. cfaddr_distinct_year_v berdasarkan cfinvc = W ----
update tmp_datamart_customerdetail as xz
set
     AlamatTempatBekerja = TRIM(TRIM(xa.cfna2) || ' ' || TRIM(xa.cfna3) || ' ' || TRIM(xa.cfna4) || ' ' || TRIM(xa.cfna5))
    ,updatequery = xz.updatequery || 'UQ-033#'
from tmp_cfaddr_distinct_v as xa
where xa.scd_end = z_dPeriod
and xa.cfinvc = 'W'
and xz.customerid_ori = xa.cfcif_2
;

z_cErrMsg = public.serene(1, 'C320');

---- update KodeDATIII, KodeHubungandenganLJK, KodeGolonganDebitur, KodeJenisBadanUsaha dari ads. cfbicd ----
update tmp_datamart_customerdetail as xz
set
     KodeHubungandenganLJK = xa.bihub1::character varying
    ,KodeGolonganDebitur = xa.bipemi
    ,KodeJenisBadanUsaha = xa.bipfix::character varying
    ,kodejenisbadanusaha_desc = xb.hostvalue
    ,updatequery = xz.updatequery || 'UQ-034#'
from tmp_cfbicd as xa
left join probi.regulatory_parameterlist as xb
    on  xb.value2::integer = xa.bipfix
    and xb.mappingcode = 'bentukbadanusaha'
where xa.scd_end = z_dPeriod
and xz.customerid_ori = xa.cfcif_2
;

z_cErrMsg = public.serene(1, 'C320.1');

update tmp_datamart_customerdetail as xz
set
     kodejenisbadanusaha = null::character varying
    ,updatequery = xz.updatequery || 'UQ-034.2#'
where coalesce(xz.kodejenisbadanusaha, '') = '0'
;

-- update kodejenisbadanusaha dari cfmast.cfytib jika masih kosong --
z_cErrMsg = public.serene(1, 'C320.2');

update tmp_datamart_customerdetail as xz
set
     kodejenisbadanusaha = case
                               when COALESCE(TRIM(regexp_replace(xa.cfytib, '[^0-9A-Za-z]', '', 'g')), '')::character varying <> '' then UPPER(COALESCE(TRIM(regexp_replace(xa.cfytib, '[^0-9A-Za-z ]', '', 'g')), ''))::character varying
                               else case
                                        when COALESCE(TRIM(regexp_replace(xa.cfytia, '[^0-9A-Za-z]', '', 'g')), '')::character varying <> '' then UPPER(COALESCE(TRIM(regexp_replace(xa.cfytia, '[^0-9A-Za-z ]', '', 'g')), ''))::character varying
                                        else xz.kodejenisbadanusaha
                                    end
                           end
    ,kodejenisbadanusaha_desc = case
                                    when COALESCE(TRIM(regexp_replace(xa.cfytib, '[^0-9A-Za-z]', '', 'g')), '')::character varying <> '' then UPPER(COALESCE(TRIM(regexp_replace(xa.cfytib, '[^0-9A-Za-z ]', '', 'g')), ''))::character varying
                                    else case
                                             when COALESCE(TRIM(regexp_replace(xa.cfytia, '[^0-9A-Za-z]', '', 'g')), '')::character varying <> '' then UPPER(COALESCE(TRIM(regexp_replace(xa.cfytia, '[^0-9A-Za-z ]', '', 'g')), ''))::character varying
                                             else xz.kodejenisbadanusaha
                                         end
                                end
    ,updatequery = xz.updatequery || 'UQ-034.3#'
from tmp_cfmast as xa
where xa.scd_end = z_dPeriod
and xz.customertype <> 'A'
and coalesce(xz.kodejenisbadanusaha, '') = ''
and xz.customerid_ori = xa.cfcif_2
;

z_cErrMsg = public.serene(1, 'C320.3');

update tmp_datamart_customerdetail as xz
set
     kodejenisbadanusaha = xa.value2
    ,updatequery = xz.updatequery || 'UQ-034.4#'
from probi.regulatory_parameterlist as xa
where xa.mappingcode = 'bentukbadanusaha'
and xa.value2 <> ''
and xz.customertype <> 'A'
and coalesce(xz.kodejenisbadanusaha, '') <> ''
and public.isnumeric(xz.kodejenisbadanusaha) = false
and xz.kodejenisbadanusaha = xa.hostvalue
;

-- di ProCIF nya ada default secara screen hubungandenganpelapor
z_cErrMsg = public.serene(1, 'C321');
update tmp_datamart_customerdetail as xz
set
     KodeHubungandenganLJK = '9900'
where
(
    coalesce(xz.KodeHubungandenganLJK, '') = ''
   or xz.KodeHubungandenganLJK = '0'
)
;


z_cErrMsg = public.serene(1, 'C330');

---- update KodeDATIII dari probi. cfpar2_log ----
update tmp_datamart_customerdetail as xz
set
     KodeDATIII = public.util_right('0000' || COALESCE(COALESCE(xa.cpdtcd::character varying, xz.KodeDATIII), '0')::character varying, 4)
    ,updatequery = xz.updatequery || 'UQ-035#'
from tmp_cfpar2_log as xa
where (
    coalesce (xz.KodeDATIII, '') = ''
    or xz.KodeDATIII = '0000'
)
and xz.KodePos = xa.cp2zip::character varying
;

z_cErrMsg = public.serene(1, 'C321');

---- update KodeDATIII saja dari cfbicd ----
update tmp_datamart_customerdetail as xz
set
     KodeDATIII = public.util_right('0000' || COALESCE(xa.bilok1, 0)::character varying, 4)
    ,updatequery = xz.updatequery || 'UQ-034.1#'
from tmp_cfbicd as xa
where xa.scd_end = z_dPeriod
and
(
       coalesce(xz.KodeDATIII, '') = ''
    or xz.KodeDATIII = '0000'
)
and xz.customerid_ori = xa.cfcif_2
;

z_cErrMsg = public.serene(1, 'C340');

---- update KodeBidangUsaha, KodePekerjaan dari tmp_cfzemp_distinct_v untuk debitur perorangan ----
update tmp_datamart_customerdetail as xz
set
     KodeBidangUsaha = public.util_right('0000' || COALESCE(xa.cfenin, ''), 4) -- SektorEkonomi
    ,KodePekerjaan = COALESCE(xa.cfoccd, '') -- KodeBidangUsaha
    ,updatequery = xz.updatequery || 'UQ-036#'
from tmp_cfzemp_distinct_v as xa
where xa.scd_end = z_dPeriod
and xz.CustomerType = 'A'
and xz.customerid_ori = xa.cfcif_2
;

z_cErrMsg = public.serene(1, 'C350');

---- update KodeBidangUsaha dari ads. cfbicd untuk debitur badan usaha ----
update tmp_datamart_customerdetail as xz
set
     KodeBidangUsaha = public.util_right('0000' || COALESCE(xa.bijdsn, 0)::character varying, 4) -- SektorEkonomi
    ,updatequery = xz.updatequery || 'UQ-037#'
from tmp_cfbicd as xa
where xa.scd_end = z_dPeriod
and xz.CustomerType <> 'A'
and xz.customerid_ori = xa.cfcif_2
;

z_cErrMsg = public.serene(1, 'C360');

---- update TempatBekerja dari tmp_cfzemp_distinct_v ----
update tmp_datamart_customerdetail as xz
set
     TempatBekerja = case
                        when xa.cfena1 like '%TIDAK%' or xa.cfena1 like '%N/A%' then 'NA'
                        else xa.cfena1
                     end
    ,updatequery = xz.updatequery || 'UQ-038#'
from tmp_cfzemp_distinct_v as xa
where xa.scd_end = z_dPeriod
and xz.customerid_ori = xa.cfcif_2
;

z_cErrMsg = public.serene(1, 'C360.1');

-- untuk kodesumberpenghasilan & penghasilankotorpertahun mengikuti cara di prcs_slik_accountcreditprocess dengan tambahan penyesuaian --
update tmp_datamart_customerdetail as xz
set
     kodesumberpenghasilan = xb.slikvalue
    ,updatequery = xz.updatequery || 'UQ-038.1#'
from tmp_datamart_customerdetail as xa
inner join probi.regulatory_parameterlist as xb
    on  xb.mappingcode = 'kodesumberpenghasilan'
    and xb.hostvalue = xa.kodepekerjaan
where xz.customerid_ori = xa.customerid_ori
;

z_cErrMsg = public.serene(1, 'C481');

update tmp_datamart_customerdetail as xz
set
     penghasilankotorpertahun = case
                                    when (coalesce(xa.cfecur * 12, 0) * xb.birateexchange) > 999999999999 then 999999999999
                                    else (coalesce(xa.cfecur * 12, 0) * xb.birateexchange)
                                end
    ,penghasilankotorpertahun_ori_cfzemp = coalesce(xa.cfecur * 12, 0) -- langsung dikali 12 --
    ,currencycode_cfzemp = xa.cfcurr
    ,updatequery = xz.updatequery || 'UQ-038.20#'
-- from ads. cfzemp_distinct_year_v as xa
from tmp_cfzemp_distinct_v as xa
inner join mis.miscurrencyratehistory as xb
    on  xb.load_dt = xa.scd_end
    and xb.currencycode = xa.cfcurr
where xa.scd_end = z_dPeriod
and xz.customerid_ori = xa.cfcif_2
;

z_cErrMsg = public.serene(1, 'C482');

update tmp_datamart_customerdetail as xz
set
     penghasilankotorpertahun = case
                                    when (xa.cfecur * 12) > 999999999999 then 999999999999
                                    else (xa.cfecur * 12)
                                end -- confirm dari Pak Hermawan, jika kurs kosong / tidak sesuai kurs di miscurrencyratehistory maka default jadi IDR --
    ,penghasilankotorpertahun_ori_cfzemp = coalesce(xa.cfecur * 12, 0) -- langsung dikali 12 --
    ,currencycode_cfzemp = xa.cfcurr
    ,updatequery = xz.updatequery || 'UQ-038.30#'
from tmp_cfzemp_distinct_v as xa
where xa.scd_end = z_dPeriod
and xa.cfcurr not in (
    select distinct xa.currencycode
    from mis.miscurrencyratehistory as xa
    where xa.load_dt = z_dPeriod
)
and xz.customerid_ori = xa.cfcif_2
;

z_cErrMsg = public.serene(1, 'C360.2');

insert into tmp_cif_data
(
     cif
    ,cifori
)
select
     case
         when xa.customerid_syariah = '' then xa.customerid_konven
         when xa.customerid_syariah <> '' then xa.customerid_syariah
     end as cif
    ,xa.customerid_ori as cifori
from tmp_datamart_customerdetail as xa
;

z_cErrMsg = public.serene(1, 'C360.3');

insert into tmp_cif_assetdata
(
     cif
    ,cifori
    ,asset
)
select
     xa.cif as cif
    ,xa.cifori as cifori
    ,sum(coalesce(xb.cfyamt, 0) * xc.birateexchange) as asset
from tmp_cif_data as xa
inner join TMP_cfysie as xb
    on  xb.scd_end = z_dPeriod
    and xb.cfyiec = 'W0004'
    and xb.cfcif_2 = xa.cifori
inner join mis.miscurrencyratehistory as xc
    on  xc.load_dt = xb.scd_end
    and xc.currencycode = case
                              when upper(xb.cfycur) not in
                              (
                                    select distinct xa.currencycode
                                    from mis.miscurrencyratehistory as xa
                                    where xa.load_dt = z_dPeriod
                              ) then 'IDR' -- confirm dari Pak Hermawan, jika kurs kosong / tidak sesuai kurs di miscurrencyratehistory maka default jadi IDR --
                              else upper(xb.cfycur)
                          end
group by
     xa.cif
    ,xa.cifori
;

z_cErrMsg = public.serene(1, 'C360.4');

insert into tmp_cif_omsetdata
(
     cif
    ,cifori
    ,omset
)
select
     xa.cif as cif
    ,xa.cifori as cifori
    ,sum(coalesce(xb.cfyamt * 12, 0) * xc.birateexchange) as omset
from tmp_cif_data as xa
inner join TMP_cfysie as xb
    on  xb.scd_end = z_dPeriod
    and xb.cfyiec = 'I2009'
    and xb.cfcif_2 = xa.cifori
inner join mis.miscurrencyratehistory as xc
    on  xc.load_dt = xb.scd_end
    -- and xc.currencycode = xb.cfycur
    and xc.currencycode = case
                              when upper(xb.cfycur) not in
                              (
                                    select distinct xa.currencycode
                                    from mis.miscurrencyratehistory as xa
                                    where xa.load_dt = z_dPeriod
                              ) then 'IDR' -- confirm dari Pak Hermawan, jika kurs kosong / tidak sesuai kurs di miscurrencyratehistory maka default jadi IDR --
                              else upper(xb.cfycur)
                          end
group by
     xa.cif
    ,xa.cifori
;

z_cErrMsg = public.serene(1, 'C361');

insert into tmp_cif_assetdata
(
     cif
    ,cifori
    ,asset
)
select
     xb.cif
    ,xb.cifori
    ,xa.total_asset as asset
from tmp_lms_workflow_log_history_AssetOmset as xa
inner join tmp_cif_data as xb
    on xb.cifori = xa.cst_cif
left join tmp_cif_assetdata as xc
    on xc.cifori = xa.cst_cif
where xc.cifori is null
;

z_cErrMsg = public.serene(1, 'C362');
insert into tmp_cif_omsetdata
(
     cif
    ,cifori
    ,omset
)
select
     xb.cif
    ,xb.cifori
    ,xa.app_omset as omsets
from tmp_lms_workflow_log_history_AssetOmset as xa
inner join tmp_cif_data as xb
    on xb.cifori = xa.cst_cif
left join tmp_cif_omsetdata as xc
    on xc.cifori = xa.cst_cif
where xc.cifori is null
;

z_cErrMsg = public.serene(1, 'C362.1');
insert into tmp_omsetaset_ultron
(
     cif_no      ,app_omset   ,total_asset ,rownumber
)
select
     xa.cif_no as cif_no
    ,xa.app_omset as app_omset
    ,xa.total_asset as total_asset
    ,ROW_NUMBER() OVER (partition by xa.cif_no order by  (xa.loan_open_date::date) desc, xa.app_omset desc , xa.total_asset desc) as rownumber
from ads.lmsultron_summary_lms_woco as xa
where xa.hkeep_dt = z_dPeriod
;

delete from tmp_omsetaset_ultron as xa
where xa.rownumber <> 1
;

z_cErrMsg = public.serene(1, 'C362.2');
insert into tmp_cif_assetdata
(
     cif
    ,cifori
    ,asset
)
select
     xb.cif
    ,xb.cifori
    ,xa.total_asset as asset
from tmp_omsetaset_ultron as xa
inner join tmp_cif_data as xb
    on xb.cifori = xa.cif_no
left join tmp_cif_assetdata as xc
    on xc.cifori = xa.cif_no
where xc.cifori is null
;

z_cErrMsg = public.serene(1, 'C362');
insert into tmp_cif_omsetdata
(
     cif
    ,cifori
    ,omset
)
select
     xb.cif
    ,xb.cifori
    ,xa.app_omset as omsets
from tmp_omsetaset_ultron as xa
inner join tmp_cif_data as xb
    on xb.cifori = xa.cif_no
left join tmp_cif_omsetdata as xc
    on xc.cifori = xa.cif_no
where xc.cifori is null
;

z_cErrMsg = public.serene(1, 'C360.5');

insert into tmp_cif_gajidata
(
     cif
    ,cifori
    ,gaji
)
select
     xa.cif as cif
    ,xa.cifori as cifori
    ,sum(coalesce(xb.cfyamt * 12, 0) * xc.birateexchange) as gaji
from tmp_cif_data as xa
inner join TMP_cfysie as xb
    on  xb.scd_end = z_dPeriod
    and xb.cfyiec = 'I1001'
    and xb.cfcif_2 = xa.cifori
inner join mis.miscurrencyratehistory as xc
    on  xc.load_dt = xb.scd_end
    -- and xc.currencycode = xb.cfycur
    and xc.currencycode = case
                              when upper(xb.cfycur) not in
                              (
                                    select distinct xa.currencycode
                                    from mis.miscurrencyratehistory as xa
                                    where xa.load_dt = z_dPeriod
                              ) then 'IDR' -- confirm dari Pak Hermawan, jika kurs kosong / tidak sesuai kurs di miscurrencyratehistory maka default jadi IDR --
                              else upper(xb.cfycur)
                          end
group by
     xa.cif
    ,xa.cifori
;

z_cErrMsg = public.serene(1, 'C360.6');

insert into tmp_cif_gajipasangandata
(
     cif
    ,cifori
    ,gajipasangan
)
select
     xa.cif as cif
    ,xa.cifori as cifori
    ,sum(coalesce(xb.cfyamt * 12, 0) * xc.birateexchange) as gajipasangan
from tmp_cif_data as xa
inner join TMP_cfysie as xb
    on  xb.scd_end = z_dPeriod
    and xb.cfyiec = 'I2001'
    and xb.cfcif_2 = xa.cifori
inner join mis.miscurrencyratehistory as xc
    on  xc.load_dt = xb.scd_end
    -- and xc.currencycode = xb.cfycur
    and xc.currencycode = case
                              when upper(xb.cfycur) not in
                              (
                                    select distinct xa.currencycode
                                    from mis.miscurrencyratehistory as xa
                                    where xa.load_dt = z_dPeriod
                              ) then 'IDR' -- confirm dari Pak Hermawan, jika kurs kosong / tidak sesuai kurs di miscurrencyratehistory maka default jadi IDR --
                              else upper(xb.cfycur)
                          end
group by
     xa.cif
    ,xa.cifori
;

z_cErrMsg = public.serene(1, 'C360.7');

insert into tmp_cif_lainnyadata
(
     cif
    ,cifori
    ,kode
    ,lainnya
    ,rowid
)
select
     xa.cif as cif
    ,xa.cifori as cifori
    ,xb.cfyiec as kode
    ,sum(coalesce(xb.cfyamt, 0) * xc.birateexchange) as lainnya
    ,ROW_NUMBER() OVER (partition by xa.cifori order by xb.cfyiec asc) as rowid
from tmp_cif_data as xa
inner join TMP_cfysie as xb
    on  xb.scd_end = z_dPeriod
    and xb.cfyiec not in
    (
         'I1001' -- Pendapatan Utama / Gaji
        ,'I2001' -- Gaji Pasangan (Suami/Istri)
        ,'I2009' -- Omzet Usaha
        ,'W0004' -- Asset Bersih
    )
    and xb.cfcif_2 = xa.cifori
inner join mis.miscurrencyratehistory as xc
    on  xc.load_dt = xb.scd_end
    -- and xc.currencycode = xb.cfycur
    and xc.currencycode = case
                              when upper(xb.cfycur) not in
                              (
                                    select distinct xa.currencycode
                                    from mis.miscurrencyratehistory as xa
                                    where xa.load_dt = z_dPeriod
                              ) then 'IDR' -- confirm dari Pak Hermawan, jika kurs kosong / tidak sesuai kurs di miscurrencyratehistory maka default jadi IDR --
                              else upper(xb.cfycur)
                          end
inner join ads.cfypic as xd
    on  xd.cypiet <> 'E' -- yang pengeluaran di exclude --
    and xd.cypiec = xb.cfyiec
group by
     xa.cif
    ,xa.cifori
    ,xb.cfyiec
;

z_cErrMsg = public.serene(1, 'C360.8');

update tmp_cif_data as xz
set
     asset = xa.asset
from tmp_cif_assetdata as xa
where xz.cifori = xa.cifori
;

z_cErrMsg = public.serene(1, 'C360.9');

update tmp_cif_data as xz
set
     omset = xa.omset
from tmp_cif_omsetdata as xa
where xz.cifori = xa.cifori
;

z_cErrMsg = public.serene(1, 'C360.10');

update tmp_cif_data as xz
set
     gaji = xa.gaji
from tmp_cif_gajidata as xa
where xz.cifori = xa.cifori
;

z_cErrMsg = public.serene(1, 'C360.11');

update tmp_cif_data as xz
set
     gajipasangan = xa.gajipasangan
from tmp_cif_gajipasangandata as xa
where xz.cifori = xa.cifori
;

z_cErrMsg = public.serene(1, 'C360.12');

update tmp_cif_data as xz
set
     lainnya = xa.lainnya
from tmp_cif_lainnyadata as xa
where xa.rowid = 1
and xz.cifori = xa.cifori
;

z_cErrMsg = public.serene(1, 'C360.13');

update tmp_cif_data as xz
set
     individualbit = 1
from TMP_cfmast as xa
where xa.cfclas = 'A'
and xz.cifori = xa.cfcif_2
;

z_cErrMsg = public.serene(1, 'C360.14');

-- update tmp_datamart_customerdetail as xz
-- set
     -- penghasilankotorpertahun = case
                                    -- when xz.kodesumberpenghasilan = '1' then case
                                                                                -- when coalesce(xa.gaji, 0) <> 0 then case
                                                                                                                        -- when xa.gaji > 999999999999 then 999999999999
                                                                                                                        -- else xa.gaji
                                                                                                                    -- end
                                                                                -- when coalesce(xa.gaji, 0) = 0 then case
                                                                                                                        -- when xa.gajipasangan > 999999999999 then 999999999999
                                                                                                                        -- else xa.gajipasangan
                                                                                                                    -- end
                                                                            -- end
                                    -- when xz.kodesumberpenghasilan = '2' then case
                                                                                -- when xa.omset > 999999999999 then 999999999999
                                                                                -- else xa.omset
                                                                            -- end
                                    -- when xz.kodesumberpenghasilan = '3' then case
-- --                                                                                 when coalesce(xa.asset, 0) <> 0 then case
-- --                                                                                                                         when xa.asset > 999999999999 then 999999999999
-- --                                                                                                                         else xa.asset
-- --                                                                                                                     end
-- --                                                                                 when coalesce(xa.asset, 0) = 0 then case
-- --                                                                                                                         when xa.lainnya > 999999999999 then 999999999999
-- --                                                                                                                         else xa.lainnya
-- --                                                                                                                     end
-- -- Aset dan lainnya di take out dari pengambilan penghasilan
                                                                                 -- when coalesce(xa.gajipasangan, 0) <> 0 then case
                                                                                                                                 -- when xa.gajipasangan > 999999999999 then 999999999999
                                                                                                                                 -- else xa.gajipasangan
                                                                                                                             -- end
                                                                                 -- when coalesce(xa.gaji, 0) <> 0 then case
                                                                                                                                 -- when xa.gaji > 999999999999 then 999999999999
                                                                                                                                 -- else xa.gaji
                                                                                                                             -- end
                                                                                 -- when coalesce(xa.omset, 0) <> 0 then case
                                                                                                                                 -- when xa.omset > 999999999999 then 999999999999
                                                                                                                                 -- else xa.omset
                                                                                                                             -- end
--1. dari cfzemp amount > 6 digit
--2. dari cfysie amount > 6 digit
--3. dari cfzemp tidak cek digit amount
--4. dari cfysie tidak cek digit amount

update tmp_datamart_customerdetail as xz
set
     penghasilankotorpertahun = case
                                    when length(coalesce(xa.gaji::numeric(30,0), 0.0)::character varying) > 6 then case
                                                                                                    when xa.gaji > 999999999999 then 999999999999
                                                                                                    else xa.gaji
                                                                                                end
                                    when length(coalesce(xa.gajipasangan::numeric(30,0), 0.0)::character varying) > 6 then case
                                                                                                            when xa.gajipasangan > 999999999999 then 999999999999
                                                                                                            else xa.gajipasangan
                                                                                                        end
                                    when length(coalesce(xa.omset::numeric(30,0), 0.0)::character varying) > 6 then case
                                                                                                     when xa.omset > 999999999999 then 999999999999
                                                                                                     else xa.omset
                                                                                                 end
                                    else xz.penghasilankotorpertahun
                                end
    ,kodesumberpenghasilan = case
                                 when length(coalesce(xa.gaji::numeric(30,0), 0.0)::character varying) > 6 then '1'
                                 when length(coalesce(xa.gajipasangan::numeric(30,0), 0.0)::character varying) > 6 then '1'
                                 when length(coalesce(xa.omset::numeric(30,0), 0.0)::character varying) > 6 then '2'
                                 else xz.kodesumberpenghasilan
                             end
    ,updatequery = xz.updatequery || 'UQ-038.2#'
from tmp_cif_data as xa
where xz.customerid_ori = xa.cifori
-- and length(coalesce(xz.penghasilankotorpertahun::numeric(30,0), 0.0)) <= 6 -- tambahan enhance hasil diskusi dengan Pak Hermawan --
and length(coalesce(xz.penghasilankotorpertahun::numeric(30,0), 0.0)::character varying) <= 6 -- tambahan enhance hasil diskusi dengan Pak Hermawan --
;

z_cErrMsg = public.serene(1, 'C360.15');

update tmp_datamart_customerdetail as xz
set
     penghasilankotorpertahun = case
                                    when coalesce(xa.gaji, 0.0) <> 0.0 then case
                                                                                when xa.gaji > 999999999999 then 999999999999
                                                                                else xa.gaji
                                                                            end
                                    when coalesce(xa.gajipasangan, 0.0) <> 0.0 then case
                                                                                        when xa.gajipasangan > 999999999999 then 999999999999
                                                                                        else xa.gajipasangan
                                                                                    end
                                    when coalesce(xa.omset, 0.0) <> 0.0 then case
                                                                                 when xa.omset > 999999999999 then 999999999999
                                                                                 else xa.omset
                                                                             end
                                end
    ,kodesumberpenghasilan = case
                                 when coalesce(xa.gaji, 0.0) <> 0.0 then '1'
                                 when coalesce(xa.gajipasangan, 0.0) <> 0.0 then '1'
                                 when coalesce(xa.omset, 0.0) <> 0.0 then '2'
                             end
    ,updatequery = xz.updatequery || 'UQ-038.3#'
from tmp_cif_data as xa
where xz.customerid_ori = xa.cifori
and coalesce(xz.penghasilankotorpertahun, 0.0) = 0.0
;


z_cErrMsg = public.serene(1, 'C370');

---- update MelanggarBM, MelampauiBM ----
update tmp_datamart_customerdetail as xz
set
     MelanggarBM = 'T'
    ,MelampauiBM = 'T'
    ,updatequery = xz.updatequery || 'UQ-039#'
;

z_cErrMsg = public.serene(1, 'C380');

---- update untuk rekening HC dari ads. ps_n_debtur_org_slik_vw untuk yang Syariah ----
update tmp_datamart_customerdetail as xz
set
     IDType = case
                  when COALESCE(xb.national_id_type, '') = '' then xz.IDType
                  else xb.national_id_type
              end
    ,IdNumber = case
                    when COALESCE(xb.NATIONAL_ID, '') = '' then xz.IdNumber
                    else xb.NATIONAL_ID
                end
    ,CustomerName = case
                        when COALESCE(xb.NAME, '') = '' then xz.CustomerName
                        else xb.NAME
                    end
    ,NamaLengkap = case
                       when COALESCE(xb.NAME, '') = '' then xz.NamaLengkap
                       else xb.NAME
                   end
    ,KodeStatusGelarDebitur = case
                                  when COALESCE(xb.EDUCATION_LVL_ACHV, '') = '' then xz.KodeStatusGelarDebitur
                                  else xb.EDUCATION_LVL_ACHV
                              end
    ,JenisKelamin = case
                        when COALESCE(xb.SEX, '') = '' then xz.JenisKelamin
                        else xb.SEX
                    end
    ,TempatLahirKTP = case
                          when COALESCE(xb.BIRTHPLACE, '') = '' then xz.TempatLahirKTP
                          else xb.BIRTHPLACE
                      end
    ,TanggalLahir = case
                        when COALESCE(xb.BIRTHDATE::date, '19000101'::date) = '19000101'::date then xz.TanggalLahir
                        else xb.BIRTHDATE::date
                    end
    ,NPWP = case
                when COALESCE(xb.IDN_TAX_EE_ID, '') = '' then  xz.NPWP
                else xb.IDN_TAX_EE_ID
            end
    ,Alamat = case
                  when COALESCE(xb.ADDRESSLONG, '') = '' then xz.Alamat
                  else xb.ADDRESSLONG
              end
    ,Kelurahan = case
                     when COALESCE(xb.ADDRESS3, '') = '' then xz.Kelurahan
                     else xb.ADDRESS3
                 end
    ,Kecamatan = case
                     when COALESCE(xb.ADDRESS4, '') = '' then xz.Kecamatan
                     else xb.ADDRESS4
                 end
    ,KodePos = case
                   when COALESCE(xb.POSTAL, '') = '' then xz.KodePos
                   else xb.POSTAL
               end
    ,Telepon = case
                   when coalesce(xb.PHONE,'') = '' then case
                                                            when coalesce(xz.Telepon,'') = '' then '0'
                                                            else xz.Telepon
                                                        end
                   else xb.PHONE
               end
    ,NomorTeleponGenggam = case
                               when coalesce(xb.PHONE1,'') = '' then case
                                                                         when coalesce(xz.NomorTeleponGenggam,'') = '' then '0'
                                                                         else xz.NomorTeleponGenggam
                                                                     end
                               else xb.PHONE1
                           end
    ,AlamatEmail = case
                       when COALESCE(xb.EMAIL_ADDR, '') = '' then xz.AlamatEmail
                       else xb.EMAIL_ADDR
                   end
    ,KodeNegara = 'ID'
    ,KodePekerjaan = '099'
    ,TempatBekerja = case
                         when COALESCE(xb.DESCR, '') = '' then xz.TempatBekerja
                         else xb.DESCR
                     end
    ,KodeBidangUsaha = '641000'
    ,AlamatTempatBekerja = case
                               when COALESCE(xb.ADDRESSLONG10, '') =  '' then xz.AlamatTempatBekerja
                               else xb.ADDRESSLONG10
                           end
    ,PenghasilanKotorPerTahun = case
                                    when COALESCE(xb.ANNUAL_RT, 0) = 0 then xz.PenghasilanKotorPerTahun
                                    else xb.ANNUAL_RT
                                end
    ,KodeSumberPenghasilan = '1'
--     ,KodeHubungandenganLJK = '9900'
    ,KodeGolonganDebitur = '9000'
    ,StatusPerkawinanDebitur = case
                                   when COALESCE(xb.MAR_STATUS, '') = '' then xz.StatusPerkawinanDebitur
                                   else xb.MAR_STATUS
                               end
    ,MelanggarBM = 'T'
    ,MelampauiBM = 'T'
    ,NamaGadisIbuKandung = case
                               when COALESCE(xb.NAME2, '') = '' then xz.NamaGadisIbuKandung
                               else xb.NAME2
                           end
    ,Source = 'ps'
    ,jumlahtanggungan = public.util_right(coalesce(xb.idn_tax_status, '0'), 1)::integer
    ,nikpassportpasangan = coalesce(xb.NATIONAL_ID2, '')
    ,namapasangan = coalesce(xb.Name3, '')
    ,tanggallahirpasangan = coalesce(xb.DATE3, '19000101'::date)
    ,perjanjianpisahharta = coalesce(xb.N_C_PISAH_HARTA, '')
    ,updatequery = xz.updatequery || 'UQ-040#'
from TMP_ps_n_debtur_org_slik_vw as xb
where xb.load_dt = z_dPeriodHC
and xz.customerid_ori = xb.c_cif_nbr
;

z_cErrMsg = public.serene(1, 'C390');

-- untuk cif yang ada di CFMAST statusnya konven, jika ada yang office nya syariah, update ke phisicalbranch
update tmp_datamart_customerdetail as xz
set
     officecustomer = xb.physicalbranch
    ,updatequery = xz.updatequery || 'UQ-041#'
from tmp_cfmast as xa
inner join mis.misofficeinformation as xb
    on  xb.scd_end = xa.scd_end
    and coalesce(xb.physicalbranch, '') <> ''
    and coalesce(xb.physicalbranch, '') <> '0' -- jangan ambil yang 0 juga --
    and xb.office_id = xa.cfbrnn
where xa.scd_end = z_dPeriod
and length(xz.officecustomer) = 5
and xz.officecustomer like '7%'
and xz.customerid_ori = xa.cfcif_2
;

z_cErrMsg = public.serene(1, 'C400');

---cek ada cif yang duplicate dan customertype nya null
update tmp_datamart_customerdetail as xz
set
     lastchangeduser = xa.cfvusr
    ,updatequery = xz.updatequery || 'UQ-042#'
from tmp_cfmast as xa
where xa.scd_end = z_dPeriod
and xz.customerid_ori = xa.cfcif_2
;

z_cErrMsg = public.serene(1, 'C410');

update tmp_datamart_customerdetail as xz
set
     GoPublic = COALESCE(TRIM(xa.cfgobli), '')
    ,NamaGroupDebitur = COALESCE(TRIM(xa.cfgrdeb), '')
    ,updatequery = xz.updatequery || 'UQ-043#'
from ads.cfbicde as xa
where xa.hkeep_dt = z_dPeriod
and xz.customerid_ori = xa.cfcif_2
;

z_cErrMsg = public.serene(1, 'C420');

update tmp_datamart_customerdetail as xz
set
     idgroupdebitur = xa.cpgcde
    ,namagroupdebitur = xb.cpgdes
    ,updatequery = xz.updatequery || 'UQ-044#'
-- from ads. cfgmbr as xa
from ads.cfgmbr_distinct_v as xa
inner join probi.cfparu_log as xb
    on  xb.hkeep_dt = xa.scd_end
    and xb.cpgcde = xa.cpgcde
where xa.scd_end = z_dPeriod
and xb.cpgcde not in
(
     '0'
    ,'999'
    ,'111' -- debitur Non-UMKM yg asset/omzetnya masuk kriteria UMKM namun groupnya diluar ON
)
and xz.customerid_ori = xa.cfcif_2
;

z_cErrMsg = public.serene(1, 'C430');

update tmp_datamart_customerdetail as xz
set
     NoAktePendirian = xa.cfssno
    -- ,NoAktePerubahanTerakhir = xa.cfssno
    ,tanggalaktependirian = coalesce(xa.cfisd7, '19000101'::date)
    ,updatequery = xz.updatequery || 'UQ-045#'
from tmp_cfmast as xa
where xa.scd_end = z_dPeriod
and xa.cfsscd = 'APP'
and xz.customerid_ori = xa.cfcif_2
;

z_cErrMsg = public.serene(1, 'C440');

-- update NoAktePendirian dari ads. cfaidn_distinct_year_v yang cfsscd = APP dan masih kosong
update tmp_datamart_customerdetail as xz
set
     NoAktePendirian = xa.cfssno
    -- ,NoAktePerubahanTerakhir = xa.cfssno
    ,tanggalaktependirian = coalesce(xa.cfisd7, '19000101'::date)
    ,updatequery = xz.updatequery || 'UQ-046#'
from tmp_cfaidn_distinct_v as xa
where xa.scd_end = z_dPeriod
and xa.cfsscd = 'APP'
and coalesce(xz.NoAktePendirian, '') = ''
and xz.customerid_ori = xa.cfcif_2
;

z_cErrMsg = public.serene(1, 'C441');

update tmp_datamart_customerdetail as xz
set
     NoAktePerubahanTerakhir = xa.cfssno
    ,tanggalakteperubahanterakhir = coalesce(xa.cfisd7, '19000101'::date)
    ,updatequery = xz.updatequery || 'UQ-045.1#'
from tmp_cfmast as xa
where xa.scd_end = z_dPeriod
and xa.cfsscd = 'APT'
and xz.customerid_ori = xa.cfcif_2
;

z_cErrMsg = public.serene(1, 'C442');

-- update NoAktePendirian dari ads. cfaidn_distinct_year_v yang cfsscd = APP dan masih kosong
update tmp_datamart_customerdetail as xz
set
     NoAktePerubahanTerakhir = xa.cfssno
    ,tanggalakteperubahanterakhir = coalesce(xa.cfisd7, '19000101'::date)
    ,updatequery = xz.updatequery || 'UQ-046.1#'
from tmp_cfaidn_distinct_v as xa
where xa.scd_end = z_dPeriod
and xa.cfsscd = 'APT'
and coalesce(xz.NoAktePerubahanTerakhir, '') = ''
and xz.customerid_ori = xa.cfcif_2
;

z_cErrMsg = public.serene(1, 'C450');

update tmp_datamart_customerdetail as xz
set
     bibankid = xa.bi_bank_id
    ,kodekantorcabang = public.util_right(COALESCE(xa.bi_bank_id::character varying, ''), 3)
    ,updatequery = xz.updatequery || 'UQ-047#'
from ads.office_information_v as xa
where xa.scd_end = z_dPeriod
and xz.officecustomer = xa.office_id_sibs
;

z_cErrMsg = public.serene(1, 'C555');
-- jika bibankid nya udah syariah, update ke konven, supaya bibankid_syariah terisi yang syariah --
update tmp_datamart_customerdetail as xz
set
     bibankid = xa.antasenavalue::integer
    ,updatequery = xz.updatequery || 'UQ-047.1#'
from tmp_regulatory_mapping_tr as xa
where xa.mappingcode = 'cabangsyariah'
and xa.addmappingcode1 = 'konven'
and xa.isactive = 'A'
and xz.bibankid::character varying ilike '289__'
and xz.kodekantorcabang = xa.hostvalue
;

z_cErrMsg = public.serene(1, 'C500');

--update untuk mapping bi_bank_id syariah disamakan dengan mapping SLIK
update tmp_datamart_customerdetail as xz
set
     bibankid_syariah = xa.antasenavalue::integer
    ,updatequery = xz.updatequery || 'UQ-048#'
from tmp_regulatory_mapping_tr as xa
where xa.mappingcode = 'cabangsyariah'
and xa.addmappingcode1 = 'syariah'
and xa.isactive = 'A'
and coalesce(xz.customerid_syariah, '') <> '' --> ambil yang ada di cfsyrmp
and xz.kodekantorcabang = xa.hostvalue
;

z_cErrMsg = public.serene(1, 'C470');

update tmp_datamart_customerdetail as xz
set
     bibankid_syariah = xz.bibankid
    ,updatequery = xz.updatequery || 'UQ-049#'
where coalesce(xz.customerid_syariah, '') <> '' --> ambil yang ada di cfsyrmp
and coalesce(xz.bibankid_syariah, 0) = 0
;

z_cErrMsg = public.serene(1, 'C556');
-- jika bibankid_syariah nya masih konven, update ke syariah --
update tmp_datamart_customerdetail as xz
set
     bibankid_syariah = xa.antasenavalue::integer
    ,updatequery = xz.updatequery || 'UQ-049.1#'
from tmp_regulatory_mapping_tr as xa
where xa.mappingcode = 'cabangsyariah'
and xa.addmappingcode1 = 'syariah'
and xa.isactive = 'A'
and coalesce(xz.customerid_syariah, '') <> '' --> ambil yang ada di cfsyrmp
and public.util_right(COALESCE(xz.bibankid_syariah::character varying, ''), 3) = xa.hostvalue
;

z_cErrMsg = public.serene(1, 'C480');

update tmp_datamart_customerdetail as xz
set
     idnumber = replace(xz.idnumber, ' ', '')
    ,updatequery = xz.updatequery || 'UQ-050#'
where coalesce(xz.idnumber, '') <> ''
;

z_cErrMsg = public.serene(1, 'C510');

update tmp_datamart_customerdetail as xz
set
     npwp = replace(xz.npwp, ' ', '')
    ,updatequery = xz.updatequery || 'UQ-051#'
where coalesce(xz.npwp, '') <> ''
;

z_cErrMsg = public.serene(1, 'C520');

update tmp_datamart_customerdetail as xz
set
     nikpassportpasangan = coalesce(xa.cfssno, '')
    ,namapasangan = coalesce(xa.cfsnme, '')
    ,tanggallahirpasangan = coalesce(xa.cfbird, '19000101'::date)
    ,perjanjianpisahharta = case
                                when coalesce(xa.cfapph, '') = 'N' then 'T'
                                else coalesce(xa.cfapph, '')
                            end
    ,updatequery = xz.updatequery || 'UQ-052#'
from ads.cffince as xa
where xa.hkeep_dt = z_dPeriod
and coalesce(xz.statusperkawinandebitur, '') in
(
     '1' -- menikah
    ,'A' -- menikah
)
and xz.customerid_ori = xa.cfcif_2
;

z_cErrMsg = public.serene(1, 'C521');

-- update jika data EOM masih kosong, update data EOD (untuk jika case rerun)
update tmp_datamart_customerdetail as xz
set
     nikpassportpasangan = coalesce(xa.cfssno, '')
    ,namapasangan = coalesce(xa.cfsnme, '')
    ,tanggallahirpasangan = coalesce(xa.cfbird, '19000101'::date)
    ,perjanjianpisahharta = case
                                when coalesce(xa.cfapph, '') = 'N' then 'T'
                                else coalesce(xa.cfapph, '')
                            end
    ,updatequery = xz.updatequery || 'UQ-052.2#'
from ads.cffince as xa
where xa.hkeep_dt = z_dCurrEOD
and coalesce(xz.namapasangan, '') = ''
and coalesce(xz.statusperkawinandebitur, '') in
(
     '1' -- menikah
    ,'A' -- menikah
)
and xz.customerid_ori = xa.cfcif_2
;

z_cErrMsg = public.serene(1, 'C522');

update tmp_datamart_customerdetail as xz
set
     namapasangan = ''
    ,nikpassportpasangan = ''
    ,tanggallahirpasangan = null::date
    ,perjanjianpisahharta = ''
    ,updatequery = xz.updatequery || 'UQ-052.3#'
where coalesce(xz.statusperkawinandebitur, '') in
(
     'C' -- Cerai
    ,'3' -- Cerai
)
and coalesce(xz.namapasangan, '') <> ''
;

z_cErrMsg = public.serene(1, 'C530');

insert into tmp_jumlahtanggungan
(
     cifori
    ,jumlahtanggungan
)
select distinct
     xa.customerid_ori as cifori
    ,count(xb.cfydty) as jumlahtanggungan
from tmp_datamart_customerdetail as xa
inner join ads.cfydpn as xb
    on  xb.scd_end = z_dPeriod
    and xb.cfcif_2 = xa.customerid_ori
group by
     xa.customerid_ori
;

z_cErrMsg = public.serene(1, 'C540');

update tmp_datamart_customerdetail as xz
set
     jumlahtanggungan = case
                            when xa.jumlahtanggungan = 0 then null
                            else xa.jumlahtanggungan
                        end
    ,updatequery = xz.updatequery || 'UQ-053#'
from tmp_jumlahtanggungan as xa
where coalesce(xz.jumlahtanggungan, 0) = 0
and coalesce(xz.source, '') <> 'ps'
and xz.customerid_ori = xa.cifori
;



z_cErrMsg = public.serene(1, 'C575');

update tmp_datamart_customerdetail as xz
set
     NoAktePerubahanTerakhir = xz.NoAktePendirian
    ,tanggalakteperubahanterakhir = xz.tanggalaktependirian
    ,updatequery = xz.updatequery || 'UQ-056.5#'
where xz.customertype <> 'A'
and coalesce(xz.NoAktePerubahanTerakhir, '') = ''
and coalesce(xz.tanggalakteperubahanterakhir, '19000101'::date) = '19000101'::date
;


z_cErrMsg = public.serene(1, 'C576');

update tmp_datamart_customerdetail as xz
set
     NoAktePendirian = xz.NoAktePerubahanTerakhir
    ,tanggalaktependirian = xz.tanggalakteperubahanterakhir
    ,updatequery = xz.updatequery || 'UQ-056.6#'
where xz.customertype <> 'A'
and coalesce(xz.NoAktePendirian, '') = ''
and coalesce(xz.tanggalaktependirian, '19000101'::date) = '19000101'::date
;


z_cErrMsg = public.serene(1, 'C590');

update tmp_datamart_customerdetail as xz
set
     idgroupdebitur = xc.groupid
    ,namagroupdebitur = xc.groupname
    ,updatequery = xz.updatequery || 'UQ-058#'
from ads.clsgroupdebtor_tr as xa
inner join ads.clsdebtor_tm as xb
    on  xb.hkeep_dt = xa.load_dt
    and xb.cfcif = xa.cfcif::character varying
inner join ads.clsgroup_tm as xc
    on  xc.groupid = xa.groupid
where xa.load_dt = z_dPeriod
and xa.groupid not in
(
     0
    ,999
    ,111 -- debitur Non-UMKM yg asset/omzetnya masuk kriteria UMKM namun groupnya diluar ON
)
and coalesce(xz.idgroupdebitur, 0) = 0
and coalesce(xz.namagroupdebitur, '') = ''
and xz.customerid_ori = xa.cfcif::character varying
;

z_cErrMsg = public.serene(1, 'C600');

update tmp_datamart_customerdetail as xz
set
     nikpassportpasangan = ''
    ,namapasangan = ''
    ,tanggallahirpasangan = '19000101'::date
    ,perjanjianpisahharta = ''
    ,statusperkawinandebitur = '2'
    ,updatequery = xz.updatequery || 'UQ-059#'
where xz.statusperkawinandebitur in ('', '2', 'B')
;

z_cErrMsg = public.serene(1, 'C610');

update tmp_datamart_customerdetail as xz
set
     tanggallahirpasangan = coalesce(xz.tanggallahirpasangan, '19000101'::date)
    ,perjanjianpisahharta = case
                                when coalesce(xz.tanggallahirpasangan, '19000101'::date) = '19000101'::date then 'T'
                                else xz.perjanjianpisahharta
                            end
    ,statusperkawinandebitur = '3'
    ,updatequery = xz.updatequery || 'UQ-060#'
where xz.statusperkawinandebitur in ('3', 'C')
;

z_cErrMsg = public.serene(1, 'C613');
--update jumlahtanggungan dari table ptbc
update tmp_datamart_customerdetail as xz
set
     jumlahtanggungan = xa.jumlahtanggungan::integer
    ,updatequery = xz.updatequery || 'UQ-063#'
from probi.manparam_ptbc_cif_parameter as xa
where xz.customerid_ori = xa.cif
and coalesce(xz.jumlahtanggungan::character varying, '0') = '0'
;


z_cErrMsg = public.serene(1, 'C615');
--update data pasangan dari table ptbc
update tmp_datamart_customerdetail as xz
set
     nikpassportpasangan = coalesce(xa.idpasangan, '')
    ,namapasangan = coalesce(xa.namapasangan, '')
    ,tanggallahirpasangan = coalesce(xa.tgllahirpasangan, '19000101')::date
    ,updatequery = xz.updatequery || 'UQ-065#'
from probi.manparam_ptbc_cif_parameter as xa
where xz.customerid_ori = xa.cif
and coalesce(xz.statusperkawinandebitur, '') in
(
     '1' -- menikah
    ,'A' -- menikah
)
and(
       coalesce(xz.nikpassportpasangan, '') = ''
    or coalesce(xz.namapasangan, '') = ''
    or coalesce(xz.tanggallahirpasangan, '19000101'::date) = '19000101'
)
;

z_cErrMsg = public.serene(1, 'C630');

---- standarisasi kolom nama menjadi huruf kapital ----
update tmp_datamart_customerdetail as xz
set
     CustomerName_ORI = xz.CustomerName
    ,NamaGadisIbuKandung_ORI = xz.NamaGadisIbuKandung
    ,NamaLengkap = UPPER(xz.NamaLengkap)
    ,CustomerName = UPPER(xz.CustomerName)
    ,NamaGadisIbuKandung = UPPER(xz.NamaGadisIbuKandung)
    ,NamaGroupDebitur = UPPER(xz.NamaGroupDebitur)
    ,NamaPasangan = UPPER(xz.NamaPasangan)
    ,UpdateQuery = xz.UpdateQuery || 'UQ-070#'
;

z_cErrMsg = public.serene(1, 'C640');

---- replace angka nol menjadi O untuk nasabah perorangan ----
update tmp_datamart_customerdetail as xz
set
     NamaLengkap = case
                       when xz.CustomerType = 'A' then REPLACE(xz.NamaLengkap, '0', 'O') -- A = perorangan --
                       else xz.NamaLengkap
                   end
    ,CustomerName = case
                        when xz.CustomerType = 'A' then REPLACE(xz.CustomerName, '0', 'O') -- A = perorangan --
                        else xz.CustomerName
                    end
    ,NamaGadisIbuKandung = REPLACE(xz.NamaGadisIbuKandung, '0', 'O')
    ,NamaPasangan = REPLACE(xz.NamaPasangan, '0', 'O')
    ,UpdateQuery = xz.UpdateQuery || 'UQ-012#'
;

z_cErrMsg = public.serene(1, 'C650');

---- replace ampersand menjadi AND ----
update tmp_datamart_customerdetail as xz
set
     NamaLengkap = REPLACE(xz.NamaLengkap, '&', ' AND ')
    ,CustomerName = REPLACE(xz.CustomerName, '&', ' AND ')
    ,NamaGadisIbuKandung = REPLACE(xz.NamaGadisIbuKandung, '&', ' AND ')
    ,NamaGroupDebitur = REPLACE(xz.NamaGroupDebitur, '&', ' AND ')
    ,NamaPasangan = REPLACE(xz.NamaPasangan, '&', ' AND ')
    ,UpdateQuery = xz.UpdateQuery || 'UQ-080#'
;

z_cErrMsg = public.serene(1, 'C660');

---- cleansing karakter non-alphanumeric ----
update tmp_datamart_customerdetail as xz
set
     NamaLengkap = public.full_trim_regex(REGEXP_REPLACE(UPPER(xz.NamaLengkap), $$[^0-9A-Z ]$$, ' ', 'g'))
    ,CustomerName = public.full_trim_regex(REGEXP_REPLACE(UPPER(xz.CustomerName), $$[^0-9A-Z ]$$, ' ', 'g'))
    ,NamaGadisIbuKandung = public.full_trim_regex(REGEXP_REPLACE(UPPER(xz.NamaGadisIbuKandung), $$[^0-9A-Z ]$$, ' ', 'g'))
    ,NamaGroupDebitur = public.full_trim_regex(REGEXP_REPLACE(UPPER(xz.NamaGroupDebitur), $$[^0-9A-Z ]$$, ' ', 'g'))
    ,NamaPasangan = public.full_trim_regex(REGEXP_REPLACE(UPPER(xz.NamaPasangan), $$[^0-9A-Z ]$$, ' ', 'g'))
    ,UpdateQuery = xz.UpdateQuery || 'UQ-090#'
;

z_cErrMsg = public.serene(1, 'C700');

truncate table tmp_17319884_customername_cleansing;

z_cErrMsg = public.serene(1, 'C670');

insert into tmp_17319884_customername_cleansing
(
     customerid                ,customertype              ,customername_ori
    ,functionname
)
select
     xa.customerid_ori as customerid
    ,xa.customertype as customertype
    ,xa.customername as customername_ori
    ,z_cFuncName || '-customername' as functionname
from tmp_datamart_customerdetail as xa
;

z_cErrMsg = public.serene(1, 'C680');

Z_cResult = ads.PRCS_Datamart_Customer_CleansingName(z_dPeriod);

if Z_cResult <> '0'
then
    z_cErrMsg = 'Error#05 - Error on PRCS_Datamart_Customer_CleansingName';
    raise EXCEPTION 'Exception Raised';
end if;

z_cErrMsg = public.serene(1, 'C690');

update tmp_datamart_customerdetail as xz
set
     NamaLengkap = xa.customername_clean
    ,CustomerName = xa.customername_clean
from tmp_17319884_customername_cleansing as xa
where xz.customerid_ori = xa.customerid
-- and xa.removedkeyword <> '' -- ada cleansing --
and xz.CustomerName <> xa.customername_clean -- ada cleansing --
;

z_cErrMsg = public.serene(1, 'C710');

truncate table tmp_17319884_customername_cleansing;

z_cErrMsg = public.serene(1, 'C720');

insert into tmp_17319884_customername_cleansing
(
     customerid                ,customertype              ,customername_ori
    ,functionname
)
select
     xa.customerid_ori as customerid
    ,'A' as customertype -- A = perorangan --
    ,xa.NamaGadisIbuKandung as customername_ori
    ,z_cFuncName || '-namagadisibukandung' as functionname
from tmp_datamart_customerdetail as xa
where xa.NamaGadisIbuKandung <> ''
;

z_cErrMsg = public.serene(1, 'C730');

Z_cResult = ads.PRCS_Datamart_Customer_CleansingName(z_dPeriod);

if Z_cResult <> '0'
then
    z_cErrMsg = 'Error#06 - Error on PRCS_Datamart_Customer_CleansingName';
    raise EXCEPTION 'Exception Raised';
end if;

z_cErrMsg = public.serene(1, 'C740');

update tmp_datamart_customerdetail as xz
set
     NamaGadisIbuKandung = xa.customername_clean
from tmp_17319884_customername_cleansing as xa
where xz.customerid_ori = xa.customerid
and xz.NamaGadisIbuKandung <> xa.customername_clean -- ada cleansing --
;

z_cErrMsg = public.serene(1, 'C620');

Z_cResult = ads.prcs_datamart_customerdetail_resikonasabah(z_dPeriod);

if Z_cResult <> '0' then
    z_cErrMsg = 'Error#04 - Error on prcs_datamart_customerdetail_resikonasabah';
    raise EXCEPTION 'Exception Raised';
end if;

----------------------------------------------------------------------------------------------------------
-- Main Process Result --
----------------------------------------------------------------------------------------------------------
z_cErrMsg = public.serene(1, 'D020');

---- housekeep table based on hkeep_yn ----
delete from probi.datamart_customerdetail as xz
where xz.hkeep_yn = 'Y' -- Y = will be deleted --
and xz.hkeep_dt < z_dPeriod + '-7 DAY'::interval
;

z_cErrMsg = public.serene(1, 'D030');

delete from probi.datamart_customerdetail as xz
where xz.hkeep_dt = z_dPeriod
;

z_cErrMsg = public.serene(1, 'D040');

insert into probi.datamart_customerdetail
(
     customerid_ori           ,customerid_konven        ,customerid_syariah
    ,customertype             ,officecustomer           ,officecustomer_ori
    ,customername             ,namalengkap              ,telepon
    ,nomortelepongenggam      ,alamatemail              ,alamat
    ,kelurahan                ,kecamatan                ,kodedatiii
    ,kodepos                  ,kodenegara               ,kodepekerjaan
    ,melanggarbm              ,melampauibm              ,kodebidangusaha
    ,idnumber                 ,idtype                   ,flagwniwna
    ,kodestatusgelardebitur   ,jeniskelamin             ,tempatlahirktp
    ,tanggallahir             ,npwp                     ,tempatbekerja
    ,alamattempatbekerja      ,penghasilankotorpertahun ,kodesumberpenghasilan
    ,kodehubungandenganljk    ,kodegolongandebitur      ,statusperkawinandebitur
    ,namagadisibukandung      ,kodejenisbadanusaha      ,gopublic
    ,idgroupdebitur           ,namagroupdebitur         ,noaktependirian
    ,noakteperubahanterakhir  ,source                   ,lastchangeduser
    ,PeringkatDebitur         ,LembagaPemeringkat       ,TanggalPemeringkatan
    ,bibankid                 ,idoperasional
    ,bibankid_syariah         ,kodekantorcabang
    ,insertquery              ,updatequery              ,deletequery
    ,hkeep_dt                 ,hkeep_yn                 ,kewarganegaraan
    ,nikpassportpasangan
    ,namapasangan
    ,tanggallahirpasangan
    ,perjanjianpisahharta
    ,jumlahtanggungan
    ,tanggalaktependirian
    ,tanggalakteperubahanterakhir
    ,riskprofile_status
    ,riskprofile_totalpoint
    ,datapekerjaan_cfoccd
    ,datapekerjaan_cfejcd
    ,hrparam_cfjobc
    ,hrparam_cfjobdep
    ,hrparam_cfjobsts
    ,hrparam_cfjobcsts
    ,hrcmaintenance_cfstsh
    ,hrcmaintenance_cfjobsts
    ,hrcmaintenance_cfind7
    ,risk_rating
    ,resiko_nasabah
    ,penghasilankotorpertahun_ori_cfzemp
    ,currencycode_cfzemp
    ,kodejenisbadanusaha_desc
    ,alamat_code
    ,CustomerName_ORI
    ,NamaGadisIbuKandung_ORI
)
select
     xa.customerid_ori as customerid_core
    ,xa.customerid_konven as customerid_konven
    ,xa.customerid_syariah as customerid_syariah
    ,xa.customertype as customertype
    ,xa.officecustomer as officecustomer
    ,xa.officecustomer_ori as officecustomer_ori
    ,xa.customername as customername
    ,xa.namalengkap as namalengkap
    ,xa.telepon as telepon
    ,xa.nomortelepongenggam as nomortelepongenggam
    ,xa.alamatemail as alamatemail
    ,xa.alamat as alamat
    ,xa.kelurahan as kelurahan
    ,xa.kecamatan as kecamatan
    ,xa.kodedatiii as kodedatiii
    ,xa.kodepos as kodepos
    ,xa.kodenegara as kodenegara
    ,xa.kodepekerjaan as kodepekerjaan
    ,xa.melanggarbm as melanggarbm
    ,xa.melampauibm as melampauibm
    ,xa.kodebidangusaha as kodebidangusaha
    ,xa.idnumber as idnumber
    ,xa.idtype as idtype
    ,xa.flagwniwna as flagwniwna
    ,xa.kodestatusgelardebitur as kodestatusgelardebitur
    ,xa.jeniskelamin as jeniskelamin
    ,xa.tempatlahirktp as tempatlahirktp
    ,xa.tanggallahir as tanggallahir
    ,xa.npwp as npwp
    ,xa.tempatbekerja as tempatbekerja
    ,xa.alamattempatbekerja as alamattempatbekerja
    ,xa.penghasilankotorpertahun as penghasilankotorpertahun
    ,xa.kodesumberpenghasilan as kodesumberpenghasilan
    ,xa.kodehubungandenganljk as kodehubungandenganljk
    ,xa.kodegolongandebitur as kodegolongandebitur
    ,xa.statusperkawinandebitur as statusperkawinandebitur
    ,xa.namagadisibukandung as namagadisibukandung
    ,xa.kodejenisbadanusaha as kodejenisbadanusaha
    ,xa.gopublic as gopublic
    ,xa.idgroupdebitur as idgroupdebitur
    ,xa.namagroupdebitur as namagroupdebitur
    ,xa.noaktependirian as noaktependirian
    ,xa.noakteperubahanterakhir as noakteperubahanterakhir
    ,xa.source as source
    ,xa.lastchangeduser as lastchangeduser
    ,xa.PeringkatDebitur as PeringkatDebitur
    ,xa.LembagaPemeringkat as LembagaPemeringkat
    ,xa.TanggalPemeringkatan as TanggalPemeringkatan
    ,xa.bibankid as bibankid
    ,z_cIdOperasional as idoperasional
    ,xa.bibankid_syariah as bibankid_syariah
    ,xa.kodekantorcabang as kodekantorcabang
    ,xa.insertquery as insertquery
    ,xa.updatequery as updatequery
    ,xa.deletequery as deletequery
    ,z_dPeriod as hkeep_dt
    ,z_cHKeepYN as hkeep_yn
    ,xa.kewarganegaraan as kewarganegaraan
    ,xa.nikpassportpasangan as nikpassportpasangan
    ,xa.namapasangan as namapasangan
    ,xa.tanggallahirpasangan as tanggallahirpasangan
    ,xa.perjanjianpisahharta as perjanjianpisahharta
    ,xa.jumlahtanggungan as jumlahtanggungan
    ,xa.tanggalaktependirian as tanggalaktependirian
    ,xa.tanggalakteperubahanterakhir as tanggalakteperubahanterakhir
    ,xa.riskprofile_status
    ,xa.riskprofile_totalpoint
    ,xa.datapekerjaan_cfoccd
    ,xa.datapekerjaan_cfejcd
    ,xa.hrparam_cfjobc
    ,xa.hrparam_cfjobdep
    ,xa.hrparam_cfjobsts
    ,xa.hrparam_cfjobcsts
    ,xa.hrcmaintenance_cfstsh
    ,xa.hrcmaintenance_cfjobsts
    ,xa.hrcmaintenance_cfind7
    ,xa.risk_rating
    ,xa.resiko_nasabah
    ,xa.penghasilankotorpertahun_ori_cfzemp as penghasilankotorpertahun_ori_cfzemp
    ,xa.currencycode_cfzemp as currencycode_cfzemp
    ,xa.kodejenisbadanusaha_desc as kodejenisbadanusaha_desc
    ,xa.alamat_code
    ,xa.CustomerName_ORI
    ,xa.NamaGadisIbuKandung_ORI
from tmp_datamart_customerdetail as xa
;

z_cErrMsg = public.serene(1, 'D050');

return 0;

----------------------------------------------------------------------------------------------------------
-- Exception --
----------------------------------------------------------------------------------------------------------
EXCEPTION
when OTHERS then
z_cFuncName = COALESCE(z_cFuncName, '[UNSPECIFIED FUNCTION NAME]');
z_cErrMsg   = COALESCE(z_cErrMsg, 'Error#00 - Unspecified Error. Please review the function definition.');
z_cSQLState = SQLSTATE;
z_cSQLMsg   = SQLERRM;
z_cUser     = CURRENT_USER;

perform public.DailyProcessErrorMessageInsert
(
     z_cFuncName -- z_pcFunctionName --
    ,z_cErrMsg -- z_pcErrorMessage --
    ,z_cSQLState -- z_pcSQLErrNo --
    ,z_cSQLMsg -- z_pcSQLErrMessage --
    ,z_cUser -- z_pcUserId --
);

raise EXCEPTION '[PG_ERROR - %]: % | % - %', z_cFuncName, z_cErrMsg, z_cSQLState, z_cSQLMsg;

----------------------------------------------------------------------------------------------------------
-- Object Usage List --
----------------------------------------------------------------------------------------------------------
/*
-- Table --
ads.cfaddr_distinct_year_v
ads.cfaidn_distinct_year_v
ads.cfconn_distinct_year_v
ads.cfzemp_distinct_year_v
ads.cfbicd
ads.cfbicde
ads.cfmast
ads.cfsyrmp
probi.cfpar2_log
probi.cfparu_log
mis.miscurrencyratehistory
mis.misofficeinformation
ads.ps_n_debtur_org_slik_vw
probi.regulatory_mapping_tr

-- Function --
ads.prcs_datamart_customerdetail_resikonasabah

-- Result --
probi.datamart_customerdetail
*/
--========================================================================================================
END;--FUNCTION--
--========================================================================================================
$BODY$
language plpgsql volatile;