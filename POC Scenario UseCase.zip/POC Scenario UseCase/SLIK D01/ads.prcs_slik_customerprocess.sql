create or replace function ads.prcs_slik_customerprocess
(
     z_pdperiod date
)
returns integer
as
$BODY$
----------------------------------------------------------------------------------------------------------
-- Variable Declaration --
----------------------------------------------------------------------------------------------------------
declare
---- system variable ----
z_cFuncName   character varying;
z_cErrMsg     character varying;
z_cSQLState   character varying;
z_cSQLMsg     character varying;
z_cUser       character varying;
z_cQuery      character varying;
z_cColumnList character varying;

---- procedure variable ----
z_dCurrEOD          date;
z_dCurrEOM          date;
z_dPeriod           date;
z_dPeriodHC         date;
z_dPeriodCurrBOM    date;
z_dPeriodLastEOM    date;
z_dPeriodPrev1EOD   date;

z_nProcessId        integer;
z_nJobId            integer;
z_cStatusProcess    character varying;
z_nSubmitterNIK     integer;
z_dApplyNeo         date;

--========================================================================================================
BEGIN--FUNCTION--
--========================================================================================================
----------------------------------------------------------------------------------------------------------
-- Variable Assignment --
----------------------------------------------------------------------------------------------------------
set optimizer = true;

z_cFuncName = 'PRCS_SLIK_CustomerProcess';

select
 xa.ops_date
from ads.DOPS_Parameters as xa
into
 z_dCurrEOD
;

z_dCurrEOM = DATE_TRUNC('month', z_dCurrEOD)::date - 1;
z_dPeriod = COALESCE(z_pdPeriod, z_dCurrEOM::date);

if DATE_PART('month', z_dPeriod) <> DATE_PART('month', z_dPeriod + '1 DAY'::interval) -- end of month date --
then
    z_dPeriodHC = z_dPeriod;
else
    z_dPeriodHC = DATE_TRUNC('month', z_dPeriod + '0 month'::interval) - '1 DAY'::interval;
end if;

z_dPeriodCurrBOM = DATE_TRUNC('MONTH', z_dPeriod + '0 MONTH'::interval);
z_dPeriodLastEOM = DATE_TRUNC('month', z_dPeriod)::date - 1;
z_dPeriodPrev1EOD = z_dPeriod + '-1 DAY'::interval;

-- deploy neo berlaku pertama kali untuk pelaporan
z_dApplyNeo = '20240131'::date;

z_nProcessId = 2;
z_nJobId = 24;
z_cStatusProcess = 'success';
z_nSubmitterNIK = 99999;

----------------------------------------------------------------------------------------------------------
-- Variable Debug --
----------------------------------------------------------------------------------------------------------
raise notice 'z_dCurrEOD        : %', z_dCurrEOD;
raise notice 'z_dCurrEOM        : %', z_dCurrEOM;
raise notice 'z_dPeriod         : %', z_dPeriod;
raise notice 'z_dPeriodLastEOM  : %', z_dPeriodLastEOM;
raise notice 'z_dPeriodHC       : %', z_dPeriodHC;
raise notice 'z_nProcessId      : %', z_nProcessId;
raise notice 'z_nJobId          : %', z_nJobId;
raise notice 'z_cStatusProcess  : %', z_cStatusProcess;
raise notice 'z_nSubmitterNIK   : %', z_nSubmitterNIK;

----------------------------------------------------------------------------------------------------------
-- Preliminary Validation --
----------------------------------------------------------------------------------------------------------
if z_dPeriod > z_dCurrEOD
then
    raise notice 'Error#01 - Cannot accept period greater than %.', TO_CHAR(z_dCurrEOD, 'DD FMMonth YYYY');
    return 1;
end if;

if z_dPeriod < DATE_TRUNC('MONTH', z_dCurrEOD + '-13 MONTH'::interval)
then
    raise notice 'Error#02 - Cannot accept period older than %.', TO_CHAR(DATE_TRUNC('MONTH', z_dCurrEOD + '-13 MONTH'::interval), 'DD FMMonth YYYY');
    return 1;
end if;

----------------------------------------------------------------------------------------------------------
-- Temporary Procedure Table Declaration --
----------------------------------------------------------------------------------------------------------
z_cErrMsg = public.serene(1, 'A010');

perform public.fnDropTemporaryTable('TMP_SLIK_CustomerDetail');
create temporary table TMP_SLIK_CustomerDetail
(
     Period                     date
    ,CustomerType               character varying
    ,CIF                        character varying
    ,OfficeCIF                  character varying
    ,CIFName                    character varying
    ,NamaLengkap                character varying
    ,Telepon                    character varying
    ,NomorTeleponGenggam        character varying
    ,AlamatEmail                character varying
    ,Alamat                     character varying
    ,Kelurahan                  character varying
    ,Kecamatan                  character varying
    ,KodeDATIII                 character varying
    ,KodePos                    character varying
    ,KodeNegara                 character varying
    ,KodePekerjaan              character varying -- KodeBidangUsaha
    ,MelanggarBM                character varying
    ,MelampauiBM                character varying
    ,KodeBidangUsaha            character varying -- SektorEkonomi
    ,IdNumber                   character varying
    ,IDType                     character varying
    ,FlagWNIWNA                 character varying
    ,KodeStatusGelarDebitur     character varying
    ,JenisKelamin               character varying
    ,TempatLahirKTP             character varying
    ,TanggalLahir               date
    ,NPWP                       character varying
    ,TempatBekerja              character varying
    ,AlamatTempatBekerja        character varying
    ,PenghasilanKotorPerTahun   numeric
    ,KodeSumberPenghasilan      character varying
    ,KodeHubungandenganLJK      character varying
    ,KodeGolonganDebitur        character varying
    ,StatusPerkawinanDebitur    character varying
    ,NamaGadisIbuKandung        character varying
    ,KodeJenisBadanUsaha        character varying
    ,CIFOri                     character varying
    ,Source                     character varying
    ,kodekantorcabang               character varying
    ,insertquery                    character varying
    ,updatequery                    character varying default ''
    ,deletequery                    character varying
    ,gopublic                       character varying
    ,idgroupdebitur                 numeric(10,0)
    ,namagroupdebitur               character varying
    ,noaktependirian                character varying
    ,noakteperubahanterakhir        character varying
    ,peringkatdebitur               character varying
    ,lembagapemeringkat             character varying
    ,tanggalpemeringkatan           date
    ,nikpassportpasangan            character varying
    ,namapasangan                   character varying
    ,tanggallahirpasangan           date
    ,perjanjianpisahharta           character varying
    ,jumlahtanggungan               integer
    ,tanggalaktependirian           date
    ,tanggalakteperubahanterakhir   date
    ,kodejenisbadanusaha_desc       character varying
)
distributed randomly;

z_cErrMsg = public.serene(1, 'A020');

perform public.fnDropTemporaryTable('TMP_SLIK_CustomerMaster');
create temporary table TMP_SLIK_CustomerMaster
(
     CIF                character varying
    ,CustomerType       character varying -- CompanyFlag
    ,PeriodPelaporan    date
    ,CIFOri             character varying
    ,KodeKantorCabang   character varying
    ,statussyariah      character varying
    ,insertquery        character varying
    ,updatequery        character varying default ''
    ,deletequery        character varying
)
distributed randomly;

----------------------------------------------------------------------------------------------------------
-- Temporary Source Table Declaration --
----------------------------------------------------------------------------------------------------------
z_cErrMsg = public.serene(1, 'B010');
---- ads.cfmast ----
perform public.fnDropTemporaryView('TMPV_cfmast');
z_cColumnList = ''
|| CHR(10) || ' cfcif_2 ,cfbird ,cfbrnn ,cfclas ,cfcoun ,cfmotn ,cfna1'
|| CHR(10) || ',cfsex ,cfsscd ,cfssno ,cfuic2 ,cfuic3 ,cfybip ,cfytib ,cfcitz'
|| CHR(10) || ',cfvusr'
|| CHR(10) || ',cfisd6'
|| CHR(10) || ',cfna1a'
;

z_cQuery = public.fnGenQuery4Partition('ads', 'cfmast', z_dPeriod, z_dCurrEOD, NULL, z_cColumnList);

z_cQuery = '
create temporary view TMPV_cfmast as
select distinct
 xa.*
from (' || z_cQuery || ') as xa
where xa.scd_end = ''' || z_dPeriod || '''::date
;';

execute z_cQuery;

z_cErrMsg = public.serene(1, 'B020');
---- ads.cfbicd ----
perform public.fnDropTemporaryView('TMPV_cfbicd');
z_cColumnList = '
     cfcif_2    ,bihub1 ,bijdsn ,bilok1 ,bipemi ,bipfix
';

z_cQuery = public.fnGenQuery4Partition('ads', 'cfbicd', z_dPeriod, z_dCurrEOD, NULL, z_cColumnList);

z_cQuery = '
create temporary view TMPV_cfbicd as
select distinct
 xa.*
from (' || z_cQuery || ') as xa
where xa.scd_end = ''' || z_dPeriod || '''::date
;';

execute z_cQuery;

z_cErrMsg = public.serene(1, 'B030');
---- ads.cfsyrmp ----
perform public.fnDropTemporaryView('TMPV_cfsyrmp');
-- z_cColumnList = '
     -- cfcif_2
-- ';

z_cColumnList = ''
|| CHR(10) || ' cfcif_2 ,cfsyr_2'
;

z_cQuery = public.fnGenQuery4Partition('ads', 'cfsyrmp', z_dPeriod, z_dCurrEOD, NULL, z_cColumnList);

z_cQuery = '
create temporary view TMPV_cfsyrmp as
select distinct
 xa.*
from (' || z_cQuery || ') as xa
where xa.hkeep_dt = ''' || z_dPeriod || '''::date
;';

execute z_cQuery;

z_cErrMsg = public.serene(1, 'B040');
---- ads.ps_n_debtur_org_slik_vw ----
perform public.fnDropTemporaryTable('TMP_ps_n_debtur_org_slik_vw');
create temporary table TMP_ps_n_debtur_org_slik_vw
(
     c_cif_nbr          character varying(40)
    ,national_id_type   character varying
    ,national_id        character varying
    ,name               character varying
    ,education_lvl_achv character varying
    ,sex                character varying
    ,birthplace         character varying
    ,birthdate          character varying
    ,idn_tax_ee_id      character varying
    ,addresslong        character varying
    ,address3           character varying
    ,address4           character varying
    ,postal             character varying
    ,phone              character varying
    ,phone1             character varying
    ,email_addr         character varying
    ,descr              character varying
    ,addresslong10      character varying
    ,annual_rt          numeric(30,4)
    ,mar_status         character varying
    ,name2              character varying
    ,load_dt            date
    ,rowid              integer
    ,idn_tax_status     character varying
    ,national_id2       character varying
    ,name3              character varying
    ,date3              date
    ,n_c_pisah_harta    character varying
)
distributed randomly;

insert into TMP_ps_n_debtur_org_slik_vw
(
     c_cif_nbr          ,national_id_type   ,national_id    ,name
    ,education_lvl_achv ,sex                ,birthplace     ,birthdate
    ,idn_tax_ee_id      ,addresslong        ,address3       ,address4
    ,postal             ,phone              ,phone1         ,email_addr
    ,descr              ,addresslong10      ,annual_rt      ,mar_status
    ,name2              ,load_dt            ,rowid
    ,idn_tax_status
    ,national_id2
    ,name3
    ,date3
    ,n_c_pisah_harta
)
select
     xa.c_cif_nbr
    ,TRIM(xa.national_id_type)
    ,TRIM(xa.national_id)
    ,TRIM(xa.name)
    ,TRIM(xa.education_lvl_achv)
    ,TRIM(xa.sex)
    ,TRIM(xa.birthplace)
    ,TRIM(xa.birthdate)
    ,TRIM(xa.idn_tax_ee_id)
    ,TRIM(xa.addresslong)
    ,TRIM(xa.address3)
    ,TRIM(xa.address4)
    ,TRIM(xa.postal)
    ,TRIM(xa.phone)
    ,TRIM(xa.phone1)
    ,TRIM(xa.email_addr)
    ,TRIM(xa.descr)
    ,TRIM(xa.addresslong10)
    ,xa.annual_rt
    ,TRIM(xa.mar_status)
    ,TRIM(xa.name2)
    ,xa.load_dt
    ,ROW_NUMBER() OVER (partition by xa.c_cif_nbr order by xa.date_applied desc) as rowid
    ,TRIM(xa.idn_tax_status) as idn_tax_status
    ,TRIM(xa.national_id2) as national_id2
    ,TRIM(xa.name3) as name3
    ,xa.date3::date as date3
    ,TRIM(xa.n_c_pisah_harta) as n_c_pisah_harta
from ads.ps_n_debtur_org_slik_vw as xa
where xa.load_dt = z_dPeriodHC
;

delete from TMP_ps_n_debtur_org_slik_vw
where rowid <> 1
;

z_cErrMsg = public.serene(1, 'B050');

perform public.fnDropTemporaryTable('TMP_SLIK_CustomerDetail_Prev');
create temporary table TMP_SLIK_CustomerDetail_Prev
(
     Period                     date
    ,CustomerType               character varying
    ,CIF                        character varying
    ,OfficeCIF                  character varying
    ,CIFName                    character varying
    ,NamaLengkap                character varying
    ,Telepon                    character varying
    ,NomorTeleponGenggam        character varying
    ,AlamatEmail                character varying
    ,Alamat                     character varying
    ,Kelurahan                  character varying
    ,Kecamatan                  character varying
    ,KodeDATIII                 character varying
    ,KodePos                    character varying
    ,KodeNegara                 character varying
    ,KodePekerjaan              character varying -- KodeBidangUsaha
    ,MelanggarBM                character varying
    ,MelampauiBM                character varying
    ,KodeBidangUsaha            character varying -- SektorEkonomi
    ,IdNumber                   character varying
    ,IDType                     character varying
    ,FlagWNIWNA                 character varying
    ,KodeStatusGelarDebitur     character varying
    ,JenisKelamin               character varying
    ,TempatLahirKTP             character varying
    ,TanggalLahir               date
    ,NPWP                       character varying
    ,TempatBekerja              character varying
    ,AlamatTempatBekerja        character varying
    ,PenghasilanKotorPerTahun   numeric
    ,KodeSumberPenghasilan      character varying
    ,KodeHubungandenganLJK      character varying
    ,KodeGolonganDebitur        character varying
    ,StatusPerkawinanDebitur    character varying
    ,NamaGadisIbuKandung        character varying
    ,KodeJenisBadanUsaha        character varying
    ,CIFOri                     character varying
    ,Source                     character varying
    ,lastchangeduser                character varying
    ,kodekantorcabang               character varying
    ,gopublic                       character varying
    ,idgroupdebitur                 numeric(10,0)
    ,namagroupdebitur               character varying
    ,noaktependirian                character varying
    ,noakteperubahanterakhir        character varying
    ,peringkatdebitur               character varying
    ,lembagapemeringkat             character varying
    ,tanggalpemeringkatan           date
    ,nikpassportpasangan            character varying
    ,namapasangan                   character varying
    ,tanggallahirpasangan           date
    ,perjanjianpisahharta           character varying
    ,jumlahtanggungan               integer
    ,tanggalaktependirian           date
    ,tanggalakteperubahanterakhir   date
    ,kodejenisbadanusaha_desc       character varying
)
distributed randomly;

z_cErrMsg = public.serene(1, 'B060');

insert into TMP_SLIK_CustomerDetail_Prev
(
     Period
    ,CIF
    ,OfficeCIF
    ,CIFName
    ,NamaLengkap
    ,Telepon
    ,NomorTeleponGenggam
    ,AlamatEmail
    ,Alamat
    ,Kelurahan
    ,Kecamatan
    ,KodeDATIII
    ,KodePos
    ,KodeNegara
    ,KodePekerjaan -- KodeBidangUsaha
    ,MelanggarBM
    ,MelampauiBM
    ,KodeBidangUsaha -- SektorEkonomi
    ,IdNumber
    ,IDType
    ,FlagWNIWNA
    ,KodeStatusGelarDebitur
    ,JenisKelamin
    ,TempatLahirKTP
    ,TanggalLahir
    ,NPWP
    ,TempatBekerja
    ,AlamatTempatBekerja
    ,PenghasilanKotorPerTahun
    ,KodeSumberPenghasilan
    ,KodeHubungandenganLJK
    ,KodeGolonganDebitur
    ,StatusPerkawinanDebitur
    ,NamaGadisIbuKandung
    ,KodeJenisBadanUsaha
    ,CIFOri
    ,Source
    ,lastchangeduser
    ,kodekantorcabang
    ,gopublic
    ,idgroupdebitur
    ,namagroupdebitur
    ,noaktependirian
    ,noakteperubahanterakhir
    ,peringkatdebitur
    ,lembagapemeringkat
    ,tanggalpemeringkatan
    ,nikpassportpasangan
    ,namapasangan
    ,tanggallahirpasangan
    ,perjanjianpisahharta
    ,jumlahtanggungan
    ,tanggalaktependirian
    ,tanggalakteperubahanterakhir
    ,kodejenisbadanusaha_desc
)
select distinct
     xa.Period
    ,xa.CIF
    ,xa.OfficeCIF
    ,xa.CIFName
    ,xa.NamaLengkap
    ,xa.Telepon
    ,xa.NomorTeleponGenggam
    ,xa.AlamatEmail
    ,xa.Alamat
    ,xa.Kelurahan
    ,xa.Kecamatan
    ,xa.KodeDATIII
    ,xa.KodePos
    ,xa.KodeNegara
    ,xa.KodePekerjaan -- KodeBidangUsaha
    ,xa.MelanggarBM
    ,xa.MelampauiBM
    ,xa.KodeBidangUsaha -- SektorEkonomi
    ,xa.IdNumber
    ,xa.IDType
    ,xa.FlagWNIWNA
    ,xa.KodeStatusGelarDebitur
    ,xa.JenisKelamin
    ,xa.TempatLahirKTP
    ,xa.TanggalLahir
    ,xa.NPWP
    ,xa.TempatBekerja
    ,xa.AlamatTempatBekerja
    ,xa.PenghasilanKotorPerTahun
    ,xa.KodeSumberPenghasilan
    ,xa.KodeHubungandenganLJK
    ,xa.KodeGolonganDebitur
    ,xa.StatusPerkawinanDebitur
    ,xa.NamaGadisIbuKandung
    ,xa.KodeJenisBadanUsaha
    ,xa.CIFOri
    ,xa.Source
    ,xa.lastchangeduser as lastchangeduser
    ,xa.kodekantorcabang as kodekantorcabang
    ,xa.gopublic as gopublic
    ,xa.idgroupdebitur as idgroupdebitur
    ,xa.namagroupdebitur as namagroupdebitur
    ,xa.noaktependirian as noaktependirian
    ,xa.noakteperubahanterakhir as noakteperubahanterakhir
    ,xa.peringkatdebitur as peringkatdebitur
    ,xa.lembagapemeringkat as lembagapemeringkat
    ,xa.tanggalpemeringkatan as tanggalpemeringkatan
    ,xa.nikpassportpasangan as nikpassportpasangan
    ,xa.namapasangan as namapasangan
    ,xa.tanggallahirpasangan as tanggallahirpasangan
    ,xa.perjanjianpisahharta as perjanjianpisahharta
    ,xa.jumlahtanggungan as jumlahtanggungan
    ,xa.tanggalaktependirian as tanggalaktependirian
    ,xa.tanggalakteperubahanterakhir as tanggalakteperubahanterakhir
    ,xa.kodejenisbadanusaha_desc as kodejenisbadanusaha_desc
from probi.slik_customerdetail as xa
where xa.Period = z_dPeriodLastEOM
;

z_cErrMsg = public.serene(1, 'B070');

perform public.fnDropTemporaryTable('TMP_datamart_customerdetail');
create temporary table TMP_datamart_customerdetail
(
     customerid_ori               character varying
    ,customerid_konven            character varying
    ,customerid_syariah           character varying
    ,customertype                 character varying
    ,officecustomer               character varying
    ,officecustomer_ori           character varying
    ,customername                 character varying
    ,namalengkap                  character varying
    ,telepon                      character varying
    ,nomortelepongenggam          character varying
    ,alamatemail                  character varying
    ,alamat                       character varying
    ,kelurahan                    character varying
    ,kecamatan                    character varying
    ,kodedatiii                   character varying
    ,kodepos                      character varying
    ,kodenegara                   character varying
    ,kodepekerjaan                character varying
    ,melanggarbm                  character varying
    ,melampauibm                  character varying
    ,kodebidangusaha              character varying
    ,idnumber                     character varying
    ,idtype                       character varying
    ,flagwniwna                   character varying
    ,kewarganegaraan              character varying
    ,kodestatusgelardebitur       character varying
    ,jeniskelamin                 character varying
    ,tempatlahirktp               character varying
    ,tanggallahir                 date
    ,npwp                         character varying
    ,tempatbekerja                character varying
    ,alamattempatbekerja          character varying
    ,penghasilankotorpertahun     numeric
    ,kodesumberpenghasilan        character varying
    ,kodehubungandenganljk        character varying
    ,kodegolongandebitur          character varying
    ,statusperkawinandebitur      character varying
    ,namagadisibukandung          character varying
    ,kodejenisbadanusaha          character varying
    ,gopublic                     character varying
    ,idgroupdebitur               numeric(10,0)
    ,namagroupdebitur             character varying
    ,noaktependirian              character varying
    ,noakteperubahanterakhir      character varying
    ,source                       character varying
    ,lastchangeduser              character varying
    ,peringkatdebitur             character varying
    ,lembagapemeringkat           character varying
    ,tanggalpemeringkatan         date
    ,bibankid                     integer
    ,bibankid_syariah             integer
    ,kodekantorcabang             character varying
    ,idoperasional                character varying
    ,idpihaklawan                 character varying
    ,insertquery                  character varying
    ,updatequery                  character varying
    ,deletequery                  character varying
    ,hkeep_yn                     character(1)
    ,hkeep_dt                     date
    ,nikpassportpasangan          character varying
    ,namapasangan                 character varying
    ,tanggallahirpasangan         date
    ,perjanjianpisahharta         character varying
    ,jumlahtanggungan             integer
    ,tanggalaktependirian         date
    ,tanggalakteperubahanterakhir date
    ,kodejenisbadanusaha_desc     character varying
)
distributed randomly;

z_cErrMsg = public.serene(1, 'B080');


z_cColumnList = ''
|| CHR(10) || ' customerid_ori               ,customerid_konven            ,customerid_syariah'
|| CHR(10) || ',customertype                 ,officecustomer               ,officecustomer_ori'
|| CHR(10) || ',customername                 ,namalengkap                  ,telepon'
|| CHR(10) || ',nomortelepongenggam          ,alamatemail                  ,alamat'
|| CHR(10) || ',kelurahan                    ,kecamatan                    ,kodedatiii'
|| CHR(10) || ',kodepos                      ,kodenegara                   ,kodepekerjaan'
|| CHR(10) || ',melanggarbm                  ,melampauibm                  ,kodebidangusaha'
|| CHR(10) || ',idnumber                     ,idtype                       ,flagwniwna'
|| CHR(10) || ',kewarganegaraan              ,kodestatusgelardebitur       ,jeniskelamin'
|| CHR(10) || ',tempatlahirktp               ,tanggallahir                 ,npwp'
|| CHR(10) || ',tempatbekerja                ,alamattempatbekerja          ,penghasilankotorpertahun'
|| CHR(10) || ',kodesumberpenghasilan        ,kodehubungandenganljk        ,kodegolongandebitur'
|| CHR(10) || ',statusperkawinandebitur      ,namagadisibukandung          ,kodejenisbadanusaha'
|| CHR(10) || ',gopublic                     ,idgroupdebitur               ,namagroupdebitur'
|| CHR(10) || ',noaktependirian              ,noakteperubahanterakhir      ,source'
|| CHR(10) || ',lastchangeduser              ,peringkatdebitur             ,lembagapemeringkat'
|| CHR(10) || ',tanggalpemeringkatan         ,bibankid                     ,bibankid_syariah'
|| CHR(10) || ',kodekantorcabang             ,idoperasional                ,idpihaklawan'
|| CHR(10) || ',insertquery                  ,updatequery                  ,deletequery'
|| CHR(10) || ',nikpassportpasangan          ,namapasangan                 ,tanggallahirpasangan'
|| CHR(10) || ',perjanjianpisahharta         ,jumlahtanggungan             ,tanggalaktependirian'
|| CHR(10) || ',tanggalakteperubahanterakhir ,kodejenisbadanusaha_desc     ,hkeep_yn'
;

z_cQuery = public.fnGenQuery4Partition('probi', 'datamart_customerdetail', z_dPeriod, z_dPeriod, NULL, z_cColumnList);
z_cQuery = ''
|| CHR(10) || 'insert into TMP_datamart_customerdetail'
|| CHR(10) || '('
|| CHR(10) || '     hkeep_dt ,' || z_cColumnList
|| CHR(10) || ')'
|| CHR(10) || 'select'
|| CHR(10) || '     xa.hkeep_dt'
|| CHR(10) || '    ,' || z_cColumnList
|| CHR(10) || 'from (' || z_cQuery || ') as xa'
|| CHR(10) || ';'
;

execute z_cQuery;

z_cErrMsg = public.serene(1, 'B081');


---- probi.slik_accountdetail ----
perform public.fnDropTemporaryView('TMPV_slik_accountdetail');

z_cColumnList = ''
|| CHR(10) || ' cifori           ,form             ,currency         ,statussyariah'
|| CHR(10) || ',keterangan       ,kodejenis        ,insertquery      ,source'
|| CHR(10) || ',kodekantorcabang ,cif              ,kap              ,lastchangeduser'
|| CHR(10) || ',updatequery      ,deletequery'
;

z_cQuery = public.fnGenQuery4Partition('probi', 'slik_accountdetail', z_dPeriod, z_dPeriod, NULL, z_cColumnList);
z_cQuery = ''
|| CHR(10) || 'create or replace temporary view TMPV_slik_accountdetail as'
|| CHR(10) || 'select'
|| CHR(10) || '     xa.*'
|| CHR(10) || 'from (' || z_cQuery || ') as xa'
|| CHR(10) || ';'
;

execute z_cQuery;

z_cErrMsg = public.serene(1, 'B085');

---- dmt.datamart_lv2b_accountcredit ----
perform public.fnDropTemporaryView('TMPV_datamart_lv2b_accountcredit');

z_cColumnList = ''
|| CHR(10) || ' bibankid        ,customerid      ,customerid_reg  ,statusdate      ,source'
|| CHR(10) || ',sektorekonomi   ,keterangan      ,insertquery     ,updatequery     ,deletequery_slk'
|| CHR(10) || ',functionname    ,customertype    ,golongandebitur'
;

z_cQuery = public.fnGenQuery4Partition('dmt', 'datamart_lv2b_accountcredit', z_dPeriod, z_dPeriod, NULL, z_cColumnList);
z_cQuery = ''
|| CHR(10) || 'create or replace temporary view TMPV_datamart_lv2b_accountcredit as'
|| CHR(10) || 'select'
|| CHR(10) || '     xa.*'
|| CHR(10) || 'from (' || z_cQuery || ') as xa'
|| CHR(10) || ';'
;

execute z_cQuery;

--- karena bisa dijalankan daily, pengambilan cif dan cifori diganti dari accountdetail

z_cErrMsg = public.serene(1, 'B090');

perform public.fnDropTemporaryTable('TMP_SLIK_AccountDetail');
create temporary table TMP_SLIK_AccountDetail
(
     cif        character varying
    ,cifori     character varying
    ,statussyariah      character varying
    ,period             date
    ,kodekantorcabang   character varying
)
distributed randomly;

z_cErrMsg = public.serene(1, 'B100');
if z_dPeriod < z_dApplyNeo
then

    insert into TMP_SLIK_AccountDetail
    (
         cif
        -- ,cifori
        ,statussyariah
        ,period
    )
    select distinct
         xa.cif
        -- ,xa.cifori as cifori
        ,xa.statussyariah as statussyariah
        ,xa.period as period
    from TMPV_slik_accountdetail as xa
    where xa.Period = z_dPeriod
    and xa.cifori is not NULL
    ;
else
    z_cErrMsg = public.serene(1, 'B101');
    insert into TMP_SLIK_AccountDetail
    (
         cif
        ,statussyariah
        ,period
    )
    select distinct
         xa.cif
        ,xa.statussyariah as statussyariah
        ,xa.period as period
    from tmpv_slik_accountdetail as xa
    where xa.Period = z_dPeriod
    and xa.form <> 'F01'
    and xa.cifori is not NULL
    union
    select distinct
         xa.customerid_reg as cif
        ,case
            when substring(xa.bibankid::character varying, 3, 3)::integer >= 900 then 'Y'
            else 'T'
         end as statussyariah
        ,xa.hkeep_dt as period
    from TMPV_datamart_lv2b_accountcredit as xa
    where xa.hkeep_dt = z_dPeriod
    and xa.deletequery_slk is null
    ;
end if;

z_cErrMsg = public.serene(1, 'B110');

update TMP_SLIK_AccountDetail as xz
set
     cifori = xa.customerid_ori
from TMP_datamart_customerdetail as xa
where xa.hkeep_dt = z_dPeriod
and xz.cif = xa.customerid_konven
;

z_cErrMsg = public.serene(1, 'B111');

-- ubah dari datamart untuk cif sesuai konven / syariah
update TMP_SLIK_AccountDetail as xz
set
     cif = case
               when xz.statussyariah = 'Y' then case
                                                    when xa.customerid_syariah = '' then xz.cif
                                                    else xa.customerid_syariah
                                                end
               else xa.customerid_konven
           end
from TMP_datamart_customerdetail as xa
where xa.hkeep_dt = z_dPeriod
and xz.cifori = xa.customerid_ori
;
z_cErrMsg = public.serene(1, 'B112');
-- update kodekantorcabang selain form kredit - f01 dari slik_accountdetail --
update tmp_slik_accountdetail as xz
set
     kodekantorcabang = xa.kodekantorcabang
from tmpv_slik_accountdetail as xa
where xa.period = z_dPeriod
and xa.form <> 'F01'
and xa.cifori is not NULL
and xz.cif = xa.cif
;

z_cErrMsg = public.serene(1, 'B113');
-- update kodekantorcabang untuk form kredit - f01 dari datamart_lv4_accountcredit --
update tmp_slik_accountdetail as xz
set
     kodekantorcabang = substring(xa.bibankid::character varying, 3, 3)
from TMPV_datamart_lv2b_accountcredit as xa
where xa.hkeep_dt = z_dPeriod
and xa.deletequery_slk is null
and xz.cif = xa.customerid_reg
;

z_cErrMsg = public.serene(1, 'B120');

perform public.fnDropTemporaryTable('TMP_SLIK_CustomerMaster_Prev');
create temporary table TMP_SLIK_CustomerMaster_Prev
(
     CIF                character varying
    ,CustomerType       character varying
    ,MaxPeriodPelaporan date
    ,CIFOri             character varying
    ,KodeKantorCabang   character varying
    ,statussyariah      character varying
)
distributed randomly;

z_cErrMsg = public.serene(1, 'B130');

insert into TMP_SLIK_CustomerMaster_Prev
(
     CIF
    ,CustomerType
    ,MaxPeriodPelaporan
    ,CIFOri
    ,KodeKantorCabang
    ,statussyariah
)
select distinct
 xa.CIF as CIF
,xa.CustomerType as CustomerType
,max(xa.PeriodPelaporan) as MaxPeriodPelaporan
,xa.CIFOri as CIFOri
,xa.KodeKantorCabang as KodeKantorCabang
,xa.statussyariah as statussyariah
from probi.slik_customermaster as xa
where xa.CustomerType is not NULL
and xa.cifori is not null
and xa.kodekantorcabang is not null
and xa.statussyariah is not null
group by
 xa.CIF
,xa.CustomerType
,xa.CIFOri
,xa.KodeKantorCabang
,xa.statussyariah
;

z_cErrMsg = public.serene(1, 'B140');

perform public.fnDropTemporaryTable('TMP_CIF_Syariah');
create temporary table TMP_CIF_Syariah
(
     CIF        character varying
    ,CIFOri     character varying
)
distributed randomly;

z_cErrMsg = public.serene(1, 'B150');

insert into TMP_CIF_Syariah
(
     CIF
    ,CIFOri
)
select distinct
 xa.CIF
,xa.CIFOri
from TMP_SLIK_AccountDetail as xa
inner join TMPV_cfsyrmp as xb
    on xb.cfcif_2 = xa.CIFOri
where xa.period = z_dPeriod
;

z_cErrMsg = public.serene(1, 'B160');
-- tmp_misofficeinformation --
perform public.fnDropTemporaryTable('tmp_misofficeinformation');
create temporary table tmp_misofficeinformation
(
     office_id      character varying
    ,bopoffice      character varying
    ,physicalbranch character varying
    ,scd_end        date
)
distributed randomly;

z_cErrMsg = public.serene(1, 'B170');

insert into tmp_misofficeinformation
(
     office_id
    ,bopoffice
    ,physicalbranch
    ,scd_end
)
select
     xa.office_id
    ,xa.bopoffice
    ,xa.physicalbranch
    ,xa.scd_end as scd_end
from mis.misofficeinformation as xa
where xa.scd_end = z_dPeriod
;

z_cErrMsg = public.serene(1, 'B180');

perform public.fnDropTemporaryTable('TMP_ListAllCIF_Form');
create temporary table TMP_ListAllCIF_Form
(
     cif                character varying
    ,statussyariah      character varying
    ,kodekantorcabang   character varying
    ,max_period         date
    ,rowid              integer
)
distributed randomly;

z_cErrMsg = public.serene(1, 'B190');

insert into TMP_ListAllCIF_Form
(
     cif
    ,statussyariah
    ,kodekantorcabang
    ,max_period
    ,rowid
)
select distinct
     xa.cif as cif
    ,case
         when xa.kodekantorcabang ilike '9__' then 'Y'
         when xa.kodekantorcabang not ilike '9__' then 'T'
     end as statussyariah
    ,xa.kodekantorcabang as kodekantorcabang
    ,max(xa.period) as max_period
    ,ROW_NUMBER() OVER (partition by xa.cif, case
                                                 when xa.kodekantorcabang ilike '9__' then 'Y'
                                                 when xa.kodekantorcabang not ilike '9__' then 'T'
                                             end order by xa.period desc) as rowid
from probi.slik_f_d01 as xa
where xa.period < z_dPeriod
group by
      xa.cif
     ,xa.kodekantorcabang
     ,xa.period
union
select distinct
     xa.cif as cif
    ,case
         when xa.kodekantorcabang ilike '9__' then 'Y'
         when xa.kodekantorcabang not ilike '9__' then 'T'
     end as statussyariah
    ,xa.kodekantorcabang as kodekantorcabang
    ,max(xa.period) as max_period
    ,ROW_NUMBER() OVER (partition by xa.cif, case
                                                 when xa.kodekantorcabang ilike '9__' then 'Y'
                                                 when xa.kodekantorcabang not ilike '9__' then 'T'
                                             end order by xa.period desc) as rowid
from probi.slik_f_d02 as xa
where xa.period < z_dPeriod
group by
      xa.cif
     ,xa.kodekantorcabang
     ,xa.period
;

z_cErrMsg = public.serene(1, 'B280');

delete from TMP_ListAllCIF_Form as xz
where xz.rowid <> 1
;

z_cErrMsg = public.serene(1, 'B200');

perform public.fnDropTemporaryTable('TMP_CIFDuplikat');
create temporary table TMP_CIFDuplikat
(
     cif    character varying
    ,cifori character varying
    ,count  integer
)
distributed randomly;



z_cErrMsg = public.serene(1, 'B270');

perform public.fnDropTemporaryTable('tmp_jumlahtanggungan');
create temporary table tmp_jumlahtanggungan
(
     cifori             character varying
    ,jumlahtanggungan   integer
)
distributed randomly;

z_cErrMsg = public.serene(1, 'B280');

---- ads.cfyrat ----
perform public.fnDropTemporaryTable('TMP_cfyrat');
create temporary table TMP_cfyrat
(
     cfcif_2 character varying(40)
    ,cfvusr  character varying
    ,cyrtd7  timestamp without time zone
    ,cyrtrc  character varying
    ,cyrtrs  character varying
    ,load_dt date
)
distributed randomly;

z_cColumnList = ''
|| CHR(10) || ' cfcif_2 ,cfvusr  ,cyrtd7  ,cyrtrc  ,cyrtrs'
;

z_cQuery = public.fnGenQuery4Partition('ads', 'cfyrat', z_dPeriod, z_dCurrEOD, NULL, z_cColumnList);
z_cQuery = ''
|| CHR(10) || 'insert into TMP_cfyrat'
|| CHR(10) || '('
|| CHR(10) || '     load_dt ,' || z_cColumnList
|| CHR(10) || ')'
|| CHR(10) || 'select'
|| CHR(10) || ' xa.load_dt'
|| CHR(10) || ',' || z_cColumnList
|| CHR(10) || 'from (' || z_cQuery || ') as xa'
|| CHR(10) || ';'
;

execute z_cQuery;

---- ads.cfysie ----
perform public.fnDropTemporaryTable('TMP_cfysie');
create temporary table TMP_cfysie
(
     cfcif_2 character varying(40)
    ,cfvusr  character varying
    ,cfyamt  numeric
    ,cfycur  character varying
    ,cfyiec  character varying
    ,scd_end date
)
distributed randomly;

z_cColumnList = ''
|| CHR(10) || ' cfcif_2 ,cfvusr  ,cfyamt  ,cfycur  ,cfyiec'
;

z_cQuery = public.fnGenQuery4Partition('ads', 'cfysie', z_dPeriod, z_dCurrEOD, NULL, z_cColumnList);
z_cQuery = ''
|| CHR(10) || 'insert into TMP_cfysie'
|| CHR(10) || '('
|| CHR(10) || '     scd_end ,' || z_cColumnList
|| CHR(10) || ')'
|| CHR(10) || 'select'
|| CHR(10) || ' xa.scd_end'
|| CHR(10) || ',' || z_cColumnList
|| CHR(10) || 'from (' || z_cQuery || ') as xa'
|| CHR(10) || ';'
;

execute z_cQuery;

z_cErrMsg = public.serene(1, 'B300');
---- probi.cfpar2_log ----
perform public.fnDropTemporaryTable('tmp_cfpar2_log');
create temporary table tmp_cfpar2_log
(
     cp2cid     character varying
    ,cp2zip     numeric
    ,cpdtcd     numeric
    ,rowid      integer
)
distributed randomly;

insert into tmp_cfpar2_log
(
     cp2cid     ,cp2zip     ,cpdtcd
    ,rowid
)
select
     xa.cp2cid::integer as cp2cid
    ,xa.cp2zip as cp2zip
    ,xa.cpdtcd as cpdtcd
    -- ,row_number() over(partition by xa.cp2zip order by xa.cpdtcd asc) as Rowid
    ,row_number() OVER(partition by xa.hkeep_dt ,xa.cp2zip order by xa.cpdtcd asc, xa.cp2cid desc) as Rowid
from probi.cfpar2_log as xa
where xa.hkeep_dt = z_dPeriod
and xa.cpdtcd <> 0
;

delete from tmp_cfpar2_log as xz
where xz.rowid <> 1
;

----------------------------------------------------------------------------------------------------------
-- Main Process --
----------------------------------------------------------------------------------------------------------
z_cErrMsg = public.serene(1, 'C010');
-- insert debitur lama --
insert into TMP_SLIK_CustomerMaster
(
     CIF
    ,PeriodPelaporan
    ,statussyariah
    ,insertquery
)
select distinct
     xa.CIF
    ,z_dPeriod
    ,xd.statussyariah as statussyariah
    ,'IQ-01' as insertquery
from probi.slik_customermaster as xa
inner join probi.slik_customerdetail as xb
    on  xb.cif = xa.cif
    and xb.period = xa.periodpelaporan
    and xb.cifori is not null
inner join TMP_SLIK_AccountDetail as xd
    on  xd.cif = xa.cif
where xa.PeriodPelaporan < z_dPeriod
and xa.CustomerType is not NULL
;

z_cErrMsg = public.serene(1, 'C020');
-- insert debitur baru --
insert into TMP_SLIK_CustomerMaster
(
     CIF
    ,PeriodPelaporan
    ,statussyariah
    ,insertquery
)
select distinct
     xa.CIF
    ,z_dPeriod
    ,xa.statussyariah as statussyariah
    ,'IQ-02' as insertquery
from TMP_SLIK_AccountDetail as xa
left join TMP_SLIK_CustomerMaster as xb
    on xb.CIF = xa.CIF
where xb.CIF is null
and xa.period = z_dPeriod
;

z_cErrMsg = public.serene(1, 'C030');

---- update CustomerType dari TMP_datamart_customerdetail (source-nya dari cfmast) konven ----
update TMP_SLIK_CustomerMaster as xz
set
     CustomerType = xa.customertype
    ,CIFOri = xa.customerid_ori
    ,KodeKantorCabang = xa.kodekantorcabang
    ,updatequery = xz.updatequery || 'UQ-01#'
from TMP_datamart_customerdetail as xa
where xa.hkeep_dt = z_dPeriod
and xz.cif = xa.customerid_konven
;

z_cErrMsg = public.serene(1, 'C040');

---- update CustomerType dari TMP_datamart_customerdetail (source-nya dari cfmast) syariah ----
update TMP_SLIK_CustomerMaster as xz
set
     CustomerType = xa.customertype
    ,CIFOri = xa.customerid_ori
    ,KodeKantorCabang = xa.kodekantorcabang
    ,updatequery = xz.updatequery || 'UQ-02#'
from TMP_datamart_customerdetail as xa
where xa.hkeep_dt = z_dPeriod
and xz.cif = xa.customerid_syariah
;

z_cErrMsg = public.serene(1, 'C050');

---- update CustomerType yang null untuk CIF dari CustomerMaster_Prev ----
update TMP_SLIK_CustomerMaster as xz
set
     CustomerType = xa.CustomerType
    ,CIFOri = xa.CIFOri
    ,KodeKantorCabang = xa.kodekantorcabang
    ,updatequery = xz.updatequery || 'UQ-03#'
from TMP_SLIK_CustomerMaster_Prev as xa
where xz.cif = xa.cif
and xz.CustomerType is null
;

z_cErrMsg = public.serene(1, 'C060');

insert into TMP_CIFDuplikat
(
     cif
    ,cifori
    ,count
)
select distinct
     xa.cif as cif
    ,xa.cifori as cifori
    ,count(1) as count
from TMP_SLIK_CustomerMaster as xa
group by
     xa.cif
    ,xa.cifori
having count(1) > 1
;

z_cErrMsg = public.serene(1, 'C070');

---- update cif untuk yang syariah ----
update TMP_SLIK_CustomerMaster as xz
set
     cif = xb.customerid_syariah
    ,kodekantorcabang = public.util_right(xb.bibankid_syariah::character varying, 3)::character varying
    ,updatequery = xz.updatequery || 'UQ-04#'
from TMP_CIFDuplikat as xa
inner join TMP_datamart_customerdetail as xb
    on  xb.customerid_ori = xa.cifori
    and xb.customerid_syariah <> ''
where xz.statussyariah = 'Y'
and xz.cifori = xa.cifori
;

z_cErrMsg = public.serene(1, 'C080');

---- update kodekantorcabang untuk yang syariah dari accountdetail ----
update TMP_SLIK_CustomerMaster as xz
set
     kodekantorcabang = xb.kodekantorcabang
    ,updatequery = xz.updatequery || 'UQ-05#'
from TMP_CIFDuplikat as xa
inner join probi.slik_accountdetail as xb
    on  xb.period = z_dPeriod
    and xb.statussyariah = 'Y'
    and xb.cifori = xa.cifori
    and xb.form <> 'F01'
where xz.statussyariah = 'Y'
and xz.cifori = xa.cifori
;

z_cErrMsg = public.serene(1, 'C090');

---- update kodekantorcabang untuk yang syariah dari accountdetail ----
update TMP_SLIK_CustomerMaster as xz
set
     kodekantorcabang = substring(xb.bibankid::character varying, 3, 3)
    ,updatequery = xz.updatequery || 'UQ-05#'
from TMP_CIFDuplikat as xa
inner join TMPV_datamart_lv2b_accountcredit as xb
    on  xb.hkeep_dt = z_dPeriod
    and xb.deletequery_slk is null
    and substring(xb.bibankid::character varying, 3, 3)::integer >= 900
    and xb.customerid = xa.cifori
where xz.statussyariah = 'Y'
and xz.cifori = xa.cifori
;

z_cErrMsg = public.serene(1, 'C081');
-- jika statussyariah = T tetapi kodekantorcabang masuk syariah --
update TMP_SLIK_CustomerMaster as xz
set
     kodekantorcabang = xa.slikvalue
    ,updatequery = xz.updatequery || 'UQ-05.1#'
from probi.regulatory_mapping_tr as xa
where xa.mappingcode = 'cabangsyariah'
and xa.addmappingcode1 = 'konven'
and xa.isactive = 'A'
and xa.hkeep_dt = z_dPeriod
and xz.statussyariah = 'T'
and xz.kodekantorcabang = xa.hostvalue
;

z_cErrMsg = public.serene(1, 'C082');
-- jika statussyariah = Y tetapi kodekantorcabang masuk konven --
update TMP_SLIK_CustomerMaster as xz
set
     kodekantorcabang = xa.slikvalue
    ,updatequery = xz.updatequery || 'UQ-05.2#'
from probi.regulatory_mapping_tr as xa
where xa.mappingcode = 'cabangsyariah'
and xa.addmappingcode1 = 'syariah'
and xa.isactive = 'A'
and xa.hkeep_dt = z_dPeriod
and xz.statussyariah = 'Y'
and xz.kodekantorcabang = xa.hostvalue
;

z_cErrMsg = public.serene(1, 'C110');
---- insert into TMP_SLIK_CustomerDetail dari TMP_datamart_customerdetail khusus yang ada di TMP_SLIK_AccountDetail saja ----
insert into TMP_SLIK_CustomerDetail
(
     Period
    ,CustomerType
    ,CIF
    ,OfficeCIF
    ,CIFName
    ,NamaLengkap
    ,Telepon
    ,NomorTeleponGenggam
    ,AlamatEmail
    ,Alamat
    ,Kelurahan
    ,Kecamatan
    ,KodeDATIII
    ,KodePos
    ,KodeNegara
    ,KodePekerjaan -- KodeBidangUsaha
    ,MelanggarBM
    ,MelampauiBM
    ,KodeBidangUsaha -- SektorEkonomi
    ,IdNumber
    ,IDType
    ,FlagWNIWNA
    ,KodeStatusGelarDebitur
    ,JenisKelamin
    ,TempatLahirKTP
    ,TanggalLahir
    ,NPWP
    ,TempatBekerja
    ,AlamatTempatBekerja
    ,PenghasilanKotorPerTahun
    ,KodeSumberPenghasilan
    ,KodeHubungandenganLJK
    ,KodeGolonganDebitur
    ,StatusPerkawinanDebitur
    ,NamaGadisIbuKandung
    ,KodeJenisBadanUsaha
    ,CIFOri
    ,Source
    ,kodekantorcabang
    ,insertquery
    ,gopublic
    ,idgroupdebitur
    ,namagroupdebitur
    ,noaktependirian
    ,noakteperubahanterakhir
    ,peringkatdebitur
    ,lembagapemeringkat
    ,tanggalpemeringkatan
    ,nikpassportpasangan
    ,namapasangan
    ,tanggallahirpasangan
    ,perjanjianpisahharta
    ,jumlahtanggungan
    ,tanggalaktependirian
    ,tanggalakteperubahanterakhir
    ,kodejenisbadanusaha_desc
)
select distinct
     z_dPeriod as Period
    ,xa.customertype as CustomerType
    ,xa.cif as CIF
    ,xc.officecustomer as OfficeCIF
    ,xc.customername as CIFName
    ,xc.namalengkap as NamaLengkap
    ,xc.telepon as Telepon
    ,xc.nomortelepongenggam as NomorTeleponGenggam
    ,xc.alamatemail as AlamatEmail
    ,xc.alamat as Alamat
    ,xc.kelurahan as Kelurahan
    ,xc.kecamatan as Kecamatan
    ,xc.kodedatiii as KodeDATIII
    ,xc.kodepos as KodePos
    ,xc.kodenegara as KodeNegara
    ,xc.kodepekerjaan as KodePekerjaan -- KodeBidangUsaha
    ,xc.melanggarbm as MelanggarBM
    ,xc.melampauibm as MelampauiBM
    ,xc.kodebidangusaha as KodeBidangUsaha -- SektorEkonomi
    ,xc.idnumber as IdNumber
    ,xc.idtype as IDType
    ,xc.flagwniwna as FlagWNIWNA
    ,xc.kodestatusgelardebitur as KodeStatusGelarDebitur -- A = SD, B = SMP, C = SMA, D = Diploma, E = S1, F = S2, G = S3, X = Taman Bermain/PAUD, Y = Taman Kanak-Kanak, Z = Lainnya
    ,xc.jeniskelamin as JenisKelamin -- Male = M, Female = F
    ,xc.tempatlahirktp as TempatLahirKTP
    ,xc.tanggallahir as TanggalLahir
    ,xc.npwp as NPWP
    ,xc.tempatbekerja as TempatBekerja
    ,xc.alamattempatbekerja as AlamatTempatBekerja
    ,xc.penghasilankotorpertahun as PenghasilanKotorPerTahun
    ,xc.kodesumberpenghasilan as KodeSumberPenghasilan
    ,xc.kodehubungandenganljk as KodeHubungandenganLJK
    ,xc.kodegolongandebitur as KodeGolonganDebitur
    ,xc.statusperkawinandebitur as StatusPerkawinanDebitur -- Kawin (A) = 1, Belum Kawin (B) = 2, Cerai (C) = 3
    ,xc.namagadisibukandung as NamaGadisIbuKandung
    ,xc.kodejenisbadanusaha as KodeJenisBadanUsaha
    ,xa.cifori as CIFOri
    ,'datamart' as Source
    ,xa.kodekantorcabang as kodekantorcabang
    ,'IQ-01' as insertquery
    ,xc.gopublic as gopublic
    ,xc.idgroupdebitur as idgroupdebitur
    ,xc.namagroupdebitur as namagroupdebitur
    ,xc.noaktependirian as noaktependirian
    ,xc.noakteperubahanterakhir as noakteperubahanterakhir
    ,xc.peringkatdebitur as peringkatdebitur
    ,xc.lembagapemeringkat as lembagapemeringkat
    ,xc.tanggalpemeringkatan as tanggalpemeringkatan
    ,xc.nikpassportpasangan as nikpassportpasangan
    ,xc.namapasangan as namapasangan
    ,xc.tanggallahirpasangan as tanggallahirpasangan
    ,xc.perjanjianpisahharta as perjanjianpisahharta
    ,xc.jumlahtanggungan as jumlahtanggungan
    ,xc.tanggalaktependirian as tanggalaktependirian
    ,xc.tanggalakteperubahanterakhir as tanggalakteperubahanterakhir
    ,xc.kodejenisbadanusaha_desc as kodejenisbadanusaha_desc
from TMP_SLIK_CustomerMaster as xa
inner join TMP_SLIK_AccountDetail as xb
    on  xb.period = z_dPeriod
    and xb.cif = xa.cif
inner join TMP_datamart_customerdetail as xc
    on  xc.hkeep_dt = z_dPeriod
    and xc.customerid_ori = xa.cifori
;

z_cErrMsg = public.serene(1, 'C120');
---- insert into TMP_SLIK_CustomerDetail dari TMP_SLIK_CustomerMaster yang CIF-nya tidak ada di ads. cfmast ----
insert into TMP_SLIK_CustomerDetail
(
     Period
    ,CustomerType
    ,CIF
    ,OfficeCIF
    ,CIFName
    ,NamaLengkap
    ,Telepon
    ,NomorTeleponGenggam
    ,AlamatEmail
    ,Alamat
    ,Kelurahan
    ,Kecamatan
    ,KodeDATIII
    ,KodePos
    ,KodeNegara
    ,KodePekerjaan -- KodeBidangUsaha
    ,MelanggarBM
    ,MelampauiBM
    ,KodeBidangUsaha -- SektorEkonomi
    ,IdNumber
    ,IDType
    ,FlagWNIWNA
    ,KodeStatusGelarDebitur
    ,JenisKelamin
    ,TempatLahirKTP
    ,TanggalLahir
    ,NPWP
    ,TempatBekerja
    ,AlamatTempatBekerja
    ,PenghasilanKotorPerTahun
    ,KodeSumberPenghasilan
    ,KodeHubungandenganLJK
    ,KodeGolonganDebitur
    ,StatusPerkawinanDebitur
    ,NamaGadisIbuKandung
    ,KodeJenisBadanUsaha
    ,Source
    ,kodekantorcabang
    ,insertquery
    ,gopublic
    ,idgroupdebitur
    ,namagroupdebitur
    ,noaktependirian
    ,noakteperubahanterakhir
    ,peringkatdebitur
    ,lembagapemeringkat
    ,tanggalpemeringkatan
    ,nikpassportpasangan
    ,namapasangan
    ,tanggallahirpasangan
    ,perjanjianpisahharta
    ,jumlahtanggungan
    ,tanggalaktependirian
    ,tanggalakteperubahanterakhir
    ,kodejenisbadanusaha_desc
)
select distinct
     z_dPeriod as Period
    ,xa.CustomerType as CustomerType
    ,xa.CIF as CIF
    ,'' as OfficeCIF
    ,'' as CIFName
    ,'' as NamaLengkap
    ,'0' as Telepon
    ,'' as NomorTeleponGenggam
    ,'' as AlamatEmail
    ,'' as Alamat
    ,'' as Kelurahan
    ,'' as Kecamatan
    ,'' as KodeDATIII
    ,'' as KodePos
    ,'' as KodeNegara
    ,'' as KodePekerjaan -- KodeBidangUsaha
    ,'' as MelanggarBM
    ,'' as MelampauiBM
    ,'' as KodeBidangUsaha -- SektorEkonomi
    ,'' as IdNumber
    ,'' as IDType
    ,'' as FlagWNIWNA
    ,'' as KodeStatusGelarDebitur -- A = SD, B = SMP, C = SMA, D = Diploma, E = S1, F = S2, G = S3, X = Taman Bermain/PAUD, Y = Taman Kanak-Kanak, Z = Lainnya
    ,'' as JenisKelamin -- Male = M, Female = F
    ,'' as TempatLahirKTP
    ,'19000101'::date as TanggalLahir
    ,'' as NPWP
    ,'' as TempatBekerja
    ,'' as AlamatTempatBekerja
    ,0 as PenghasilanKotorPerTahun
    ,'' as KodeSumberPenghasilan
    ,'' as KodeHubungandenganLJK
    ,'' as KodeGolonganDebitur
    ,'' as StatusPerkawinanDebitur -- Kawin (A) = 1, Belum Kawin (B) = 2, Cerai (C) = 3
    ,'' as NamaGadisIbuKandung
    ,'' as KodeJenisBadanUsaha
    ,'master' as source
    ,xa.kodekantorcabang as kodekantorcabang
    ,'IQ-02' as insertquery
    ,'' as gopublic
    ,0 as idgroupdebitur
    ,'' as namagroupdebitur
    ,'' as noaktependirian
    ,'' as noakteperubahanterakhir
    ,'' as peringkatdebitur
    ,'' as lembagapemeringkat
    ,'19000101'::date as tanggalpemeringkatan
    ,'' as nikpassportpasangan
    ,'' as namapasangan
    ,'19000101'::date as tanggallahirpasangan
    ,'' as perjanjianpisahharta
    ,0 as jumlahtanggungan
    ,'19000101'::date as tanggalaktependirian
    ,'19000101'::date as tanggalakteperubahanterakhir
    ,'' as kodejenisbadanusaha_desc
from TMP_SLIK_CustomerMaster as xa
left join TMP_SLIK_CustomerDetail as xb
    on  xb.CIF = xa.CIF
    and xb.kodekantorcabang = xa.kodekantorcabang
where xa.CustomerType is not NULL
and xb.CIF is NULL
;

z_cErrMsg = public.serene(1, 'C130');
---- update IDType, IdNumber dari ads. cfmast berdasarkan FlagWNIWNA yang debitur perorangan WNI ----
update TMP_SLIK_CustomerDetail as xz
set
     IDType = xa.cfsscd
    ,IdNumber = xa.cfssno
    ,updatequery = xz.updatequery || 'UQ-01#'
from TMPV_cfmast as xa
where xa.scd_end = z_dPeriod
and xa.cfsscd in
(
     'KTP', 'KTPS'
)
and xz.FlagWNIWNA = 'WNI'
and xz.CustomerType = 'A'
and xz.cifori = xa.cfcif_2
;

z_cErrMsg = public.serene(1, 'C140');
---- update IDType, IdNumber dari ads. cfmast berdasarkan FlagWNIWNA yang debitur perorangan WNA ----
update TMP_SLIK_CustomerDetail as xz
set
     IDType = xa.cfsscd
    ,IdNumber = xa.cfssno
    ,updatequery = xz.updatequery || 'UQ-02#'
from TMPV_cfmast as xa
where xa.scd_end = z_dPeriod
and xa.cfsscd in
(
     'PP'
)
and xz.FlagWNIWNA = 'WNA'
and xz.CustomerType = 'A'
and xz.cifori = xa.cfcif_2
;

z_cErrMsg = public.serene(1, 'C150');
---- update IDType, IdNumber dari ads. cfaidn_distinct_v berdasarkan FlagWNIWNA yang debitur perorangan WNI ----
update TMP_SLIK_CustomerDetail as xz
set
     IDType = xa.cfsscd
    ,IdNumber = xa.cfssno
    ,updatequery = xz.updatequery || 'UQ-03#'
from ads.cfaidn_distinct_year_v as xa
where xa.scd_end = z_dPeriod
and xa.cfsscd in
(
     'KTP', 'KTPS'
)
and xz.FlagWNIWNA = 'WNI'
and xz.CustomerType = 'A'
and coalesce(xz.IDType, '') = ''
and xz.cifori = xa.cfcif_2
;

z_cErrMsg = public.serene(1, 'C160');
---- update IDType, IdNumber dari ads. cfaidn_distinct_v berdasarkan FlagWNIWNA yang debitur perorangan WNA ----
update TMP_SLIK_CustomerDetail as xz
set
     IDType = xa.cfsscd
    ,IdNumber = xa.cfssno
    ,updatequery = xz.updatequery || 'UQ-04#'
from ads.cfaidn_distinct_year_v as xa
where xa.scd_end = z_dPeriod
and xa.cfsscd in
(
     'PP'
)
and xz.FlagWNIWNA = 'WNA'
and xz.CustomerType = 'A'
and coalesce(xz.IDType, '') = ''
and xz.cifori = xa.cfcif_2
;

z_cErrMsg = public.serene(1, 'C170');
--ini untuk idtype munculin dulu saja semua nya untuk yang selain KTP, KTPS, PP --> biar ketahuan tidak ada mappingnya
--KITS -- kartu izin tinggal terbatas
update TMP_SLIK_CustomerDetail as xz
set
     IDType = xa.cfsscd
    ,IdNumber = xa.cfssno
    ,updatequery = xz.updatequery || 'UQ-05#'
from TMPV_cfmast as xa
where xa.scd_end = z_dPeriod
and xa.cfsscd in
(
     'KIMS' -- kartu izin menetap sementara
    ,'KITS' -- kartu izin tinggal terbatas
)
and xz.FlagWNIWNA = 'WNA'
and xz.CustomerType = 'A'
and coalesce(xz.IDType, '') = ''
and xz.cifori = xa.cfcif_2
;

z_cErrMsg = public.serene(1, 'C180');
--ini untuk idtype munculin dulu saja semua nya untuk yang selain KTP, KTPS, PP --> biar ketahuan tidak ada mappingnya
update TMP_SLIK_CustomerDetail as xz
set
     IDType = xa.cfsscd
    ,IdNumber = xa.cfssno
    ,updatequery = xz.updatequery || 'UQ-06#'
from TMPV_cfmast as xa
where xa.scd_end = z_dPeriod
and xz.FlagWNIWNA = 'WNI'
and xz.CustomerType = 'A'
and coalesce(xz.IDType, '') = ''
and xz.cifori = xa.cfcif_2
;

z_cErrMsg = public.serene(1, 'C190');
---- update IDType, IdNumber dari ads. cfaidn_distinct_v untuk debitur badan usaha ----
update TMP_SLIK_CustomerDetail as xz
set
     IDType = xa.cfsscd
    ,IdNumber = xa.cfssno
    ,updatequery = xz.updatequery || 'UQ-07#'
from ads.cfaidn_distinct_year_v as xa
where xa.scd_end = z_dPeriod
and xa.cfsscd in
(
     'NPWP'
)
and xz.CustomerType <> 'A'
and xz.cifori = xa.cfcif_2
;

z_cErrMsg = public.serene(1, 'C200');
---- update NPWP dari ads. cfmast yang cfsscd = NPWP ----
update TMP_SLIK_CustomerDetail as xz
set
     NPWP = xa.cfssno
    ,updatequery = xz.updatequery || 'UQ-08#'
from TMPV_cfmast as xa
where xa.scd_end = z_dPeriod
and xa.cfsscd in
(
     'NPWP'
)
and xz.cifori = xa.cfcif_2
;

z_cErrMsg = public.serene(1, 'C210');
---- update NPWP dari ads. cfaidn_distinct_v yang cfsscd = NPWP dan masih kosong ----
update TMP_SLIK_CustomerDetail as xz
set
     NPWP = xa.cfssno
    ,updatequery = xz.updatequery || 'UQ-09#'
from ads.cfaidn_distinct_year_v as xa
where xa.scd_end = z_dPeriod
and xa.cfsscd in
(
     'NPWP'
)
and coalesce(xz.NPWP, '') = ''
and  xz.cifori = xa.cfcif_2
;


z_cErrMsg = public.serene(1, 'C390');
---- update AlamatEmail dari ads. cfconn_distinct_v yang cfeadc = EM ----
update TMP_SLIK_CustomerDetail as xz
set
     AlamatEmail = xa.cfeadd
    ,updatequery = xz.updatequery || 'UQ-27#'
from ads.cfconn_distinct_year_v as xa
where xa.scd_end = z_dPeriod
and xa.cfeadc = 'EM'
and xz.cifori = xa.cfcif_2
;


z_cErrMsg = public.serene(1, 'C440');
---- update KodeBidangUsaha dari ads. cfzemp_distinct_v untuk debitur perorangan ----
update TMP_SLIK_CustomerDetail as xz
set
     KodeBidangUsaha = public.util_right('0000' || COALESCE(xa.cfenin, ''), 4) -- SektorEkonomi
    ,updatequery = xz.updatequery || 'UQ-32#'
from ads.cfzemp_distinct_year_v as xa
where xa.scd_end = z_dPeriod
and xz.CustomerType = 'A'
and xz.cifori = xa.cfcif_2
;

z_cErrMsg = public.serene(1, 'C450');
---- update KodeBidangUsaha dari ads. cfbicd untuk debitur badan usaha ----
update TMP_SLIK_CustomerDetail as xz
set
     KodeBidangUsaha = public.util_right('0000' || COALESCE(xa.bijdsn, 0)::character varying, 4) -- SektorEkonomi
    ,updatequery = xz.updatequery || 'UQ-33#'
from TMPV_cfbicd as xa
where xa.scd_end = z_dPeriod
and xz.CustomerType <> 'A'
and xz.cifori = xa.cfcif_2
;

z_cErrMsg = public.serene(1, 'C460');
---- update KodePekerjaan dari ads. cfzemp_distinct_v ----
update TMP_SLIK_CustomerDetail as xz
set
     KodePekerjaan = COALESCE(xa.cfoccd, '') -- KodeBidangUsaha
    ,updatequery = xz.updatequery || 'UQ-34#'
from ads.cfzemp_distinct_year_v as xa
where xa.scd_end = z_dPeriod
and xz.CustomerType = 'A'
and xz.cifori = xa.cfcif_2
;

z_cErrMsg = public.serene(1, 'C470');
---- update TempatBekerja dari ads. cfzemp_distinct_v ----
update TMP_SLIK_CustomerDetail as xz
set
     TempatBekerja = case when xa.cfena1 like '%TIDAK%' or xa.cfena1 like '%N/A%' then 'NA'
                     else xa.cfena1 end
    ,updatequery = xz.updatequery || 'UQ-35#'
from ads.cfzemp_distinct_year_v as xa
where xa.scd_end = z_dPeriod
and xz.cifori = xa.cfcif_2
;




z_cErrMsg = public.serene(1, 'C575');

z_cErrMsg = public.serene(1, 'C580');
---- update MelanggarBM, MelampauiBM ----
update TMP_SLIK_CustomerDetail as xz
set
     MelanggarBM = 'T'
    ,MelampauiBM = 'T'
    ,updatequery = xz.updatequery || 'UQ-38#'
;

z_cErrMsg = public.serene(1, 'C590');

update TMP_SLIK_CustomerDetail as xz
set
     IDType = case
                when COALESCE(xb.national_id_type, '') = '' then xz.IDType
                else xb.national_id_type
              end
    ,IdNumber = case
                    when COALESCE(xb.NATIONAL_ID, '') = '' then xz.IdNumber
                    else xb.NATIONAL_ID
                end
    ,NamaLengkap = case
                      when COALESCE(xb.NAME, '') = '' then xz.NamaLengkap
                      else xb.NAME
                   end
    ,KodeStatusGelarDebitur = case
                                when COALESCE(xb.EDUCATION_LVL_ACHV, '') = '' then xz.KodeStatusGelarDebitur
                                else xb.EDUCATION_LVL_ACHV
                              end
    ,JenisKelamin = case
                        when COALESCE(xb.SEX, '') = '' then xz.JenisKelamin
                        else xb.SEX
                    end
    ,TempatLahirKTP = case
                        when COALESCE(xb.BIRTHPLACE, '') = '' then xz.TempatLahirKTP
                        else xb.BIRTHPLACE
                      end
    ,TanggalLahir = case
                        when COALESCE(xb.BIRTHDATE::date, '19000101'::date) = '19000101'::date then xz.TanggalLahir
                        else xb.BIRTHDATE::date
                    end
    ,NPWP = case
                when COALESCE(xb.IDN_TAX_EE_ID, '') = '' then  xz.NPWP
                else xb.IDN_TAX_EE_ID
            end
    ,Alamat = case
                  when COALESCE(xb.ADDRESSLONG, '') = '' then xz.Alamat
                  else xb.ADDRESSLONG
              end
    ,Kelurahan = case
                    when COALESCE(xb.ADDRESS3, '') = '' then xz.Kelurahan
                    else xb.ADDRESS3
                 end
    ,Kecamatan = case
                    when COALESCE(xb.ADDRESS4, '') = '' then xz.Kecamatan
                    else xb.ADDRESS4
                 end
    ,KodePos = case
                    when COALESCE(xb.POSTAL, '') = '' then xz.KodePos
                    else xb.POSTAL
               end
    ,Telepon = case
                    when COALESCE(xb.PHONE,'') = '' then
                        case when COALESCE(xz.Telepon,'') = '' then '0'
                             else xz.Telepon
                        end
                    else xb.PHONE
               end
    ,NomorTeleponGenggam = case
                                when COALESCE(xb.PHONE1,'') = '' then
                                    case when COALESCE(xz.NomorTeleponGenggam,'') = '' then '0'
                                         else xz.NomorTeleponGenggam
                                    end
                                else xb.PHONE1
                           end
    ,AlamatEmail = case
                        when COALESCE(xb.EMAIL_ADDR, '') = '' then xz.AlamatEmail
                        else xb.EMAIL_ADDR
                   end
    ,KodeNegara = 'ID'
    ,KodePekerjaan = '099'
    ,TempatBekerja = case
                        when COALESCE(xb.DESCR, '') = '' then xz.TempatBekerja
                        else xb.DESCR
                     end
    ,KodeBidangUsaha = '641000'
    ,AlamatTempatBekerja = case
                                when COALESCE(xb.ADDRESSLONG10, '') =  '' then xz.AlamatTempatBekerja
                                else xb.ADDRESSLONG10
                           end
    ,PenghasilanKotorPerTahun = case
                                    when COALESCE(xb.ANNUAL_RT, 0) = 0 then xz.PenghasilanKotorPerTahun
                                    else xb.ANNUAL_RT
                                end
    ,KodeSumberPenghasilan = '1'
    -- ,KodeHubungandenganLJK = '9900'
    ,KodeGolonganDebitur = '9000'
    ,MelanggarBM = 'T'
    ,MelampauiBM = 'T'
    ,NamaGadisIbuKandung = case
                                when COALESCE(xb.NAME2, '') = '' then xz.NamaGadisIbuKandung
                                else xb.NAME2
                           end
    ,Source = 'ps'
    ,updatequery = xz.updatequery || 'UQ-39#'
from TMP_ps_n_debtur_org_slik_vw as xb
where xb.load_dt = z_dPeriodHC
and xz.cifori = xb.c_cif_nbr
;

z_cErrMsg = public.serene(1, 'C600');
---- update KodeDATIII dari ads. cfpar2 ----
update TMP_SLIK_CustomerDetail as xz
set
     KodeDATIII = public.util_right('0000' || COALESCE(COALESCE(xb.cpdtcd::character varying, xz.KodeDATIII), '0')::character varying, 4)
    ,updatequery = xz.updatequery || 'UQ-40#'
from tmp_cfpar2_log as xb -- supaya tidak multiple update, ikuti cara di datamart_customerdetail --
where
(
       coalesce(xz.KodeDATIII, '') = ''
    or xz.KodeDATIII = '0000'
)
and xz.KodePos = xb.cp2zip
;

-- pindahan dari atas
z_cErrMsg = public.serene(1, 'C431');

---- update KodeDATIII saja dari cfbicd ----
update TMP_SLIK_CustomerDetail as xz
set
     KodeDATIII = public.util_right('0000' || COALESCE(xa.bilok1, 0)::character varying, 4)
    ,updatequery = xz.updatequery || 'UQ-31.1#'
from TMPV_cfbicd as xa
where xa.scd_end = z_dPeriod
and
(
       coalesce(xz.KodeDATIII, '') = ''
    or xz.KodeDATIII = '0000'
)
and xz.cifori = xa.cfcif_2
;

z_cErrMsg = public.serene(1, 'C610');
-- untuk cif yang ada di ads. cfmast statusnya konven, jika ada yang office nya Syariah, update ke phisicalbranch
update TMP_SLIK_CustomerDetail as xz
set
     OfficeCIF = xb.physicalbranch
    ,updatequery = xz.updatequery || 'UQ-41#'
from TMPV_cfmast as xa
inner join tmp_misofficeinformation as xb
    on  xb.scd_end = xa.scd_end
    and coalesce(xb.physicalbranch, '') <> ''
    and coalesce(xb.physicalbranch, '') <> '0' -- jangan ambil yang 0 juga --
    and xb.office_id = xa.cfbrnn
where xa.scd_end = z_dPeriod
and length(xz.OfficeCIF) = 5
and xz.OfficeCIF like '7%'
and xz.cifori = xa.cfcif_2
;

z_cErrMsg = public.serene(1, 'C620');
---- update Data di TMP_SLIK_CustomerDetail berdasarkan CIF dari TMP_SLIK_CustomerDetail_Prev yang tidak ada di bulan sekarang & ads. cfmast ----
update TMP_SLIK_CustomerDetail as xz
set
     CIFName = case when COALESCE(TRIM(xz.CIFName), '') = '' and COALESCE(TRIM(xa.CIFName), '') <> '' then xa.CIFName
               else xz.CIFName end
    ,NamaLengkap = case when COALESCE(TRIM(xz.NamaLengkap), '') = '' and COALESCE(TRIM(xa.NamaLengkap), '') <> '' then xa.NamaLengkap
                   else xz.NamaLengkap end
    ,Telepon = case when COALESCE(TRIM(xz.Telepon), '') = '' and COALESCE(TRIM(xa.Telepon), '') <> '' then xa.Telepon
                   else xz.Telepon end
    ,NomorTeleponGenggam = case when COALESCE(TRIM(xz.NomorTeleponGenggam), '') = '' and COALESCE(TRIM(xa.NomorTeleponGenggam), '') <> '' then xa.NomorTeleponGenggam
                   else xz.NomorTeleponGenggam end
    ,AlamatEmail = case when COALESCE(TRIM(xz.AlamatEmail), '') = '' and COALESCE(TRIM(xa.AlamatEmail), '') <> '' then xa.AlamatEmail
                   else xz.AlamatEmail end
    ,Alamat = case when COALESCE(TRIM(xz.Alamat), '') = '' and COALESCE(TRIM(xa.Alamat), '') <> '' then xa.Alamat
                   else xz.Alamat end
    ,Kelurahan = case when COALESCE(TRIM(xz.Kelurahan), '') = '' and COALESCE(TRIM(xa.Kelurahan), '') <> '' then xa.Kelurahan
                   else xz.Kelurahan end
    ,Kecamatan = case when COALESCE(TRIM(xz.Kecamatan), '') = '' and COALESCE(TRIM(xa.Kecamatan), '') <> '' then xa.Kecamatan
                   else xz.Kecamatan end
    ,KodeDATIII = case when COALESCE(TRIM(xz.KodeDATIII), '') = '' and COALESCE(TRIM(xa.KodeDATIII), '') <> '' then xa.KodeDATIII
                   else xz.KodeDATIII end
    ,KodePos = case when COALESCE(TRIM(xz.KodePos), '') = '' and COALESCE(TRIM(xa.KodePos), '') <> '' then xa.KodePos
                   else xz.KodePos end
    ,KodeNegara = case when COALESCE(TRIM(xz.KodeNegara), '') = '' and COALESCE(TRIM(xa.KodeNegara), '') <> '' then xa.KodeNegara
                   else xz.KodeNegara end
    ,KodePekerjaan = case when COALESCE(TRIM(xz.KodePekerjaan), '') = '' and COALESCE(TRIM(xa.KodePekerjaan), '') <> '' then xa.KodePekerjaan
                   else xz.KodePekerjaan end -- KodeBidangUsaha
    ,KodeBidangUsaha = case when COALESCE(TRIM(xz.KodeBidangUsaha), '') = '' and COALESCE(TRIM(xa.KodeBidangUsaha), '') <> '' then xa.KodeBidangUsaha
                   else xz.KodeBidangUsaha end -- SektorEkonomi
    ,IdNumber = case when COALESCE(TRIM(xz.IdNumber), '') = '' and COALESCE(TRIM(xa.IdNumber), '') <> '' then xa.IdNumber
                   else xz.IdNumber end
    ,IDType = case when COALESCE(TRIM(xz.IDType), '') = '' and COALESCE(TRIM(xa.IDType), '') <> '' then xa.IDType
                   else xz.IDType end
    ,KodeStatusGelarDebitur = case when COALESCE(TRIM(xz.KodeStatusGelarDebitur), '') = '' and COALESCE(TRIM(xa.KodeStatusGelarDebitur), '') <> '' then xa.KodeStatusGelarDebitur
                   else xz.KodeStatusGelarDebitur end -- A = SD, B = SMP, C = SMA, D = Diploma, E = S1, F = S2, G = S3, X = Taman Bermain/PAUD, Y = Taman Kanak-Kanak, Z = Lainnya
    ,JenisKelamin = case when COALESCE(TRIM(xz.JenisKelamin), '') = '' and COALESCE(TRIM(xa.JenisKelamin), '') <> '' then xa.JenisKelamin
                   else xz.JenisKelamin end -- Male = M, Female = F
    ,TempatLahirKTP = case when COALESCE(TRIM(xz.TempatLahirKTP), '') = '' and COALESCE(TRIM(xa.TempatLahirKTP), '') <> '' then xa.TempatLahirKTP
                   else xz.TempatLahirKTP end
    ,TanggalLahir = case when COALESCE(xz.TanggalLahir, '19000101'::date) = '19000101'::date and COALESCE(xa.TanggalLahir, '19000101'::date) <> '19000101'::date then xa.TanggalLahir
                   else xz.TanggalLahir end
    ,NPWP = case when COALESCE(TRIM(xz.NPWP), '') = '' and COALESCE(TRIM(xa.NPWP), '') <> '' then xa.NPWP
                   else xz.NPWP end
    ,TempatBekerja = case when COALESCE(TRIM(xz.TempatBekerja), '') = '' and COALESCE(TRIM(xa.TempatBekerja), '') <> '' then xa.TempatBekerja
                   else xz.TempatBekerja end
    ,AlamatTempatBekerja = case when COALESCE(TRIM(xz.AlamatTempatBekerja), '') = '' and COALESCE(TRIM(xa.AlamatTempatBekerja), '') <> '' then xa.AlamatTempatBekerja
                   else xz.AlamatTempatBekerja end
    ,KodeHubungandenganLJK = case when COALESCE(TRIM(xz.KodeHubungandenganLJK), '') = '' and COALESCE(TRIM(xa.KodeHubungandenganLJK), '') <> '' then xa.KodeHubungandenganLJK
                   else xz.KodeHubungandenganLJK end
    ,KodeGolonganDebitur = case when COALESCE(TRIM(xz.KodeGolonganDebitur), '') = '' and COALESCE(TRIM(xa.KodeGolonganDebitur), '') <> '' then xa.KodeGolonganDebitur
                   else xz.KodeGolonganDebitur end
    ,StatusPerkawinanDebitur = case when COALESCE(TRIM(xz.StatusPerkawinanDebitur), '') = '' and COALESCE(TRIM(xa.StatusPerkawinanDebitur), '') <> '' then xa.StatusPerkawinanDebitur
                   else xz.StatusPerkawinanDebitur end -- Kawin (A) = 1, Belum Kawin (B) = 2, Cerai (C) = 3
    ,NamaGadisIbuKandung = case when COALESCE(TRIM(xz.NamaGadisIbuKandung), '') = '' and COALESCE(TRIM(xa.NamaGadisIbuKandung), '') <> '' then xa.NamaGadisIbuKandung
                   else xz.NamaGadisIbuKandung end
    ,KodeJenisBadanUsaha = case when COALESCE(TRIM(xz.KodeJenisBadanUsaha), '') = '' and COALESCE(TRIM(xa.KodeJenisBadanUsaha), '') <> '' then xa.KodeJenisBadanUsaha
                   else xz.KodeJenisBadanUsaha end
    ,kodejenisbadanusaha_desc = case
                                    when coalesce(trim(xz.kodejenisbadanusaha_desc), '') = '' and coalesce(trim(xa.kodejenisbadanusaha_desc), '') <> '' then xa.kodejenisbadanusaha_desc
                                    else xz.kodejenisbadanusaha_desc
                                end
    ,updatequery = xz.updatequery || 'UQ-42#'
from TMP_SLIK_CustomerDetail_Prev as xa
where xa.period = z_dPeriodLastEOM
and xz.cif = xa.cif
and xz.OfficeCIF = xa.OfficeCIF
;

z_cErrMsg = public.serene(1, 'C630');


z_cErrMsg = public.serene(1, 'C680');

update TMP_SLIK_CustomerDetail as xz
set
     idnumber = replace(xz.idnumber, ' ', '')
    ,updatequery = xz.updatequery || 'UQ-48#'
where coalesce(xz.idnumber, '') <> ''
;

z_cErrMsg = public.serene(1, 'C690');

update TMP_SLIK_CustomerDetail as xz
set
     npwp = replace(xz.npwp, ' ', '')
    ,updatequery = xz.updatequery || 'UQ-49#'
where coalesce(xz.npwp, '') <> ''
;


z_cErrMsg = public.serene(1, 'C770');


---- delete Data di TMP_SLIK_CustomerDetail yang duplikat ----
z_cErrMsg = public.serene(1, 'C790');
-- TMP_SLIK_CustomerDetailDuplikat --
perform public.fnDropTemporaryTable('TMP_SLIK_CustomerDetailDuplikat');
create temporary table TMP_SLIK_CustomerDetailDuplikat
(
     Period                     date
    ,CustomerType               character varying
    ,CIF                        character varying
    ,OfficeCIF                  character varying
    ,CIFName                    character varying
    ,NamaLengkap                character varying
    ,Telepon                    character varying
    ,NomorTeleponGenggam        character varying
    ,AlamatEmail                character varying
    ,Alamat                     character varying
    ,Kelurahan                  character varying
    ,Kecamatan                  character varying
    ,KodeDATIII                 character varying
    ,KodePos                    character varying
    ,KodeNegara                 character varying
    ,KodePekerjaan              character varying -- KodeBidangUsaha
    ,MelanggarBM                character varying
    ,MelampauiBM                character varying
    ,KodeBidangUsaha            character varying -- SektorEkonomi
    ,IdNumber                   character varying
    ,IDType                     character varying
    ,FlagWNIWNA                 character varying
    ,KodeStatusGelarDebitur     character varying
    ,JenisKelamin               character varying
    ,TempatLahirKTP             character varying
    ,TanggalLahir               date
    ,NPWP                       character varying
    ,TempatBekerja              character varying
    ,AlamatTempatBekerja        character varying
    ,PenghasilanKotorPerTahun   numeric
    ,KodeSumberPenghasilan      character varying
    ,KodeHubungandenganLJK      character varying
    ,KodeGolonganDebitur        character varying
    ,StatusPerkawinanDebitur    character varying
    ,NamaGadisIbuKandung        character varying
    ,KodeJenisBadanUsaha        character varying
    ,CIFOri                     character varying
    ,Source                     character varying
    ,rowid                      integer
    ,lastchangeduser            character varying
    ,kodekantorcabang               character varying
    ,insertquery                    character varying
    ,updatequery                    character varying default ''
    ,deletequery                    character varying
    ,gopublic                       character varying
    ,idgroupdebitur                 numeric(10,0)
    ,namagroupdebitur               character varying
    ,noaktependirian                character varying
    ,noakteperubahanterakhir        character varying
    ,peringkatdebitur               character varying
    ,lembagapemeringkat             character varying
    ,tanggalpemeringkatan           date
    ,nikpassportpasangan            character varying
    ,namapasangan                   character varying
    ,tanggallahirpasangan           date
    ,perjanjianpisahharta           character varying
    ,jumlahtanggungan               integer
    ,tanggalaktependirian           date
    ,tanggalakteperubahanterakhir   date
    ,kodejenisbadanusaha_desc       character varying
)
distributed randomly;

z_cErrMsg = public.serene(1, 'C800');

insert into TMP_SLIK_CustomerDetailDuplikat
(
     Period                     ,CIF                    ,OfficeCIF              ,CIFName                ,NamaLengkap                ,Telepon                ,NomorTeleponGenggam
    ,AlamatEmail                ,Alamat                 ,Kelurahan              ,Kecamatan              ,KodeDATIII                 ,KodePos                ,KodeNegara
    ,KodePekerjaan              ,MelanggarBM            ,MelampauiBM            ,KodeBidangUsaha        ,IdNumber                   ,IDType                 ,FlagWNIWNA
    ,KodeStatusGelarDebitur     ,JenisKelamin           ,TempatLahirKTP         ,TanggalLahir           ,NPWP                       ,TempatBekerja          ,AlamatTempatBekerja
    ,PenghasilanKotorPerTahun   ,KodeSumberPenghasilan  ,KodeHubungandenganLJK  ,KodeGolonganDebitur    ,StatusPerkawinanDebitur    ,NamaGadisIbuKandung    ,KodeJenisBadanUsaha
    ,CIFOri                     ,Source                 ,rowid
    ,kodekantorcabang
    ,insertquery
    ,gopublic
    ,idgroupdebitur
    ,namagroupdebitur
    ,noaktependirian
    ,noakteperubahanterakhir
    ,peringkatdebitur
    ,lembagapemeringkat
    ,tanggalpemeringkatan
    ,nikpassportpasangan
    ,namapasangan
    ,tanggallahirpasangan
    ,perjanjianpisahharta
    ,jumlahtanggungan
    ,tanggalaktependirian
    ,tanggalakteperubahanterakhir
    ,updatequery
    ,kodejenisbadanusaha_desc
)
select distinct
     xa.Period
    ,xa.CIF
    ,xa.OfficeCIF
    ,xa.CIFName
    ,xa.NamaLengkap
    ,xa.Telepon
    ,xa.NomorTeleponGenggam
    ,xa.AlamatEmail
    ,xa.Alamat
    ,xa.Kelurahan
    ,xa.Kecamatan
    ,xa.KodeDATIII
    ,xa.KodePos
    ,xa.KodeNegara
    ,xa.KodePekerjaan -- KodeBidangUsaha
    ,xa.MelanggarBM
    ,xa.MelampauiBM
    ,xa.KodeBidangUsaha -- SektorEkonomi
    ,xa.IdNumber
    ,xa.IDType
    ,xa.FlagWNIWNA
    ,xa.KodeStatusGelarDebitur
    ,xa.JenisKelamin
    ,xa.TempatLahirKTP
    ,xa.TanggalLahir
    ,xa.NPWP
    ,xa.TempatBekerja
    ,xa.AlamatTempatBekerja
    ,xa.PenghasilanKotorPerTahun
    ,xa.KodeSumberPenghasilan
    ,xa.KodeHubungandenganLJK
    ,xa.KodeGolonganDebitur
    ,xa.StatusPerkawinanDebitur
    ,xa.NamaGadisIbuKandung
    ,xa.KodeJenisBadanUsaha
    ,xa.CIFOri
    ,xa.Source
    ,ROW_NUMBER() OVER (partition by xa.cif ,xa.kodekantorcabang order by xa.period desc) as rowid
    ,xa.kodekantorcabang as kodekantorcabang
    ,xa.insertquery as insertquery
    ,xa.gopublic as gopublic
    ,xa.idgroupdebitur as idgroupdebitur
    ,xa.namagroupdebitur as namagroupdebitur
    ,xa.noaktependirian as noaktependirian
    ,xa.noakteperubahanterakhir as noakteperubahanterakhir
    ,xa.peringkatdebitur as peringkatdebitur
    ,xa.lembagapemeringkat as lembagapemeringkat
    ,xa.tanggalpemeringkatan as tanggalpemeringkatan
    ,xa.nikpassportpasangan as nikpassportpasangan
    ,xa.namapasangan as namapasangan
    ,xa.tanggallahirpasangan as tanggallahirpasangan
    ,xa.perjanjianpisahharta as perjanjianpisahharta
    ,xa.jumlahtanggungan as jumlahtanggungan
    ,xa.tanggalaktependirian as tanggalaktependirian
    ,xa.tanggalakteperubahanterakhir as tanggalakteperubahanterakhir
    ,xa.updatequery as updatequery
    ,xa.kodejenisbadanusaha_desc as kodejenisbadanusaha_desc
from TMP_SLIK_CustomerDetail as xa
where xa.Period = z_dPeriod
;

delete from TMP_SLIK_CustomerDetailDuplikat
where rowid <> 1
;

z_cErrMsg = public.serene(1, 'C810');
-- delete CustomerType is null
delete from TMP_SLIK_CustomerMaster as xz
where xz.CustomerType is NULL
;

z_cErrMsg = public.serene(1, 'C820');

update TMP_SLIK_CustomerDetailDuplikat as xz
set
     lastchangeduser = xa.cfvusr
    ,updatequery = xz.updatequery || 'UQ-57#'
from tmpv_cfmast as xa
where xz.cifori = xa.cfcif_2
;

z_cErrMsg = public.serene(1, 'C830');

insert into TMP_SLIK_CustomerMaster
(
     cif
    ,customertype
    ,periodpelaporan
    ,cifori
    ,kodekantorcabang
    ,statussyariah
    ,insertquery
)
select distinct
     xa.cif as cif
    ,xa.customertype as customertype
    ,z_dPeriod as periodpelaporan
    ,xb.cifori as cifori
    ,xb.kodekantorcabang as kodekantorcabang
    ,xb.statussyariah as statussyariah
    ,'IQ-03' as insertquery
from TMP_SLIK_CustomerMaster_Prev as xa
-- inner join probi.slik_accountdetail as xb
inner join tmp_slik_accountdetail as xb
    on  xb.cif = xa.cif
    and xb.period = z_dPeriod
left join TMP_SLIK_CustomerMaster as xc
    on  xc.cif = xa.cif
    and xc.periodpelaporan = z_dPeriod
where xa.maxperiodpelaporan = z_dPeriodLastEOM
and xc.cif is null
;

z_cErrMsg = public.serene(1, 'C840');

insert into TMP_SLIK_CustomerDetailDuplikat
(
     period
    ,cif
    ,officecif
    ,cifname
    ,namalengkap
    ,telepon
    ,nomortelepongenggam
    ,alamatemail
    ,alamat
    ,kelurahan
    ,kecamatan
    ,kodedatiii
    ,kodepos
    ,kodenegara
    ,kodepekerjaan
    ,melanggarbm
    ,melampauibm
    ,kodebidangusaha
    ,idnumber
    ,idtype
    ,flagwniwna
    ,kodestatusgelardebitur
    ,jeniskelamin
    ,tempatlahirktp
    ,tanggallahir
    ,npwp
    ,tempatbekerja
    ,alamattempatbekerja
    ,penghasilankotorpertahun
    ,kodesumberpenghasilan
    ,kodehubungandenganljk
    ,kodegolongandebitur
    ,statusperkawinandebitur
    ,namagadisibukandung
    ,kodejenisbadanusaha
    ,cifori
    ,source
    ,rowid
    ,kodekantorcabang
    ,insertquery
    ,gopublic
    ,idgroupdebitur
    ,namagroupdebitur
    ,noaktependirian
    ,noakteperubahanterakhir
    ,peringkatdebitur
    ,lembagapemeringkat
    ,tanggalpemeringkatan
    ,nikpassportpasangan
    ,namapasangan
    ,tanggallahirpasangan
    ,perjanjianpisahharta
    ,jumlahtanggungan
    ,tanggalaktependirian
    ,tanggalakteperubahanterakhir
    ,lastchangeduser
    ,kodejenisbadanusaha_desc
)
select distinct
     z_dPeriod as period
    ,xa.cif as cif
    ,xa.officecif as officecif
    ,xa.cifname as cifname
    ,xa.namalengkap as namalengkap
    ,xa.telepon as telepon
    ,xa.nomortelepongenggam as nomortelepongenggam
    ,xa.alamatemail as alamatemail
    ,xa.alamat as alamat
    ,xa.kelurahan as kelurahan
    ,xa.kecamatan as kecamatan
    ,xa.kodedatiii as kodedatiii
    ,xa.kodepos as kodepos
    ,xa.kodenegara as kodenegara
    ,xa.kodepekerjaan as kodepekerjaan
    ,xa.melanggarbm as melanggarbm
    ,xa.melampauibm as melampauibm
    ,xa.kodebidangusaha as kodebidangusaha
    ,xa.idnumber as idnumber
    ,xa.idtype as idtype
    ,xa.flagwniwna as flagwniwna
    ,xa.kodestatusgelardebitur as kodestatusgelardebitur
    ,xa.jeniskelamin as jeniskelamin
    ,xa.tempatlahirktp as tempatlahirktp
    ,xa.tanggallahir as tanggallahir
    ,xa.npwp as npwp
    ,xa.tempatbekerja as tempatbekerja
    ,xa.alamattempatbekerja as alamattempatbekerja
    ,xa.penghasilankotorpertahun as penghasilankotorpertahun
    ,xa.kodesumberpenghasilan as kodesumberpenghasilan
    ,xa.kodehubungandenganljk as kodehubungandenganljk
    ,xa.kodegolongandebitur as kodegolongandebitur
    ,xa.statusperkawinandebitur as statusperkawinandebitur
    ,xa.namagadisibukandung as namagadisibukandung
    ,xa.kodejenisbadanusaha as kodejenisbadanusaha
    ,xa.cifori as cifori
    ,'lastmonth' as source
    ,ROW_NUMBER() OVER (partition by xa.cif ,xa.kodekantorcabang order by xa.period desc) as rowid
    ,xa.kodekantorcabang as kodekantorcabang
    ,'IQ-03' as insertquery
    ,xa.gopublic as gopublic
    ,xa.idgroupdebitur as idgroupdebitur
    ,xa.namagroupdebitur as namagroupdebitur
    ,xa.noaktependirian as noaktependirian
    ,xa.noakteperubahanterakhir as noakteperubahanterakhir
    ,xa.peringkatdebitur as peringkatdebitur
    ,xa.lembagapemeringkat as lembagapemeringkat
    ,xa.tanggalpemeringkatan as tanggalpemeringkatan
    ,xa.nikpassportpasangan as nikpassportpasangan
    ,xa.namapasangan as namapasangan
    ,xa.tanggallahirpasangan as tanggallahirpasangan
    ,xa.perjanjianpisahharta as perjanjianpisahharta
    ,xa.jumlahtanggungan as jumlahtanggungan
    ,xa.tanggalaktependirian as tanggalaktependirian
    ,xa.tanggalakteperubahanterakhir as tanggalakteperubahanterakhir
    ,xa.lastchangeduser as lastchangeduser
    ,xa.kodejenisbadanusaha_desc as kodejenisbadanusaha_desc
from TMP_SLIK_CustomerDetail_Prev as xa
inner join TMP_SLIK_CustomerMaster as xb
    on  xb.cif = xa.cif
    and xb.periodpelaporan = z_dPeriod
    and xb.insertquery = 'IQ-03'
left join TMP_SLIK_CustomerDetailDuplikat as xc
    on  xc.cif = xa.cif
    and xc.period = z_dPeriod
where xa.period = z_dPeriodLastEOM
and xc.cif is null
;

z_cErrMsg = public.serene(1, 'C860');

update TMP_SLIK_CustomerDetailDuplikat as xz
set
     kodekantorcabang = xa.kodekantorcabang
    ,nikpassportpasangan = xa.nikpassportpasangan
    ,namapasangan = xa.namapasangan
    ,tanggallahirpasangan = case
                                when xa.tanggallahirpasangan = '' then null
                                else xa.tanggallahirpasangan::date
                            end
    ,perjanjianpisahharta = xa.perjanjianpisahharta
    ,jumlahtanggungan = case
                            when xa.jumlahtanggungan = '' then null
                            else xa.jumlahtanggungan::integer
                        end
    ,updatequery = xz.updatequery || 'UQ-58#'
from probi.slik_f_d01 as xa
where xa.period = z_dPeriodLastEOM
and xz.insertquery = 'IQ-03'
and xz.cif = xa.cif
;

z_cErrMsg = public.serene(1, 'C870');

update TMP_SLIK_CustomerDetailDuplikat as xz
set
     kodekantorcabang = xa.kodekantorcabang
    ,gopublic = xa.gopublic
    ,namagroupdebitur = xa.namagroupdebitur
    ,noaktependirian = xa.noaktependirian
    ,noakteperubahanterakhir = xa.noakteperubahanterakhir
    ,peringkatdebitur = xa.peringkatdebitur
    ,lembagapemeringkat = xa.lembagapemeringkat
    ,tanggalpemeringkatan = case
                                when xa.tanggalpemeringkatan = '' then null
                                else xa.tanggalpemeringkatan::date
                            end
    ,tanggalaktependirian = case
                                when xa.tanggalaktependirian = '' then null
                                else xa.tanggalaktependirian::date
                            end
    ,tanggalakteperubahanterakhir = case
                                        when xa.tanggalakteperubahanterakhir = '' then null
                                        else xa.tanggalakteperubahanterakhir::date
                                    end
    ,updatequery = xz.updatequery || 'UQ-59#'
from probi.slik_f_d02 as xa
where xa.period = z_dPeriodLastEOM
and xz.insertquery = 'IQ-03'
and xz.cif = xa.cif
;

----------------------------------------------------------------------------------------------------------
-- Main Process Result --
----------------------------------------------------------------------------------------------------------
z_cErrMsg = public.serene(1, 'D010');
---- delete probi. slik_customermaster yang bukan EOM dan EOD ----
delete from probi.slik_customermaster as xa
where DATE_PART('month', xa.PeriodPelaporan) = DATE_PART('month', xa.PeriodPelaporan + 1)
and xa.PeriodPelaporan between z_dPeriodCurrBOM and z_dPeriodPrev1EOD
;

z_cErrMsg = public.serene(1, 'D020');
---- delete probi. slik_customermaster per periode pelaporan ----
delete from probi.slik_customermaster as xz
where xz.PeriodPelaporan = z_dPeriod
;

z_cErrMsg = public.serene(1, 'D030');
---- insert probi. slik_customermaster per periode pelaporan dari TMP_SLIK_CustomerMaster ----
insert into probi.slik_customermaster
(
     CIF
    ,CustomerType -- CompanyFlag
    ,PeriodPelaporan
    ,cifori
    ,kodekantorcabang
    ,statussyariah
    ,insertquery
    ,updatequery
)
select distinct
     xa.CIF as CIF
    ,xa.CustomerType as CustomerType -- CompanyFlag
    ,xa.PeriodPelaporan as PeriodPelaporan
    ,xa.cifori as cifori
    ,xa.kodekantorcabang as kodekantorcabang
    ,xa.statussyariah as statussyariah
    ,xa.insertquery as insertquery
    ,xa.updatequery as updatequery
from TMP_SLIK_CustomerMaster as xa
order by
     xa.CIF asc
    ,xa.kodekantorcabang asc
;

z_cErrMsg = public.serene(1, 'D040');
---- delete probi. slik_customerdetail yang bukan EOM dan EOD ----
delete from probi.slik_customerdetail as xa
where DATE_PART('month', xa.period) = DATE_PART('month', xa.period + 1)
and xa.period between z_dPeriodCurrBOM and z_dPeriodPrev1EOD
;

z_cErrMsg = public.serene(1, 'D050');
---- delete probi. slik_customerdetail per periode pelaporan ----
delete from probi.slik_customerdetail as xz
where xz.Period = z_dPeriod
;

z_cErrMsg = public.serene(1, 'D060');
---- insert probi. slik_customerdetail per periode pelaporan dari TMP_SLIK_CustomerDetail ----
insert into probi.slik_customerdetail
(
     Period
    ,CIF
    ,OfficeCIF
    ,CIFName
    ,NamaLengkap
    ,Telepon
    ,AlamatEmail
    ,Alamat
    ,Kelurahan
    ,Kecamatan
    ,KodeDATIII
    ,KodePos
    ,KodeNegara
    ,KodePekerjaan -- KodeBidangUsaha
    ,MelanggarBM
    ,MelampauiBM
    ,KodeBidangUsaha -- SektorEkonomi
    ,IdNumber
    ,IDType
    ,FlagWNIWNA
    ,KodeStatusGelarDebitur
    ,JenisKelamin
    ,TempatLahirKTP
    ,TanggalLahir
    ,NPWP
    ,NomorTeleponGenggam
    ,TempatBekerja
    ,AlamatTempatBekerja
    ,PenghasilanKotorPerTahun
    ,KodeSumberPenghasilan
    ,KodeHubungandenganLJK
    ,KodeGolonganDebitur
    ,StatusPerkawinanDebitur
    ,NamaGadisIbuKandung
    ,KodeJenisBadanUsaha
    ,CIFOri
    ,Source
    ,lastchangeduser
    ,kodekantorcabang
    ,gopublic
    ,idgroupdebitur
    ,namagroupdebitur
    ,noaktependirian
    ,noakteperubahanterakhir
    ,peringkatdebitur
    ,lembagapemeringkat
    ,tanggalpemeringkatan
    ,nikpassportpasangan
    ,namapasangan
    ,tanggallahirpasangan
    ,perjanjianpisahharta
    ,jumlahtanggungan
    ,tanggalaktependirian
    ,tanggalakteperubahanterakhir
    ,insertquery
    ,updatequery
    ,kodejenisbadanusaha_desc
)
select distinct
     xa.Period as Period
    ,xa.CIF as CIF
    ,xa.OfficeCIF as OfficeCIF
    ,xa.CIFName as CIFName
    ,xa.NamaLengkap as NamaLengkap
    ,xa.Telepon as Telepon
    ,xa.AlamatEmail as AlamatEmail
    ,xa.Alamat as Alamat
    ,xa.Kelurahan as Kelurahan
    ,xa.Kecamatan as Kecamatan
    ,xa.KodeDATIII as KodeDATIII
    ,xa.KodePos as KodePos
    ,xa.KodeNegara as KodeNegara
    ,xa.KodePekerjaan as KodePekerjaan -- KodeBidangUsaha
    ,xa.MelanggarBM as MelanggarBM
    ,xa.MelampauiBM as MelampauiBM
    ,xa.KodeBidangUsaha as KodeBidangUsaha -- SektorEkonomi
    ,xa.IdNumber as IdNumber
    ,xa.IDType as IDType
    ,xa.FlagWNIWNA as FlagWNIWNA
    ,xa.KodeStatusGelarDebitur as KodeStatusGelarDebitur
    ,xa.JenisKelamin as JenisKelamin
    ,xa.TempatLahirKTP as TempatLahirKTP
    ,xa.TanggalLahir as TanggalLahir
    ,xa.NPWP as NPWP
    ,xa.NomorTeleponGenggam as NomorTeleponGenggam
    ,xa.TempatBekerja as TempatBekerja
    ,xa.AlamatTempatBekerja as AlamatTempatBekerja
    ,xa.PenghasilanKotorPerTahun as PenghasilanKotorPerTahun
    ,xa.KodeSumberPenghasilan as KodeSumberPenghasilan
    ,xa.KodeHubungandenganLJK as KodeHubungandenganLJK
    ,xa.KodeGolonganDebitur as KodeGolonganDebitur
    ,xa.StatusPerkawinanDebitur as StatusPerkawinanDebitur
    ,xa.NamaGadisIbuKandung as NamaGadisIbuKandung
    ,xa.KodeJenisBadanUsaha as KodeJenisBadanUsaha
    ,xa.CIFOri as CIFOri
    ,xa.Source as Source
    ,xa.lastchangeduser as lastchangeduser
    ,xa.kodekantorcabang as kodekantorcabang
    ,xa.gopublic as gopublic
    ,xa.idgroupdebitur as idgroupdebitur
    ,xa.namagroupdebitur as namagroupdebitur
    ,xa.noaktependirian as noaktependirian
    ,xa.noakteperubahanterakhir as noakteperubahanterakhir
    ,xa.peringkatdebitur as peringkatdebitur
    ,xa.lembagapemeringkat as lembagapemeringkat
    ,xa.tanggalpemeringkatan as tanggalpemeringkatan
    ,xa.nikpassportpasangan as nikpassportpasangan
    ,xa.namapasangan as namapasangan
    ,xa.tanggallahirpasangan as tanggallahirpasangan
    ,xa.perjanjianpisahharta as perjanjianpisahharta
    ,xa.jumlahtanggungan as jumlahtanggungan
    ,xa.tanggalaktependirian as tanggalaktetanggalakteperubahanterakhirpendirian
    ,xa.tanggalakteperubahanterakhir as tanggalakteperubahanterakhir
    ,xa.insertquery as insertquery
    ,xa.updatequery as updatequery
    ,xa.kodejenisbadanusaha_desc as kodejenisbadanusaha_desc
from TMP_SLIK_CustomerDetailDuplikat as xa
order by
     xa.CIF asc
    ,xa.NamaLengkap asc
    ,xa.kodekantorcabang asc
;


z_cErrMsg = public.serene(1, 'D670');

perform public.runcmd
(
                  'psql -d ' || current_database()::character varying || ' -Atc "'
    || CHR(10) || 'update probi.BI_ProcessTable_TM as xz'
    || CHR(10) || 'set'
    || CHR(10) || '     successbit = 1 -- success --'
    || CHR(10) || '    ,lastexecsuccessdate = ''' || current_timestamp::character varying || ''''
    || CHR(10) || 'where xz.storedprocedurename = ''' || LOWER(z_cFuncName) || ''''
    || CHR(10) || ';'
    || CHR(10) || '"'
);

z_cErrMsg = public.serene(1, 'D680');

perform public.runcmd
(
                  'psql -d ' || current_database()::character varying || ' -Atc "'
    || CHR(10) || 'insert into probi.bi_statusprocesslog_tm'
    || CHR(10) || '('
    || CHR(10) || '     processguid          ,perioddata           ,groupid              ,processid'
    || CHR(10) || '    ,lastchangestatusdate ,statusprocess        ,keterangan           ,submiternik'
    || CHR(10) || '    ,submitdate           ,approvalnik          ,approvaldate         ,textfile'
    || CHR(10) || ')'
    || CHR(10) || 'select'
    || CHR(10) || '     null::character varying as processguid'
    || CHR(10) || '    ,''' || z_dPeriod::character varying || ''' as perioddata'
    || CHR(10) || '    ,' || z_nJobId::character varying || ' as groupid'
    || CHR(10) || '    ,' || z_nProcessId::character varying || ' as processid'
    || CHR(10) || '    ,null::timestamp without time zone as lastchangestatusdate'
    || CHR(10) || '    ,''' || z_cStatusProcess || ''' as statusprocess'
    || CHR(10) || '    ,''' || '' || ''' as keterangan'
    || CHR(10) || '    ,' || z_nSubmitterNIK::character varying || ' as submiternik'
    || CHR(10) || '    ,''' || current_timestamp::character varying || ''' as submitdate'
    || CHR(10) || '    ,null::integer as approvalnik'
    || CHR(10) || '    ,null::timestamp without time zone as approvaldate'
    || CHR(10) || '    ,null::character varying as textfile'
    || CHR(10) || ';'
    || CHR(10) || '"'
);

set optimizer = false;

return 0;

----------------------------------------------------------------------------------------------------------
-- Exception --
----------------------------------------------------------------------------------------------------------
EXCEPTION
when OTHERS then
z_cFuncName = COALESCE(z_cFuncName, '[UNSPECIFIED FUNCTION NAME]');
z_cErrMsg   = COALESCE(z_cErrMsg, 'Error#00 - Unspecified Error. Please review the function definition.');
z_cSQLState = SQLSTATE;
z_cSQLMsg   = SQLERRM;
z_cUser     = USER;

perform public.DailyProcessErrorMessageInsert
(
     z_cFuncName -- z_pcFunctionName --
    ,z_cErrMsg -- z_pcErrorMessage --
    ,z_cSQLState -- z_pcSQLErrNo --
    ,z_cSQLMsg -- z_pcSQLErrMessage --
    ,z_cUser -- z_pcUserId --
);

raise EXCEPTION '[ERROR - %]: % | % - %', z_cFuncName, z_cErrMsg, z_cSQLState, z_cSQLMsg;

set optimizer = false;

----------------------------------------------------------------------------------------------------------
-- Object Usage List --
----------------------------------------------------------------------------------------------------------
/*
-- Table --

-- Function --

-- Result --

*/
--========================================================================================================
END;--FUNCTION--
--========================================================================================================
$BODY$
language plpgsql volatile;